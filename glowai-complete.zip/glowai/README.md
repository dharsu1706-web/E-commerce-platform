# 🌸 GlowAI — Premium AI-Powered Cosmetic E-Commerce Platform

A full-stack, production-ready beauty e-commerce platform with AI-powered skincare recommendations, built with React + Vite, Node.js/Express, MongoDB, and Cloudinary.

## ✨ Features

- AI Beauty Assistant chatbot with skin-type-based recommendations
- AI Skin Quiz with personalized product suggestions
- Full e-commerce flow: Shop, Cart, Checkout, Orders, Tracking
- JWT Authentication with protected routes
- Admin Dashboard with analytics, charts, and full CRUD management
- Wishlist, Reviews & Ratings, Coupons, Newsletter
- Dark mode, glassmorphism UI, smooth Framer Motion animations
- Fully responsive (mobile, tablet, desktop)

## 🛠️ Tech Stack

**Frontend:** React + Vite, Tailwind CSS, Framer Motion, React Router, Axios, Recharts
**Backend:** Node.js, Express, JWT, bcrypt, Mongoose
**Database:** MongoDB Atlas
**Image Storage:** Cloudinary

## 🚀 Getting Started

### Backend Setup

```bash
cd backend
npm install
cp .env.example .env
# Fill in your MongoDB URI, JWT secret, Cloudinary keys, SMTP credentials
npm run seed   # Seeds database with 30 products, categories, coupons, admin user
npm run dev    # Starts server on port 5000
```

### Frontend Setup

```bash
cd frontend
npm install
cp .env.example .env
# Set VITE_API_URL to your backend URL
npm run dev    # Starts dev server on port 5173
```

## 🔑 Demo Credentials (after seeding)

- **Admin:** admin@glowai.com / Admin@123456
- **User:** demo@glowai.com / Demo@123456

## 📦 Deployment

- **Frontend:** Deploy to Vercel (vercel.json included for SPA routing)
- **Backend:** Deploy to Render (set environment variables from .env.example)

## 📁 Project Structure

```
glowai/
├── frontend/
│   ├── src/
│   │   ├── components/  (common, layout, home, shop, product, cart, auth, admin, dashboard, quiz, chatbot)
│   │   ├── pages/        (HomePage, ShopPage, ProductDetailsPage, dashboard/, admin/, etc.)
│   │   ├── hooks/
│   │   ├── context/      (AuthContext, CartContext, ThemeContext)
│   │   └── services/     (api.js)
└── backend/
    ├── controllers/
    ├── models/            (User, Product, Category, Order, Review, Coupon, Newsletter)
    ├── routes/
    ├── middleware/         (auth, errorHandler)
    ├── config/             (db, cloudinary)
    └── utils/              (seeder, sendEmail)
```

## 🎨 Design

Premium pink/white/black theme inspired by Apple and Sephora, with glassmorphism cards, smooth animations, and full dark mode support.
