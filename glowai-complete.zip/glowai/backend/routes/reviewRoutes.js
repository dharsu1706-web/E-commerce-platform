// reviewRoutes.js
const express = require('express');
const router = express.Router();
const { getProductReviews, createReview, updateReview, deleteReview, moderateReview, getAllReviews } = require('../controllers/reviewController');
const { protect, authorize } = require('../middleware/auth');

router.get('/', protect, authorize('admin'), getAllReviews);
router.get('/:productId', getProductReviews);
router.post('/', protect, createReview);
router.route('/:id').put(protect, updateReview).delete(protect, deleteReview);
router.put('/:id/moderate', protect, authorize('admin'), moderateReview);

module.exports = router;
