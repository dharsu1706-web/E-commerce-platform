// uploadRoutes.js
const express = require('express');
const router = express.Router();
const { protect, authorize } = require('../middleware/auth');
const { upload, cloudinary } = require('../config/cloudinary');
const asyncHandler = require('express-async-handler');

router.post('/', protect, authorize('admin'), upload.array('images', 5), asyncHandler(async (req, res) => {
  if (!req.files || req.files.length === 0) {
    res.status(400);
    throw new Error('No files uploaded');
  }
  const images = req.files.map(file => ({ public_id: file.filename, url: file.path }));
  res.status(200).json({ success: true, images });
}));

router.delete('/', protect, authorize('admin'), asyncHandler(async (req, res) => {
  const { public_id } = req.body;
  if (!public_id) {
    res.status(400);
    throw new Error('Public ID is required');
  }
  await cloudinary.uploader.destroy(public_id);
  res.status(200).json({ success: true, message: 'Image deleted' });
}));

module.exports = router;
