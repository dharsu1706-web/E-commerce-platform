const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/auth');
const User = require('../models/User');
const asyncHandler = require('express-async-handler');

router.get('/', protect, asyncHandler(async (req, res) => {
  const user = await User.findById(req.user._id).populate({
    path: 'wishlist',
    select: 'name images price discountPrice ratings numReviews slug stock',
    populate: { path: 'category', select: 'name' },
  });
  res.status(200).json({ success: true, wishlist: user.wishlist });
}));

router.post('/:productId', protect, asyncHandler(async (req, res) => {
  const user = await User.findById(req.user._id);
  const idx = user.wishlist.indexOf(req.params.productId);
  if (idx > -1) {
    user.wishlist.splice(idx, 1);
    await user.save();
    return res.status(200).json({ success: true, message: 'Removed from wishlist', inWishlist: false });
  }
  user.wishlist.push(req.params.productId);
  await user.save();
  res.status(200).json({ success: true, message: 'Added to wishlist', inWishlist: true });
}));

module.exports = router;
