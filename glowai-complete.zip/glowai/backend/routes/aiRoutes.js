const express = require('express');
const router = express.Router();
const { chat, skinQuizRecommendations } = require('../controllers/aiController');

router.post('/chat', chat);
router.post('/quiz', skinQuizRecommendations);

module.exports = router;
