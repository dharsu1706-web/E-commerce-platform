const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/auth');
const asyncHandler = require('express-async-handler');
const Product = require('../models/Product');

// Cart is primarily client-side but we provide a sync endpoint
router.post('/validate', protect, asyncHandler(async (req, res) => {
  const { items } = req.body;
  const validatedItems = [];
  let hasChanges = false;

  for (const item of items) {
    const product = await Product.findById(item.product).select('name price discountPrice stock images slug isActive');
    if (!product || !product.isActive) {
      hasChanges = true;
      continue; // Remove unavailable products
    }
    const currentPrice = product.discountPrice || product.price;
    if (currentPrice !== item.price) hasChanges = true;
    if (item.quantity > product.stock) {
      item.quantity = product.stock;
      hasChanges = true;
    }
    if (product.stock > 0) {
      validatedItems.push({
        ...item,
        price: currentPrice,
        name: product.name,
        image: product.images[0]?.url || '',
        stock: product.stock,
      });
    }
  }

  res.status(200).json({ success: true, items: validatedItems, hasChanges });
}));

module.exports = router;
