const express = require('express');
const router = express.Router();
const { validateCoupon, getAllCoupons, createCoupon, updateCoupon, deleteCoupon } = require('../controllers/couponController');
const { protect, authorize } = require('../middleware/auth');

router.post('/validate', protect, validateCoupon);
router.route('/').get(protect, authorize('admin'), getAllCoupons).post(protect, authorize('admin'), createCoupon);
router.route('/:id').put(protect, authorize('admin'), updateCoupon).delete(protect, authorize('admin'), deleteCoupon);

module.exports = router;
