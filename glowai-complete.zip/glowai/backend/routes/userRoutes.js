const express = require('express');
const router = express.Router();
const { getProfile, updateProfile, addAddress, updateAddress, deleteAddress, toggleWishlist, getAllUsers, updateUser, deleteUser } = require('../controllers/userController');
const { protect, authorize } = require('../middleware/auth');

router.get('/profile', protect, getProfile);
router.put('/profile', protect, updateProfile);
router.post('/address', protect, addAddress);
router.route('/address/:addressId').put(protect, updateAddress).delete(protect, deleteAddress);
router.post('/wishlist/:productId', protect, toggleWishlist);

// Admin routes
router.get('/', protect, authorize('admin'), getAllUsers);
router.route('/:id').put(protect, authorize('admin'), updateUser).delete(protect, authorize('admin'), deleteUser);

module.exports = router;
