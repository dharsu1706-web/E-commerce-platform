const asyncHandler = require('express-async-handler');
const sendEmail = require('../utils/sendEmail');

exports.sendContact = asyncHandler(async (req, res) => {
  const { name, email, subject, message } = req.body;

  await sendEmail({
    email: process.env.FROM_EMAIL,
    subject: `GlowAI Contact: ${subject}`,
    html: `<h3>New Contact Form Submission</h3><p><strong>Name:</strong> ${name}</p><p><strong>Email:</strong> ${email}</p><p><strong>Subject:</strong> ${subject}</p><p><strong>Message:</strong></p><p>${message}</p>`,
  });

  await sendEmail({
    email,
    subject: 'We received your message - GlowAI',
    html: `<h2>Thank you for contacting GlowAI! 🌸</h2><p>Hi ${name},</p><p>We've received your message and will get back to you within 24-48 hours.</p><p>Our team is dedicated to giving you the best beauty experience!</p><p>Love,<br/>GlowAI Team ✨</p>`,
  });

  res.status(200).json({ success: true, message: 'Message sent successfully! We\'ll get back to you soon.' });
});
