const asyncHandler = require('express-async-handler');
const Order = require('../models/Order');
const Product = require('../models/Product');
const User = require('../models/User');
const Review = require('../models/Review');

exports.getDashboardStats = asyncHandler(async (req, res) => {
  const now = new Date();
  const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
  const startOfLastMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1);
  const endOfLastMonth = new Date(now.getFullYear(), now.getMonth(), 0);

  const [
    totalOrders, thisMonthOrders, lastMonthOrders,
    totalUsers, thisMonthUsers,
    totalProducts, lowStockProducts,
    revenueData, topProducts, recentOrders,
    orderStatusStats, pendingReviews,
  ] = await Promise.all([
    Order.countDocuments(),
    Order.countDocuments({ createdAt: { $gte: startOfMonth } }),
    Order.countDocuments({ createdAt: { $gte: startOfLastMonth, $lte: endOfLastMonth } }),
    User.countDocuments({ role: 'user' }),
    User.countDocuments({ role: 'user', createdAt: { $gte: startOfMonth } }),
    Product.countDocuments({ isActive: true }),
    Product.countDocuments({ isActive: true, stock: { $lte: 10 } }),
    Order.aggregate([
      { $group: { _id: null, total: { $sum: '$totalPrice' }, thisMonth: { $sum: { $cond: [{ $gte: ['$createdAt', startOfMonth] }, '$totalPrice', 0] } }, lastMonth: { $sum: { $cond: [{ $and: [{ $gte: ['$createdAt', startOfLastMonth] }, { $lte: ['$createdAt', endOfLastMonth] }] }, '$totalPrice', 0] } } } },
    ]),
    Order.aggregate([
      { $unwind: '$items' },
      { $group: { _id: '$items.product', totalSold: { $sum: '$items.quantity' }, revenue: { $sum: { $multiply: ['$items.price', '$items.quantity'] } } } },
      { $sort: { totalSold: -1 } },
      { $limit: 5 },
      { $lookup: { from: 'products', localField: '_id', foreignField: '_id', as: 'product' } },
      { $unwind: '$product' },
      { $project: { name: '$product.name', image: { $arrayElemAt: ['$product.images.url', 0] }, totalSold: 1, revenue: 1 } },
    ]),
    Order.find().sort('-createdAt').limit(5).populate('user', 'name email').select('orderNumber totalPrice orderStatus createdAt user'),
    Order.aggregate([{ $group: { _id: '$orderStatus', count: { $sum: 1 } } }]),
    Review.countDocuments({ isApproved: false }),
  ]);

  // Monthly revenue for chart (last 6 months)
  const monthlyRevenue = [];
  for (let i = 5; i >= 0; i--) {
    const start = new Date(now.getFullYear(), now.getMonth() - i, 1);
    const end = new Date(now.getFullYear(), now.getMonth() - i + 1, 0);
    const result = await Order.aggregate([
      { $match: { createdAt: { $gte: start, $lte: end } } },
      { $group: { _id: null, revenue: { $sum: '$totalPrice' }, orders: { $sum: 1 } } },
    ]);
    monthlyRevenue.push({
      month: start.toLocaleString('default', { month: 'short' }),
      revenue: result[0]?.revenue || 0,
      orders: result[0]?.orders || 0,
    });
  }

  const revenue = revenueData[0] || { total: 0, thisMonth: 0, lastMonth: 0 };

  res.status(200).json({
    success: true,
    stats: {
      totalOrders,
      thisMonthOrders,
      orderGrowth: lastMonthOrders ? (((thisMonthOrders - lastMonthOrders) / lastMonthOrders) * 100).toFixed(1) : 100,
      totalUsers,
      thisMonthUsers,
      totalProducts,
      lowStockProducts,
      totalRevenue: revenue.total,
      thisMonthRevenue: revenue.thisMonth,
      revenueGrowth: revenue.lastMonth ? (((revenue.thisMonth - revenue.lastMonth) / revenue.lastMonth) * 100).toFixed(1) : 100,
    },
    topProducts,
    recentOrders,
    monthlyRevenue,
    orderStatusStats,
    pendingReviews,
  });
});
