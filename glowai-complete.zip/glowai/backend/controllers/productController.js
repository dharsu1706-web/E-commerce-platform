const asyncHandler = require('express-async-handler');
const Product = require('../models/Product');
const Review = require('../models/Review');

// @desc    Get all products
// @route   GET /api/products
// @access  Public
exports.getProducts = asyncHandler(async (req, res) => {
  const page = parseInt(req.query.page) || 1;
  const limit = parseInt(req.query.limit) || 12;
  const skip = (page - 1) * limit;

  let query = { isActive: true };

  // Search
  if (req.query.search) {
    query.$text = { $search: req.query.search };
  }

  // Category filter
  if (req.query.category) {
    query.category = req.query.category;
  }

  // Price filter
  if (req.query.minPrice || req.query.maxPrice) {
    query.price = {};
    if (req.query.minPrice) query.price.$gte = Number(req.query.minPrice);
    if (req.query.maxPrice) query.price.$lte = Number(req.query.maxPrice);
  }

  // Skin type filter
  if (req.query.skinType) {
    query.skinType = { $in: [req.query.skinType, 'all'] };
  }

  // Special filters
  if (req.query.featured === 'true') query.isFeatured = true;
  if (req.query.bestSeller === 'true') query.isBestSeller = true;
  if (req.query.trending === 'true') query.isTrending = true;
  if (req.query.isNew === 'true') query.isNew = true;

  // Sort
  let sort = {};
  switch (req.query.sort) {
    case 'price_asc': sort = { price: 1 }; break;
    case 'price_desc': sort = { price: -1 }; break;
    case 'rating': sort = { ratings: -1 }; break;
    case 'newest': sort = { createdAt: -1 }; break;
    case 'popular': sort = { sold: -1 }; break;
    default: sort = { createdAt: -1 };
  }

  const total = await Product.countDocuments(query);
  const products = await Product.find(query)
    .populate('category', 'name slug')
    .sort(sort)
    .skip(skip)
    .limit(limit)
    .select('-__v');

  res.status(200).json({
    success: true,
    count: products.length,
    total,
    page,
    pages: Math.ceil(total / limit),
    products,
  });
});

// @desc    Get single product
// @route   GET /api/products/:id
// @access  Public
exports.getProduct = asyncHandler(async (req, res) => {
  const product = await Product.findOne({
    $or: [{ _id: req.params.id.match(/^[0-9a-fA-F]{24}$/) ? req.params.id : null }, { slug: req.params.id }],
    isActive: true,
  }).populate('category', 'name slug');

  if (!product) {
    res.status(404);
    throw new Error('Product not found');
  }

  // Get reviews
  const reviews = await Review.find({ product: product._id, isApproved: true })
    .populate('user', 'name avatar')
    .sort('-createdAt')
    .limit(20);

  // Get related products
  const related = await Product.find({
    category: product.category,
    _id: { $ne: product._id },
    isActive: true,
  })
    .limit(4)
    .select('name images price discountPrice ratings numReviews slug');

  res.status(200).json({ success: true, product, reviews, related });
});

// @desc    Create product (Admin)
// @route   POST /api/products
// @access  Private/Admin
exports.createProduct = asyncHandler(async (req, res) => {
  const product = await Product.create(req.body);
  res.status(201).json({ success: true, message: 'Product created successfully', product });
});

// @desc    Update product (Admin)
// @route   PUT /api/products/:id
// @access  Private/Admin
exports.updateProduct = asyncHandler(async (req, res) => {
  let product = await Product.findById(req.params.id);
  if (!product) {
    res.status(404);
    throw new Error('Product not found');
  }
  product = await Product.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
  res.status(200).json({ success: true, message: 'Product updated successfully', product });
});

// @desc    Delete product (Admin)
// @route   DELETE /api/products/:id
// @access  Private/Admin
exports.deleteProduct = asyncHandler(async (req, res) => {
  const product = await Product.findById(req.params.id);
  if (!product) {
    res.status(404);
    throw new Error('Product not found');
  }
  product.isActive = false;
  await product.save();
  res.status(200).json({ success: true, message: 'Product deleted successfully' });
});

// @desc    Get featured/bestseller/trending products
// @route   GET /api/products/featured
// @access  Public
exports.getSpecialProducts = asyncHandler(async (req, res) => {
  const [featured, bestSellers, trending, newArrivals] = await Promise.all([
    Product.find({ isFeatured: true, isActive: true }).limit(6).populate('category', 'name').select('-__v'),
    Product.find({ isBestSeller: true, isActive: true }).limit(8).populate('category', 'name').select('-__v'),
    Product.find({ isTrending: true, isActive: true }).limit(8).populate('category', 'name').select('-__v'),
    Product.find({ isNew: true, isActive: true }).sort('-createdAt').limit(8).populate('category', 'name').select('-__v'),
  ]);
  res.status(200).json({ success: true, featured, bestSellers, trending, newArrivals });
});
