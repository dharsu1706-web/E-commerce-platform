const asyncHandler = require('express-async-handler');
const Product = require('../models/Product');

// Keyword-based AI recommendation engine
const skinCareKnowledge = {
  skinTypes: {
    oily: {
      keywords: ['oily', 'oily skin', 'shiny', 'acne prone', 'large pores', 'greasy'],
      concerns: ['acne', 'blackheads', 'excess sebum', 'large pores'],
      recommendedIngredients: ['salicylic acid', 'niacinamide', 'hyaluronic acid', 'clay', 'zinc'],
      avoidIngredients: ['coconut oil', 'petroleum', 'heavy creams'],
      routine: ['Gentle foam cleanser', 'Salicylic acid toner', 'Oil-free moisturizer', 'SPF 30+'],
    },
    dry: {
      keywords: ['dry', 'dry skin', 'flaky', 'tight', 'dull', 'dehydrated'],
      concerns: ['flakiness', 'tightness', 'premature aging', 'dullness'],
      recommendedIngredients: ['hyaluronic acid', 'ceramides', 'glycerin', 'shea butter', 'vitamin E'],
      avoidIngredients: ['alcohol', 'sulfates', 'fragrance'],
      routine: ['Creamy cleanser', 'Hydrating toner', 'Rich moisturizer', 'Facial oil', 'SPF 50'],
    },
    combination: {
      keywords: ['combination', 't-zone', 'oily t-zone', 'dry cheeks'],
      concerns: ['uneven texture', 'shine in t-zone', 'dry patches'],
      recommendedIngredients: ['niacinamide', 'hyaluronic acid', 'green tea', 'vitamin C'],
      avoidIngredients: ['heavy oils', 'stripping cleansers'],
      routine: ['Balancing cleanser', 'Niacinamide serum', 'Lightweight moisturizer', 'SPF 30+'],
    },
    sensitive: {
      keywords: ['sensitive', 'sensitive skin', 'redness', 'irritation', 'reactive', 'rosacea'],
      concerns: ['redness', 'irritation', 'inflammation', 'reactivity'],
      recommendedIngredients: ['centella asiatica', 'aloe vera', 'ceramides', 'oat extract'],
      avoidIngredients: ['fragrance', 'alcohol', 'strong acids', 'retinol'],
      routine: ['Gentle micellar cleanser', 'Calming toner', 'Barrier repair moisturizer', 'Mineral SPF'],
    },
    acne: {
      keywords: ['acne', 'pimples', 'breakouts', 'spots', 'blemishes', 'zits'],
      concerns: ['acne', 'post-acne marks', 'inflammation'],
      recommendedIngredients: ['salicylic acid', 'benzoyl peroxide', 'niacinamide', 'tea tree', 'zinc'],
      avoidIngredients: ['comedogenic oils', 'heavy silicones'],
      routine: ['Salicylic cleanser', 'BHA toner', 'Niacinamide serum', 'Oil-free moisturizer', 'SPF'],
    },
    darkSpots: {
      keywords: ['dark spots', 'hyperpigmentation', 'uneven skin tone', 'melasma', 'post-acne marks', 'pigmentation'],
      concerns: ['hyperpigmentation', 'uneven tone', 'dark spots'],
      recommendedIngredients: ['vitamin C', 'alpha arbutin', 'kojic acid', 'niacinamide', 'retinol'],
      avoidIngredients: ['sun exposure without SPF'],
      routine: ['Gentle cleanser', 'Vitamin C serum', 'Alpha arbutin serum', 'Moisturizer', 'SPF 50+'],
    },
    antiAging: {
      keywords: ['anti aging', 'wrinkles', 'fine lines', 'aging', 'mature skin', 'firmness'],
      concerns: ['wrinkles', 'sagging', 'loss of firmness', 'dullness'],
      recommendedIngredients: ['retinol', 'peptides', 'vitamin C', 'hyaluronic acid', 'collagen'],
      avoidIngredients: ['strong exfoliants without moisturizing'],
      routine: ['Gentle cleanser', 'Retinol serum (PM)', 'Peptide serum (AM)', 'Rich moisturizer', 'SPF 50+'],
    },
  },
};

const detectIntent = (message) => {
  const lower = message.toLowerCase();
  const intents = [];

  Object.entries(skinCareKnowledge.skinTypes).forEach(([type, data]) => {
    if (data.keywords.some(kw => lower.includes(kw))) {
      intents.push(type);
    }
  });

  return intents.length > 0 ? intents : ['general'];
};

const generateResponse = (message, products, intents) => {
  const lower = message.toLowerCase();
  let response = '';
  let recommendedProducts = [];

  if (intents.includes('general')) {
    // Greetings
    if (lower.includes('hello') || lower.includes('hi') || lower.includes('hey')) {
      return {
        response: "Hello, gorgeous! 🌸 I'm your GlowAI Beauty Assistant. I can help you find the perfect products for your skin type, suggest skincare routines, and recommend solutions for your skin concerns. What can I help you with today?",
        products: [],
      };
    }
    // Help
    if (lower.includes('help') || lower.includes('what can you do')) {
      return {
        response: `Here's what I can help you with:\n\n✨ **Skin Type Recommendations** — Tell me your skin type (oily, dry, combination, sensitive)\n🌿 **Concern-Based Suggestions** — Acne, dark spots, anti-aging, hydration\n💆 **Skincare Routines** — Morning and evening routines tailored to you\n🛍️ **Product Recommendations** — Find the best products from our collection\n\nJust tell me about your skin, and I'll work my magic! ✨`,
        products: [],
      };
    }
    // Show all products
    recommendedProducts = products.slice(0, 4);
    return {
      response: "I'd love to give you personalized recommendations! Could you tell me more about your skin type or concerns? For example: 'I have oily skin with acne' or 'I want to reduce dark spots'. Here are some of our popular products in the meantime:",
      products: recommendedProducts,
    };
  }

  // Build response based on detected intents
  const primaryIntent = intents[0];
  const skinData = skinCareKnowledge.skinTypes[primaryIntent];

  if (!skinData) {
    return { response: "I'm not quite sure what you need. Try asking about specific skin concerns like 'oily skin', 'acne', 'dark spots', or 'dry skin'!", products: [] };
  }

  // Filter products by skin type and concerns
  recommendedProducts = products.filter(p => {
    const matches = intents.some(intent => {
      if (intent === 'oily') return p.skinType?.includes('oily') || p.tags?.some(t => ['oily', 'acne', 'pore'].includes(t));
      if (intent === 'dry') return p.skinType?.includes('dry') || p.tags?.some(t => ['dry', 'hydrating', 'moisturizing'].includes(t));
      if (intent === 'combination') return p.skinType?.includes('combination') || p.tags?.includes('combination');
      if (intent === 'sensitive') return p.skinType?.includes('sensitive') || p.tags?.some(t => ['sensitive', 'calming', 'gentle'].includes(t));
      if (intent === 'acne') return p.tags?.some(t => ['acne', 'blemish', 'salicylic'].includes(t));
      if (intent === 'darkSpots') return p.tags?.some(t => ['brightening', 'vitamin-c', 'dark-spots', 'pigmentation'].includes(t));
      if (intent === 'antiAging') return p.tags?.some(t => ['anti-aging', 'retinol', 'firming', 'peptides'].includes(t));
      return false;
    });
    return matches;
  }).slice(0, 4);

  // If no specific matches, return featured products
  if (recommendedProducts.length === 0) {
    recommendedProducts = products.filter(p => p.isFeatured || p.isBestSeller).slice(0, 4);
  }

  const routineText = skinData.routine.map((step, i) => `${i + 1}. ${step}`).join('\n');
  const ingredientsText = skinData.recommendedIngredients.slice(0, 4).join(', ');

  response = `Great question! Here's my personalized advice:\n\n`;

  if (primaryIntent === 'oily') {
    response += `**For Oily Skin** 🌿\nOily skin needs balancing — not stripping. The goal is to control excess sebum while keeping skin hydrated.\n\n`;
  } else if (primaryIntent === 'dry') {
    response += `**For Dry Skin** 💧\nDry skin needs intense hydration and a strengthened moisture barrier. Layering hydrating products is key!\n\n`;
  } else if (primaryIntent === 'acne') {
    response += `**For Acne-Prone Skin** 🎯\nFighting acne requires a consistent routine targeting bacteria and inflammation while keeping skin balanced.\n\n`;
  } else if (primaryIntent === 'darkSpots') {
    response += `**For Dark Spots & Hyperpigmentation** ✨\nFading dark spots takes patience — usually 8-12 weeks of consistent use. Always pair brightening ingredients with SPF!\n\n`;
  } else if (primaryIntent === 'sensitive') {
    response += `**For Sensitive Skin** 🌸\nSensitive skin needs a minimal, gentle approach. Introduce one new product at a time to avoid reactions.\n\n`;
  } else if (primaryIntent === 'antiAging') {
    response += `**Anti-Aging Skincare** 🌟\nThe best anti-aging ingredient is sunscreen — but adding actives like retinol and peptides can make a visible difference over time.\n\n`;
  } else if (primaryIntent === 'combination') {
    response += `**For Combination Skin** ⚖️\nCombination skin benefits from balancing products that address both oily and dry zones without over-correcting either.\n\n`;
  }

  response += `**Key Ingredients to Look For:**\n${ingredientsText}\n\n**Recommended Routine:**\n${routineText}\n\nHere are some products I recommend for you:`;

  return { response, products: recommendedProducts };
};

// @desc    Chat with AI beauty assistant
// @route   POST /api/ai/chat
// @access  Public
exports.chat = asyncHandler(async (req, res) => {
  const { message, history } = req.body;

  if (!message) {
    res.status(400);
    throw new Error('Message is required');
  }

  // Fetch relevant products
  const products = await Product.find({ isActive: true })
    .select('name images price discountPrice ratings slug skinType tags isFeatured isBestSeller')
    .limit(50)
    .lean();

  const intents = detectIntent(message);
  const { response, products: recommendedProducts } = generateResponse(message, products, intents);

  // Format product recommendations
  const formattedProducts = recommendedProducts.map(p => ({
    _id: p._id,
    name: p.name,
    image: p.images?.[0]?.url || '',
    price: p.price,
    discountPrice: p.discountPrice,
    ratings: p.ratings,
    slug: p.slug,
  }));

  res.status(200).json({
    success: true,
    response,
    products: formattedProducts,
    intents,
  });
});

// @desc    Get skin quiz recommendations
// @route   POST /api/ai/quiz
// @access  Public
exports.skinQuizRecommendations = asyncHandler(async (req, res) => {
  const { skinType, concerns, answers } = req.body;

  let productQuery = { isActive: true };

  if (skinType && skinType !== 'normal') {
    productQuery.skinType = { $in: [skinType, 'all'] };
  }

  const products = await Product.find(productQuery)
    .populate('category', 'name')
    .limit(12)
    .select('name images price discountPrice ratings numReviews slug skinType tags category brand');

  // Score and sort products by relevance
  const scoredProducts = products.map(p => {
    let score = 0;
    if (p.isBestSeller) score += 3;
    if (p.isFeatured) score += 2;
    if (p.isTrending) score += 2;
    if (p.ratings >= 4) score += 2;
    if (concerns && p.skinConcerns) {
      concerns.forEach(c => {
        if (p.skinConcerns.includes(c)) score += 3;
      });
    }
    return { product: p, score };
  });

  scoredProducts.sort((a, b) => b.score - a.score);
  const recommended = scoredProducts.slice(0, 8).map(s => s.product);

  const routineAdvice = skinCareKnowledge.skinTypes[skinType];

  res.status(200).json({
    success: true,
    skinType,
    concerns,
    products: recommended,
    routine: routineAdvice?.routine || [],
    ingredients: routineAdvice?.recommendedIngredients || [],
    message: `Based on your ${skinType} skin type, here are our top recommendations! 🌸`,
  });
});
