const asyncHandler = require('express-async-handler');
const User = require('../models/User');

// @desc    Get user profile
// @route   GET /api/users/profile
// @access  Private
exports.getProfile = asyncHandler(async (req, res) => {
  const user = await User.findById(req.user._id).populate('wishlist', 'name images price discountPrice ratings slug');
  res.status(200).json({ success: true, user });
});

// @desc    Update user profile
// @route   PUT /api/users/profile
// @access  Private
exports.updateProfile = asyncHandler(async (req, res) => {
  const { name, phone, skinType, skinConcerns, avatar } = req.body;
  const user = await User.findById(req.user._id);

  if (name) user.name = name;
  if (phone !== undefined) user.phone = phone;
  if (skinType !== undefined) user.skinType = skinType;
  if (skinConcerns !== undefined) user.skinConcerns = skinConcerns;
  if (avatar) user.avatar = avatar;

  await user.save();
  res.status(200).json({ success: true, message: 'Profile updated successfully', user });
});

// @desc    Add address
// @route   POST /api/users/address
// @access  Private
exports.addAddress = asyncHandler(async (req, res) => {
  const user = await User.findById(req.user._id);
  const { name, street, city, state, zipCode, country, isDefault } = req.body;

  if (isDefault) {
    user.addresses.forEach(addr => (addr.isDefault = false));
  }

  user.addresses.push({ name, street, city, state, zipCode, country, isDefault });
  await user.save();
  res.status(201).json({ success: true, message: 'Address added', addresses: user.addresses });
});

// @desc    Update address
// @route   PUT /api/users/address/:addressId
// @access  Private
exports.updateAddress = asyncHandler(async (req, res) => {
  const user = await User.findById(req.user._id);
  const address = user.addresses.id(req.params.addressId);

  if (!address) {
    res.status(404);
    throw new Error('Address not found');
  }

  if (req.body.isDefault) {
    user.addresses.forEach(addr => (addr.isDefault = false));
  }

  Object.assign(address, req.body);
  await user.save();
  res.status(200).json({ success: true, message: 'Address updated', addresses: user.addresses });
});

// @desc    Delete address
// @route   DELETE /api/users/address/:addressId
// @access  Private
exports.deleteAddress = asyncHandler(async (req, res) => {
  const user = await User.findById(req.user._id);
  user.addresses = user.addresses.filter(a => a._id.toString() !== req.params.addressId);
  await user.save();
  res.status(200).json({ success: true, message: 'Address removed', addresses: user.addresses });
});

// @desc    Toggle wishlist
// @route   POST /api/users/wishlist/:productId
// @access  Private
exports.toggleWishlist = asyncHandler(async (req, res) => {
  const user = await User.findById(req.user._id);
  const idx = user.wishlist.indexOf(req.params.productId);

  if (idx > -1) {
    user.wishlist.splice(idx, 1);
    await user.save();
    return res.status(200).json({ success: true, message: 'Removed from wishlist', inWishlist: false });
  }

  user.wishlist.push(req.params.productId);
  await user.save();
  res.status(200).json({ success: true, message: 'Added to wishlist', inWishlist: true });
});

// @desc    Get all users (Admin)
// @route   GET /api/users
// @access  Private/Admin
exports.getAllUsers = asyncHandler(async (req, res) => {
  const page = parseInt(req.query.page) || 1;
  const limit = 20;
  const skip = (page - 1) * limit;

  let query = {};
  if (req.query.search) {
    query.$or = [
      { name: { $regex: req.query.search, $options: 'i' } },
      { email: { $regex: req.query.search, $options: 'i' } },
    ];
  }
  if (req.query.role) query.role = req.query.role;

  const total = await User.countDocuments(query);
  const users = await User.find(query).sort('-createdAt').skip(skip).limit(limit).select('-password');

  res.status(200).json({ success: true, users, total, page, pages: Math.ceil(total / limit) });
});

// @desc    Update user (Admin)
// @route   PUT /api/users/:id
// @access  Private/Admin
exports.updateUser = asyncHandler(async (req, res) => {
  const user = await User.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true }).select('-password');
  if (!user) {
    res.status(404);
    throw new Error('User not found');
  }
  res.status(200).json({ success: true, message: 'User updated', user });
});

// @desc    Delete user (Admin)
// @route   DELETE /api/users/:id
// @access  Private/Admin
exports.deleteUser = asyncHandler(async (req, res) => {
  const user = await User.findById(req.params.id);
  if (!user) {
    res.status(404);
    throw new Error('User not found');
  }
  user.isActive = false;
  await user.save();
  res.status(200).json({ success: true, message: 'User deactivated' });
});
