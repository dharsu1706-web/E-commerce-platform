const asyncHandler = require('express-async-handler');
const Newsletter = require('../models/Newsletter');
const sendEmail = require('../utils/sendEmail');

exports.subscribe = asyncHandler(async (req, res) => {
  const { email } = req.body;
  const existing = await Newsletter.findOne({ email });
  if (existing) {
    if (!existing.isActive) {
      existing.isActive = true;
      await existing.save();
      return res.status(200).json({ success: true, message: 'Welcome back! You have been re-subscribed.' });
    }
    return res.status(400).json({ success: false, message: 'Email already subscribed' });
  }
  await Newsletter.create({ email });
  try {
    await sendEmail({
      email,
      subject: 'Welcome to GlowAI Newsletter! 🌸',
      html: `<h2>Welcome to GlowAI!</h2><p>Thank you for subscribing to our newsletter. You'll receive exclusive beauty tips, product launches, and special offers directly in your inbox.</p><p>Happy glowing! ✨</p>`,
    });
  } catch (e) {
    console.error('Newsletter welcome email failed:', e.message);
  }
  res.status(201).json({ success: true, message: 'Successfully subscribed to the newsletter! 🌸' });
});

exports.unsubscribe = asyncHandler(async (req, res) => {
  const newsletter = await Newsletter.findOneAndUpdate({ email: req.body.email }, { isActive: false });
  if (!newsletter) {
    res.status(404);
    throw new Error('Email not found');
  }
  res.status(200).json({ success: true, message: 'Unsubscribed successfully' });
});

exports.getAllSubscribers = asyncHandler(async (req, res) => {
  const subscribers = await Newsletter.find({ isActive: true }).sort('-createdAt');
  res.status(200).json({ success: true, count: subscribers.length, subscribers });
});
