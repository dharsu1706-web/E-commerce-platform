const asyncHandler = require('express-async-handler');
const Category = require('../models/Category');
const Product = require('../models/Product');

exports.getCategories = asyncHandler(async (req, res) => {
  const categories = await Category.find({ isActive: true }).sort('order').select('-__v');
  // Attach product counts
  const withCounts = await Promise.all(categories.map(async (cat) => {
    const count = await Product.countDocuments({ category: cat._id, isActive: true });
    return { ...cat.toObject(), productCount: count };
  }));
  res.status(200).json({ success: true, categories: withCounts });
});

exports.getCategory = asyncHandler(async (req, res) => {
  const category = await Category.findOne({ $or: [{ _id: req.params.id.match(/^[0-9a-fA-F]{24}$/) ? req.params.id : null }, { slug: req.params.id }] });
  if (!category) {
    res.status(404);
    throw new Error('Category not found');
  }
  res.status(200).json({ success: true, category });
});

exports.createCategory = asyncHandler(async (req, res) => {
  const category = await Category.create(req.body);
  res.status(201).json({ success: true, message: 'Category created', category });
});

exports.updateCategory = asyncHandler(async (req, res) => {
  const category = await Category.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
  if (!category) {
    res.status(404);
    throw new Error('Category not found');
  }
  res.status(200).json({ success: true, message: 'Category updated', category });
});

exports.deleteCategory = asyncHandler(async (req, res) => {
  const category = await Category.findById(req.params.id);
  if (!category) {
    res.status(404);
    throw new Error('Category not found');
  }
  category.isActive = false;
  await category.save();
  res.status(200).json({ success: true, message: 'Category deleted' });
});
