import React, { useState, useEffect } from 'react'
import { FaTimes } from 'react-icons/fa'

const skinTypes = ['oily', 'dry', 'combination', 'sensitive', 'normal']

const ShopFilters = ({ categories, filters, onChange, onClear, isMobile, onClose }) => {
  const [priceRange, setPriceRange] = useState([filters.minPrice || 0, filters.maxPrice || 5000])

  useEffect(() => {
    setPriceRange([filters.minPrice || 0, filters.maxPrice || 5000])
  }, [filters.minPrice, filters.maxPrice])

  const handlePriceCommit = () => {
    onChange({ minPrice: priceRange[0], maxPrice: priceRange[1] })
  }

  return (
    <div className={`${isMobile ? '' : 'glass-card-solid rounded-2xl p-5 sticky top-24'}`}>
      {isMobile && (
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-display font-semibold text-lg">Filters</h3>
          <button onClick={onClose} className="btn-icon"><FaTimes /></button>
        </div>
      )}

      {/* Category */}
      <div className="mb-6">
        <h4 className="font-semibold text-sm text-gray-800 dark:text-gray-200 mb-3">Category</h4>
        <div className="space-y-2 max-h-56 overflow-y-auto custom-scroll">
          <label className="flex items-center gap-2 text-sm cursor-pointer text-gray-600 dark:text-gray-400 hover:text-pink-500">
            <input
              type="radio"
              name="category"
              checked={!filters.category}
              onChange={() => onChange({ category: '' })}
              className="text-pink-500 focus:ring-pink-400"
            />
            All Categories
          </label>
          {categories.map((cat) => (
            <label key={cat._id} className="flex items-center justify-between gap-2 text-sm cursor-pointer text-gray-600 dark:text-gray-400 hover:text-pink-500">
              <span className="flex items-center gap-2">
                <input
                  type="radio"
                  name="category"
                  checked={filters.category === cat._id}
                  onChange={() => onChange({ category: cat._id })}
                  className="text-pink-500 focus:ring-pink-400"
                />
                {cat.name}
              </span>
              <span className="text-xs text-gray-400">({cat.productCount || 0})</span>
            </label>
          ))}
        </div>
      </div>

      {/* Price */}
      <div className="mb-6">
        <h4 className="font-semibold text-sm text-gray-800 dark:text-gray-200 mb-3">Price Range</h4>
        <div className="flex items-center gap-2 mb-3">
          <span className="text-xs text-gray-500">₹{priceRange[0]}</span>
          <input
            type="range"
            min="0"
            max="5000"
            step="100"
            value={priceRange[1]}
            onChange={(e) => setPriceRange([priceRange[0], Number(e.target.value)])}
            onMouseUp={handlePriceCommit}
            onTouchEnd={handlePriceCommit}
            className="flex-1 accent-pink-500"
          />
          <span className="text-xs text-gray-500">₹{priceRange[1]}</span>
        </div>
        <div className="flex gap-2">
          {[
            { label: 'Under ₹1000', min: 0, max: 1000 },
            { label: '₹1000-2000', min: 1000, max: 2000 },
            { label: 'Above ₹2000', min: 2000, max: 5000 },
          ].map((range) => (
            <button
              key={range.label}
              onClick={() => onChange({ minPrice: range.min, maxPrice: range.max })}
              className="text-xs px-2.5 py-1.5 rounded-full border border-pink-200 dark:border-pink-800 text-gray-600 dark:text-gray-300 hover:bg-pink-500 hover:text-white hover:border-pink-500 transition-colors"
            >
              {range.label}
            </button>
          ))}
        </div>
      </div>

      {/* Skin Type */}
      <div className="mb-6">
        <h4 className="font-semibold text-sm text-gray-800 dark:text-gray-200 mb-3">Skin Type</h4>
        <div className="flex flex-wrap gap-2">
          {skinTypes.map((type) => (
            <button
              key={type}
              onClick={() => onChange({ skinType: filters.skinType === type ? '' : type })}
              className={`text-xs px-3 py-1.5 rounded-full border transition-colors capitalize ${
                filters.skinType === type
                  ? 'bg-pink-500 text-white border-pink-500'
                  : 'border-pink-200 dark:border-pink-800 text-gray-600 dark:text-gray-300 hover:border-pink-400'
              }`}
            >
              {type}
            </button>
          ))}
        </div>
      </div>

      <button onClick={onClear} className="w-full text-sm font-medium text-pink-500 hover:text-pink-600 py-2 border border-pink-200 dark:border-pink-800 rounded-full hover:bg-pink-50 dark:hover:bg-pink-900/20 transition-colors">
        Clear All Filters
      </button>
    </div>
  )
}

export default ShopFilters
