import React from 'react'
import { FaChevronLeft, FaChevronRight } from 'react-icons/fa'

const Pagination = ({ page, pages, onChange }) => {
  if (pages <= 1) return null

  const getPageNumbers = () => {
    const numbers = []
    const maxVisible = 5
    let start = Math.max(1, page - Math.floor(maxVisible / 2))
    let end = Math.min(pages, start + maxVisible - 1)
    if (end - start < maxVisible - 1) start = Math.max(1, end - maxVisible + 1)
    for (let i = start; i <= end; i++) numbers.push(i)
    return numbers
  }

  return (
    <div className="flex items-center justify-center gap-2 mt-10">
      <button
        onClick={() => onChange(page - 1)}
        disabled={page === 1}
        className="w-10 h-10 rounded-full flex items-center justify-center border border-pink-200 dark:border-pink-800 text-gray-600 dark:text-gray-300 hover:bg-pink-500 hover:text-white hover:border-pink-500 transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
      >
        <FaChevronLeft size={12} />
      </button>

      {getPageNumbers()[0] > 1 && (
        <>
          <button onClick={() => onChange(1)} className="w-10 h-10 rounded-full flex items-center justify-center border border-pink-200 dark:border-pink-800 text-gray-600 dark:text-gray-300 hover:bg-pink-50 dark:hover:bg-pink-900/20 transition-colors text-sm">1</button>
          <span className="text-gray-400">...</span>
        </>
      )}

      {getPageNumbers().map((num) => (
        <button
          key={num}
          onClick={() => onChange(num)}
          className={`w-10 h-10 rounded-full flex items-center justify-center text-sm font-medium transition-colors ${
            num === page
              ? 'bg-pink-500 text-white shadow-glow'
              : 'border border-pink-200 dark:border-pink-800 text-gray-600 dark:text-gray-300 hover:bg-pink-50 dark:hover:bg-pink-900/20'
          }`}
        >
          {num}
        </button>
      ))}

      {getPageNumbers()[getPageNumbers().length - 1] < pages && (
        <>
          <span className="text-gray-400">...</span>
          <button onClick={() => onChange(pages)} className="w-10 h-10 rounded-full flex items-center justify-center border border-pink-200 dark:border-pink-800 text-gray-600 dark:text-gray-300 hover:bg-pink-50 dark:hover:bg-pink-900/20 transition-colors text-sm">{pages}</button>
        </>
      )}

      <button
        onClick={() => onChange(page + 1)}
        disabled={page === pages}
        className="w-10 h-10 rounded-full flex items-center justify-center border border-pink-200 dark:border-pink-800 text-gray-600 dark:text-gray-300 hover:bg-pink-500 hover:text-white hover:border-pink-500 transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
      >
        <FaChevronRight size={12} />
      </button>
    </div>
  )
}

export default Pagination
