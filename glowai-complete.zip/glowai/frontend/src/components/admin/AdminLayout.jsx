import React, { useState } from 'react'
import { Link, useLocation } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import {
  FaTachometerAlt, FaBoxOpen, FaShoppingCart, FaUsers, FaTags,
  FaStar, FaBars, FaTimes, FaArrowLeft, FaThLarge,
} from 'react-icons/fa'

const navItems = [
  { name: 'Dashboard', path: '/admin', icon: FaTachometerAlt },
  { name: 'Products', path: '/admin/products', icon: FaBoxOpen },
  { name: 'Categories', path: '/admin/categories', icon: FaThLarge },
  { name: 'Orders', path: '/admin/orders', icon: FaShoppingCart },
  { name: 'Users', path: '/admin/users', icon: FaUsers },
  { name: 'Coupons', path: '/admin/coupons', icon: FaTags },
  { name: 'Reviews', path: '/admin/reviews', icon: FaStar },
]

const AdminLayout = ({ children, title }) => {
  const location = useLocation()
  const [sidebarOpen, setSidebarOpen] = useState(false)

  return (
    <div className="min-h-screen flex bg-gray-50 dark:bg-[#0f0a0d]">
      {/* Sidebar */}
      <aside className="hidden lg:flex flex-col w-64 glass-card-solid border-r border-pink-100 dark:border-pink-900/30 flex-shrink-0">
        <SidebarContent location={location} />
      </aside>

      {/* Mobile sidebar */}
      <AnimatePresence>
        {sidebarOpen && (
          <div className="fixed inset-0 z-50 lg:hidden">
            <div className="absolute inset-0 bg-black/50" onClick={() => setSidebarOpen(false)} />
            <motion.aside initial={{ x: '-100%' }} animate={{ x: 0 }} exit={{ x: '-100%' }} className="absolute left-0 top-0 h-full w-64 bg-white dark:bg-gray-900 flex flex-col">
              <SidebarContent location={location} onClose={() => setSidebarOpen(false)} />
            </motion.aside>
          </div>
        )}
      </AnimatePresence>

      {/* Main content */}
      <div className="flex-1 min-w-0">
        <header className="glass-card-solid border-b border-pink-100 dark:border-pink-900/30 px-4 sm:px-6 py-4 flex items-center justify-between sticky top-0 z-30">
          <div className="flex items-center gap-3">
            <button onClick={() => setSidebarOpen(true)} className="btn-icon lg:hidden"><FaBars /></button>
            <h1 className="text-lg sm:text-xl font-display font-semibold text-gray-900 dark:text-white">{title}</h1>
          </div>
        </header>
        <main className="p-4 sm:p-6">{children}</main>
      </div>
    </div>
  )
}

const SidebarContent = ({ location, onClose }) => (
  <>
    <div className="p-5 border-b border-pink-100 dark:border-pink-900/30 flex items-center justify-between">
      <Link to="/" className="flex items-center gap-2">
        <div className="w-9 h-9 rounded-full bg-gradient-to-br from-pink-400 to-pink-600 flex items-center justify-center shadow-glow">
          <span className="text-white font-display font-bold text-lg">G</span>
        </div>
        <span className="text-lg font-display font-bold text-gradient">GlowAI Admin</span>
      </Link>
      {onClose && <button onClick={onClose} className="btn-icon"><FaTimes /></button>}
    </div>
    <nav className="flex-1 p-3 space-y-1 overflow-y-auto custom-scroll">
      {navItems.map((item) => {
        const isActive = location.pathname === item.path
        return (
          <Link
            key={item.path}
            to={item.path}
            onClick={onClose}
            className={`flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-colors ${
              isActive ? 'bg-pink-500 text-white shadow-glow' : 'text-gray-600 dark:text-gray-300 hover:bg-pink-50 dark:hover:bg-pink-900/20 hover:text-pink-500'
            }`}
          >
            <item.icon size={15} /> {item.name}
          </Link>
        )
      })}
    </nav>
    <div className="p-3 border-t border-pink-100 dark:border-pink-900/30">
      <Link to="/" className="flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium text-gray-500 hover:text-pink-500 hover:bg-pink-50 dark:hover:bg-pink-900/20 transition-colors">
        <FaArrowLeft size={14} /> Back to Store
      </Link>
    </div>
  </>
)

export default AdminLayout
