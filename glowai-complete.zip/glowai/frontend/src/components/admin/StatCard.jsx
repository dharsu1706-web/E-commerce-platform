import React from 'react'
import { FaArrowUp, FaArrowDown } from 'react-icons/fa'

const StatCard = ({ icon: Icon, label, value, growth, prefix = '' }) => {
  const isPositive = Number(growth) >= 0
  return (
    <div className="glass-card-solid rounded-2xl p-5">
      <div className="flex items-center justify-between mb-3">
        <div className="w-11 h-11 rounded-xl bg-pink-100 dark:bg-pink-900/30 flex items-center justify-center">
          <Icon className="text-pink-500" size={18} />
        </div>
        {growth !== undefined && (
          <span className={`text-xs font-semibold flex items-center gap-1 ${isPositive ? 'text-emerald-500' : 'text-red-500'}`}>
            {isPositive ? <FaArrowUp size={10} /> : <FaArrowDown size={10} />} {Math.abs(growth)}%
          </span>
        )}
      </div>
      <p className="text-2xl font-display font-bold text-gray-900 dark:text-white">{prefix}{value?.toLocaleString('en-IN')}</p>
      <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">{label}</p>
    </div>
  )
}

export default StatCard
