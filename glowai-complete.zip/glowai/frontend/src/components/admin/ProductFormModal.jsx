import React, { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { FaTimes, FaUpload, FaTrash } from 'react-icons/fa'
import toast from 'react-hot-toast'
import Button from '../common/Button'
import { productAPI, uploadAPI } from '../../services/api'

const emptyForm = {
  name: '', description: '', shortDescription: '', price: '', discountPrice: '',
  category: '', brand: '', stock: '', volume: '', howToUse: '',
  ingredients: '', benefits: '', tags: '', skinType: [], skinConcerns: '',
  isFeatured: false, isBestSeller: false, isTrending: false, isNew: false,
  images: [],
}

const skinTypeOptions = ['dry', 'oily', 'combination', 'sensitive', 'normal', 'all']

const ProductFormModal = ({ product, categories, onClose, onSaved }) => {
  const [form, setForm] = useState(emptyForm)
  const [saving, setSaving] = useState(false)
  const [uploading, setUploading] = useState(false)

  useEffect(() => {
    if (product) {
      setForm({
        ...emptyForm,
        ...product,
        category: product.category?._id || product.category || '',
        ingredients: product.ingredients?.join(', ') || '',
        benefits: product.benefits?.join(', ') || '',
        tags: product.tags?.join(', ') || '',
        skinConcerns: product.skinConcerns?.join(', ') || '',
        skinType: product.skinType || [],
      })
    }
  }, [product])

  const handleFileChange = async (e) => {
    const files = Array.from(e.target.files)
    if (!files.length) return
    setUploading(true)
    try {
      const formData = new FormData()
      files.forEach((f) => formData.append('images', f))
      const { data } = await uploadAPI.upload(formData)
      setForm((prev) => ({ ...prev, images: [...prev.images, ...data.images] }))
      toast.success('Images uploaded')
    } catch (err) {
      toast.error(err.response?.data?.message || 'Upload failed')
    } finally {
      setUploading(false)
    }
  }

  const removeImage = (idx) => {
    setForm((prev) => ({ ...prev, images: prev.images.filter((_, i) => i !== idx) }))
  }

  const toggleSkinType = (type) => {
    setForm((prev) => ({
      ...prev,
      skinType: prev.skinType.includes(type) ? prev.skinType.filter((t) => t !== type) : [...prev.skinType, type],
    }))
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setSaving(true)
    try {
      const payload = {
        ...form,
        price: Number(form.price),
        discountPrice: Number(form.discountPrice) || 0,
        stock: Number(form.stock),
        ingredients: form.ingredients.split(',').map((s) => s.trim()).filter(Boolean),
        benefits: form.benefits.split(',').map((s) => s.trim()).filter(Boolean),
        tags: form.tags.split(',').map((s) => s.trim()).filter(Boolean),
        skinConcerns: form.skinConcerns.split(',').map((s) => s.trim()).filter(Boolean),
      }

      if (product) {
        const { data } = await productAPI.update(product._id, payload)
        toast.success(data.message)
      } else {
        const { data } = await productAPI.create(payload)
        toast.success(data.message)
      }
      onSaved()
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to save product')
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/50" onClick={onClose} />
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="relative bg-white dark:bg-gray-900 rounded-3xl w-full max-w-3xl max-h-[90vh] overflow-y-auto custom-scroll p-6 sm:p-8"
      >
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-display font-semibold text-gray-900 dark:text-white">{product ? 'Edit Product' : 'Add New Product'}</h2>
          <button onClick={onClose} className="btn-icon"><FaTimes /></button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid sm:grid-cols-2 gap-4">
            <input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Product Name" className="input-field sm:col-span-2" />
            <input required value={form.brand} onChange={(e) => setForm({ ...form, brand: e.target.value })} placeholder="Brand" className="input-field" />
            <select required value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} className="input-field">
              <option value="">Select Category</option>
              {categories.map((c) => <option key={c._id} value={c._id}>{c.name}</option>)}
            </select>
            <input required type="number" value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} placeholder="Price (₹)" className="input-field" />
            <input type="number" value={form.discountPrice} onChange={(e) => setForm({ ...form, discountPrice: e.target.value })} placeholder="Discount Price (₹) - optional" className="input-field" />
            <input required type="number" value={form.stock} onChange={(e) => setForm({ ...form, stock: e.target.value })} placeholder="Stock Quantity" className="input-field" />
            <input value={form.volume} onChange={(e) => setForm({ ...form, volume: e.target.value })} placeholder="Volume (e.g. 30ml)" className="input-field" />
          </div>

          <textarea required value={form.shortDescription} onChange={(e) => setForm({ ...form, shortDescription: e.target.value })} placeholder="Short Description" className="input-field" />
          <textarea required value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="Full Description" className="input-field min-h-[100px]" />
          <textarea value={form.howToUse} onChange={(e) => setForm({ ...form, howToUse: e.target.value })} placeholder="How to use" className="input-field" />

          <input value={form.ingredients} onChange={(e) => setForm({ ...form, ingredients: e.target.value })} placeholder="Ingredients (comma separated)" className="input-field" />
          <input value={form.benefits} onChange={(e) => setForm({ ...form, benefits: e.target.value })} placeholder="Benefits (comma separated)" className="input-field" />
          <input value={form.tags} onChange={(e) => setForm({ ...form, tags: e.target.value })} placeholder="Tags (comma separated, e.g. vitamin-c, brightening)" className="input-field" />
          <input value={form.skinConcerns} onChange={(e) => setForm({ ...form, skinConcerns: e.target.value })} placeholder="Skin Concerns (comma separated)" className="input-field" />

          {/* Skin types */}
          <div>
            <label className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2 block">Suitable Skin Types</label>
            <div className="flex flex-wrap gap-2">
              {skinTypeOptions.map((type) => (
                <button
                  key={type}
                  type="button"
                  onClick={() => toggleSkinType(type)}
                  className={`text-xs px-3 py-1.5 rounded-full border capitalize transition-colors ${form.skinType.includes(type) ? 'bg-pink-500 text-white border-pink-500' : 'border-pink-200 dark:border-pink-800 text-gray-600 dark:text-gray-300'}`}
                >
                  {type}
                </button>
              ))}
            </div>
          </div>

          {/* Flags */}
          <div className="flex flex-wrap gap-4">
            {['isFeatured', 'isBestSeller', 'isTrending', 'isNew'].map((flag) => (
              <label key={flag} className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-300 cursor-pointer">
                <input type="checkbox" checked={form[flag]} onChange={(e) => setForm({ ...form, [flag]: e.target.checked })} className="text-pink-500 rounded focus:ring-pink-400" />
                {flag.replace('is', '').replace(/([A-Z])/g, ' $1').trim()}
              </label>
            ))}
          </div>

          {/* Images */}
          <div>
            <label className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2 block">Product Images</label>
            <div className="flex flex-wrap gap-3 mb-3">
              {form.images.map((img, i) => (
                <div key={i} className="relative w-20 h-20 rounded-xl overflow-hidden group">
                  <img src={img.url} alt={`Product ${i}`} className="w-full h-full object-cover" />
                  <button type="button" onClick={() => removeImage(i)} className="absolute inset-0 bg-black/50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity text-white">
                    <FaTrash size={14} />
                  </button>
                </div>
              ))}
              <label className="w-20 h-20 rounded-xl border-2 border-dashed border-pink-300 flex items-center justify-center cursor-pointer hover:bg-pink-50 dark:hover:bg-pink-900/20 transition-colors">
                {uploading ? <span className="text-xs text-pink-500">...</span> : <FaUpload className="text-pink-400" />}
                <input type="file" accept="image/*" multiple onChange={handleFileChange} className="hidden" disabled={uploading} />
              </label>
            </div>
            <p className="text-xs text-gray-400">Or images already include a default Unsplash URL for testing if none uploaded.</p>
          </div>

          <div className="flex gap-3 pt-4">
            <Button type="submit" variant="primary" loading={saving}>{product ? 'Update Product' : 'Create Product'}</Button>
            <Button type="button" variant="ghost" onClick={onClose}>Cancel</Button>
          </div>
        </form>
      </motion.div>
    </div>
  )
}

export default ProductFormModal
