import React from 'react'
import { Navigate, useLocation } from 'react-router-dom'
import { useAuth } from '../../context/AuthContext'
import { PageLoader } from '../common/Loaders'

export const ProtectedRoute = ({ children }) => {
  const { isAuthenticated, initialLoading } = useAuth()
  const location = useLocation()

  if (initialLoading) return <PageLoader />
  if (!isAuthenticated) return <Navigate to="/login" state={{ from: location }} replace />
  return children
}

export const AdminRoute = ({ children }) => {
  const { isAuthenticated, isAdmin, initialLoading } = useAuth()
  const location = useLocation()

  if (initialLoading) return <PageLoader />
  if (!isAuthenticated) return <Navigate to="/login" state={{ from: location }} replace />
  if (!isAdmin) return <Navigate to="/" replace />
  return children
}

export const GuestRoute = ({ children }) => {
  const { isAuthenticated, initialLoading } = useAuth()
  if (initialLoading) return <PageLoader />
  if (isAuthenticated) return <Navigate to="/" replace />
  return children
}
