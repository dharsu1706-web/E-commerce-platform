import React, { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'

const ProductGallery = ({ images = [] }) => {
  const [activeIndex, setActiveIndex] = useState(0)
  const safeImages = images.length > 0 ? images : [{ url: 'https://via.placeholder.com/600x600?text=GlowAI' }]

  return (
    <div>
      <div className="relative aspect-square rounded-2xl overflow-hidden glass-card-solid mb-4">
        <AnimatePresence mode="wait">
          <motion.img
            key={activeIndex}
            src={safeImages[activeIndex]?.url}
            alt="Product"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="w-full h-full object-cover"
          />
        </AnimatePresence>
      </div>

      {safeImages.length > 1 && (
        <div className="flex gap-3 overflow-x-auto custom-scroll pb-1">
          {safeImages.map((img, i) => (
            <button
              key={i}
              onClick={() => setActiveIndex(i)}
              className={`flex-shrink-0 w-16 h-16 sm:w-20 sm:h-20 rounded-xl overflow-hidden border-2 transition-colors ${
                activeIndex === i ? 'border-pink-500' : 'border-transparent opacity-70 hover:opacity-100'
              }`}
            >
              <img src={img.url} alt={`Thumbnail ${i + 1}`} className="w-full h-full object-cover" />
            </button>
          ))}
        </div>
      )}
    </div>
  )
}

export default ProductGallery
