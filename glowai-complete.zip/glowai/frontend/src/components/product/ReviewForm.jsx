import React, { useState } from 'react'
import { FaStar } from 'react-icons/fa'
import toast from 'react-hot-toast'
import { useAuth } from '../../context/AuthContext'
import { reviewAPI } from '../../services/api'
import Button from '../common/Button'

const ReviewForm = ({ productId, onSubmit }) => {
  const { isAuthenticated } = useAuth()
  const [rating, setRating] = useState(0)
  const [hoverRating, setHoverRating] = useState(0)
  const [title, setTitle] = useState('')
  const [comment, setComment] = useState('')
  const [loading, setLoading] = useState(false)
  const [showForm, setShowForm] = useState(false)

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (rating === 0) {
      toast.error('Please select a rating')
      return
    }
    setLoading(true)
    try {
      const { data } = await reviewAPI.create({ product: productId, rating, title, comment })
      toast.success(data.message)
      setRating(0)
      setTitle('')
      setComment('')
      setShowForm(false)
      onSubmit?.(data.review)
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to submit review')
    } finally {
      setLoading(false)
    }
  }

  if (!isAuthenticated) {
    return (
      <div className="glass-card-solid rounded-2xl p-6 text-center mb-6">
        <p className="text-gray-600 dark:text-gray-300">Please <a href="/login" className="text-pink-500 font-semibold hover:underline">login</a> to write a review.</p>
      </div>
    )
  }

  if (!showForm) {
    return (
      <button onClick={() => setShowForm(true)} className="mb-6 btn-secondary text-sm">
        Write a Review
      </button>
    )
  }

  return (
    <form onSubmit={handleSubmit} className="glass-card-solid rounded-2xl p-6 mb-6 space-y-4">
      <h4 className="font-display font-semibold text-gray-800 dark:text-white">Write a Review</h4>

      <div className="flex items-center gap-2">
        {[1, 2, 3, 4, 5].map((star) => (
          <button
            key={star}
            type="button"
            onClick={() => setRating(star)}
            onMouseEnter={() => setHoverRating(star)}
            onMouseLeave={() => setHoverRating(0)}
          >
            <FaStar
              size={24}
              className={(hoverRating || rating) >= star ? 'text-amber-400' : 'text-gray-300 dark:text-gray-600'}
            />
          </button>
        ))}
      </div>

      <input
        type="text"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        placeholder="Review title (e.g. 'Amazing product!')"
        className="input-field"
        required
        maxLength={100}
      />

      <textarea
        value={comment}
        onChange={(e) => setComment(e.target.value)}
        placeholder="Share your experience with this product..."
        className="input-field min-h-[100px] resize-none"
        required
        maxLength={1000}
      />

      <div className="flex gap-3">
        <Button type="submit" variant="primary" loading={loading}>Submit Review</Button>
        <Button type="button" variant="ghost" onClick={() => setShowForm(false)}>Cancel</Button>
      </div>
    </form>
  )
}

export default ReviewForm
