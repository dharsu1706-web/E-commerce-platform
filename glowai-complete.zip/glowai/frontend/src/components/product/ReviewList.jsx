import React from 'react'
import { FaCheckCircle } from 'react-icons/fa'
import StarRating from '../common/StarRating'
import EmptyState from '../common/EmptyState'
import { FaCommentAlt } from 'react-icons/fa'

const ReviewList = ({ reviews = [] }) => {
  if (reviews.length === 0) {
    return (
      <EmptyState
        icon={FaCommentAlt}
        title="No reviews yet"
        message="Be the first to share your experience with this product!"
      />
    )
  }

  return (
    <div className="space-y-4">
      {reviews.map((review) => (
        <div key={review._id} className="glass-card-solid rounded-2xl p-5">
          <div className="flex items-start gap-3 mb-2">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-pink-300 to-pink-500 flex items-center justify-center text-white font-semibold flex-shrink-0">
              {review.user?.name?.charAt(0).toUpperCase() || 'U'}
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2 flex-wrap">
                <p className="font-semibold text-sm text-gray-800 dark:text-white">{review.user?.name || 'Anonymous'}</p>
                {review.isVerifiedPurchase && (
                  <span className="badge-green text-[10px]"><FaCheckCircle size={9} /> Verified Purchase</span>
                )}
              </div>
              <StarRating rating={review.rating} size={12} className="mt-1" />
            </div>
            <span className="text-xs text-gray-400 flex-shrink-0">{new Date(review.createdAt).toLocaleDateString()}</span>
          </div>
          <h5 className="font-medium text-sm text-gray-800 dark:text-gray-100 mb-1">{review.title}</h5>
          <p className="text-sm text-gray-600 dark:text-gray-300 leading-relaxed">{review.comment}</p>
        </div>
      ))}
    </div>
  )
}

export default ReviewList
