import React, { useState } from 'react'
import { FaCheckCircle } from 'react-icons/fa'
import StarRating from '../common/StarRating'
import ReviewForm from './ReviewForm'
import ReviewList from './ReviewList'

const ProductTabs = ({ product, reviews, onReviewSubmit }) => {
  const [activeTab, setActiveTab] = useState('description')

  const tabs = [
    { id: 'description', label: 'Description' },
    { id: 'ingredients', label: 'Ingredients' },
    { id: 'benefits', label: 'Benefits' },
    { id: 'reviews', label: `Reviews (${reviews.length})` },
  ]

  return (
    <div className="mt-12">
      {/* Tab headers */}
      <div className="flex gap-1 overflow-x-auto custom-scroll border-b border-pink-100 dark:border-pink-900/30 mb-6">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`px-4 sm:px-6 py-3 text-sm font-medium whitespace-nowrap border-b-2 transition-colors ${
              activeTab === tab.id
                ? 'border-pink-500 text-pink-500'
                : 'border-transparent text-gray-500 dark:text-gray-400 hover:text-pink-400'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Tab content */}
      <div className="min-h-[150px]">
        {activeTab === 'description' && (
          <div className="prose prose-sm dark:prose-invert max-w-none">
            <p className="text-gray-600 dark:text-gray-300 leading-relaxed">{product.description}</p>
            {product.howToUse && (
              <div className="mt-6 glass-card-solid rounded-2xl p-5">
                <h4 className="font-display font-semibold text-gray-800 dark:text-white mb-2">How to Use</h4>
                <p className="text-gray-600 dark:text-gray-300 text-sm">{product.howToUse}</p>
              </div>
            )}
          </div>
        )}

        {activeTab === 'ingredients' && (
          <div>
            <h4 className="font-display font-semibold text-gray-800 dark:text-white mb-4">Key Ingredients</h4>
            {product.ingredients?.length > 0 ? (
              <div className="grid sm:grid-cols-2 gap-3">
                {product.ingredients.map((ing, i) => (
                  <div key={i} className="flex items-center gap-3 glass-card-solid rounded-xl p-3">
                    <div className="w-2 h-2 rounded-full bg-pink-400 flex-shrink-0" />
                    <span className="text-sm text-gray-700 dark:text-gray-300">{ing}</span>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-gray-500">No ingredient information available.</p>
            )}
          </div>
        )}

        {activeTab === 'benefits' && (
          <div>
            <h4 className="font-display font-semibold text-gray-800 dark:text-white mb-4">Key Benefits</h4>
            {product.benefits?.length > 0 ? (
              <div className="grid sm:grid-cols-2 gap-3">
                {product.benefits.map((benefit, i) => (
                  <div key={i} className="flex items-start gap-3 glass-card-solid rounded-xl p-4">
                    <FaCheckCircle className="text-pink-500 mt-0.5 flex-shrink-0" />
                    <span className="text-sm text-gray-700 dark:text-gray-300">{benefit}</span>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-gray-500">No benefit information available.</p>
            )}
          </div>
        )}

        {activeTab === 'reviews' && (
          <div>
            <div className="flex items-center gap-4 mb-6 glass-card-solid rounded-2xl p-6">
              <div className="text-center">
                <p className="text-4xl font-display font-bold text-gray-900 dark:text-white">{product.ratings?.toFixed(1) || '0.0'}</p>
                <StarRating rating={product.ratings} size={14} className="justify-center mt-1" />
                <p className="text-xs text-gray-500 mt-1">{product.numReviews} reviews</p>
              </div>
            </div>
            <ReviewForm productId={product._id} onSubmit={onReviewSubmit} />
            <ReviewList reviews={reviews} />
          </div>
        )}
      </div>
    </div>
  )
}

export default ProductTabs
