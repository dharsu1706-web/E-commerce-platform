import React from 'react'
import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import { FaArrowRight } from 'react-icons/fa'
import ProductCard from '../common/ProductCard'
import { ProductGridSkeleton } from '../common/Loaders'

const ProductSection = ({ title, subtitle, products = [], loading, viewAllLink, badge, bgClass = '' }) => {
  return (
    <section className={`py-12 lg:py-16 ${bgClass}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-8 flex-wrap gap-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            {badge && <span className="badge-pink mb-2">{badge}</span>}
            <h2 className="section-heading mt-2">{title}</h2>
            {subtitle && <p className="text-gray-500 dark:text-gray-400 mt-1">{subtitle}</p>}
          </motion.div>
          {viewAllLink && (
            <Link to={viewAllLink} className="flex items-center gap-2 text-pink-500 font-semibold hover:gap-3 transition-all text-sm">
              View All <FaArrowRight size={12} />
            </Link>
          )}
        </div>

        {loading ? (
          <ProductGridSkeleton count={4} />
        ) : products.length === 0 ? (
          <p className="text-center text-gray-400 py-8">No products available right now.</p>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
            {products.map((p, i) => <ProductCard key={p._id} product={p} index={i} />)}
          </div>
        )}
      </div>
    </section>
  )
}

export default ProductSection
