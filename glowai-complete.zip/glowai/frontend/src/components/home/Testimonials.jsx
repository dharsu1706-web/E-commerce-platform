import React from 'react'
import { motion } from 'framer-motion'
import { FaQuoteLeft } from 'react-icons/fa'
import StarRating from '../common/StarRating'

const testimonials = [
  {
    name: 'Priya Sharma',
    role: 'Verified Buyer',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&q=80',
    rating: 5,
    text: "The AI quiz recommended the Vitamin C serum and Hyaluronic Acid combo — my skin has never looked better! Dark spots have visibly faded in just a month.",
  },
  {
    name: 'Ananya Reddy',
    role: 'Skincare Enthusiast',
    avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&q=80',
    rating: 5,
    text: "GlowAI's chatbot is like having a dermatologist in my pocket. It suggested a routine for my acne-prone skin and I've seen incredible results.",
  },
  {
    name: 'Meera Iyer',
    role: 'Verified Buyer',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&q=80',
    rating: 4,
    text: "Love the packaging, the quality, and especially the personalized recommendations. The Ceramide moisturizer is a holy grail for my dry skin!",
  },
  {
    name: 'Kavya Nair',
    role: 'Beauty Blogger',
    avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&q=80',
    rating: 5,
    text: "As someone who reviews dozens of beauty brands, GlowAI stands out. The premium feel, the AI personalization — it's next level.",
  },
];

const Testimonials = () => {
  return (
    <section className="py-16 lg:py-24 bg-pink-50/50 dark:bg-pink-950/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="section-heading"
          >
            Loved by Thousands
          </motion.h2>
          <p className="section-subheading mx-auto">
            Real stories from our glowing community
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {testimonials.map((t, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: i * 0.1 }}
              className="glass-card-solid rounded-2xl p-6 flex flex-col"
            >
              <FaQuoteLeft className="text-pink-300 mb-3" size={20} />
              <p className="text-sm text-gray-600 dark:text-gray-300 flex-1 mb-4 leading-relaxed">{t.text}</p>
              <StarRating rating={t.rating} size={13} className="mb-3" />
              <div className="flex items-center gap-3">
                <img src={t.avatar} alt={t.name} className="w-10 h-10 rounded-full object-cover" />
                <div>
                  <p className="font-semibold text-sm text-gray-800 dark:text-white">{t.name}</p>
                  <p className="text-xs text-gray-400">{t.role}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

export default Testimonials
