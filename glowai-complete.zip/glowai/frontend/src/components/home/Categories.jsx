import React from 'react'
import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'

const Categories = ({ categories = [] }) => {
  if (!categories.length) return null

  return (
    <section className="py-16 lg:py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="section-heading"
          >
            Shop by Category
          </motion.h2>
          <p className="section-subheading mx-auto">
            Explore our curated collection of premium skincare essentials
          </p>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-4">
          {categories.map((cat, i) => (
            <motion.div
              key={cat._id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: i * 0.05 }}
            >
              <Link
                to={`/shop?category=${cat._id}`}
                className="flex flex-col items-center gap-3 p-4 rounded-2xl glass-card-solid hover:shadow-card-hover hover:-translate-y-1 transition-all duration-300 group"
              >
                <div className="w-14 h-14 rounded-full bg-gradient-to-br from-pink-100 to-pink-200 dark:from-pink-900/40 dark:to-pink-800/40 flex items-center justify-center text-2xl group-hover:scale-110 transition-transform">
                  {cat.icon || '✨'}
                </div>
                <div className="text-center">
                  <p className="text-sm font-medium text-gray-800 dark:text-gray-100 group-hover:text-pink-500 transition-colors">{cat.name}</p>
                  <p className="text-xs text-gray-400">{cat.productCount || 0} items</p>
                </div>
              </Link>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

export default Categories
