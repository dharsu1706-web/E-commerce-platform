import React from 'react'
import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import { FaMagic, FaArrowRight, FaBrain, FaLeaf, FaHeart } from 'react-icons/fa'
import Button from '../common/Button'

const features = [
  { icon: FaBrain, title: 'AI Skin Analysis', text: 'Get personalized recommendations based on your unique skin profile' },
  { icon: FaLeaf, title: 'Curated Ingredients', text: 'Only the most effective, dermatologist-approved formulas' },
  { icon: FaHeart, title: 'Tailored Routines', text: 'Morning and evening routines designed just for you' },
]

const AIBanner = () => {
  return (
    <section className="py-16 lg:py-24 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          className="relative rounded-3xl overflow-hidden bg-gradient-to-br from-pink-500 via-pink-600 to-rose-600 p-8 sm:p-12 lg:p-16"
        >
          {/* Decorative elements */}
          <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full blur-3xl" />
          <div className="absolute bottom-0 left-0 w-64 h-64 bg-white/10 rounded-full blur-3xl" />

          <div className="relative grid lg:grid-cols-2 gap-10 items-center">
            <div>
              <div className="inline-flex items-center gap-2 bg-white/20 px-4 py-2 rounded-full mb-6">
                <FaMagic className="text-white" size={14} />
                <span className="text-sm font-medium text-white">Powered by Artificial Intelligence</span>
              </div>
              <h2 className="text-3xl sm:text-4xl lg:text-5xl font-display font-bold text-white mb-4">
                Meet Your Personal AI Beauty Assistant
              </h2>
              <p className="text-pink-100 text-lg mb-8 max-w-lg">
                Take our smart skin quiz or chat with GlowAI Assistant to discover products perfectly matched to your skin type, concerns, and goals.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link to="/skin-quiz">
                  <Button variant="dark" size="lg" icon={FaArrowRight}>Take the Skin Quiz</Button>
                </Link>
              </div>
            </div>

            <div className="grid gap-4">
              {features.map((f, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: 30 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.4, delay: i * 0.1 }}
                  className="flex items-start gap-4 bg-white/10 backdrop-blur-md rounded-2xl p-5 border border-white/20"
                >
                  <div className="w-12 h-12 rounded-xl bg-white/20 flex items-center justify-center flex-shrink-0">
                    <f.icon className="text-white" size={20} />
                  </div>
                  <div>
                    <h3 className="text-white font-semibold mb-1">{f.title}</h3>
                    <p className="text-pink-100 text-sm">{f.text}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  )
}

export default AIBanner
