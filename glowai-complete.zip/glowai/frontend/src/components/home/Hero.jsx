import React from 'react'
import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import { FaArrowRight, FaMagic, FaStar } from 'react-icons/fa'
import Button from '../common/Button'

const Hero = () => {
  return (
    <section className="relative overflow-hidden bg-gradient-hero pt-10 pb-20 lg:pt-16 lg:pb-32">
      {/* Decorative blobs */}
      <div className="absolute top-0 right-0 w-72 h-72 bg-pink-300/30 rounded-full blur-3xl animate-float" />
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-rose-300/20 rounded-full blur-3xl animate-float" style={{ animationDelay: '1s' }} />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left content */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center lg:text-left"
          >
            <div className="inline-flex items-center gap-2 glass-card-solid px-4 py-2 rounded-full mb-6">
              <FaMagic className="text-pink-500" size={14} />
              <span className="text-sm font-medium text-pink-600 dark:text-pink-400">AI-Powered Beauty Recommendations</span>
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-display font-bold leading-tight text-gray-900 dark:text-white mb-6">
              Discover Your <span className="text-gradient-rose italic">Perfect Glow</span> with AI
            </h1>

            <p className="text-lg text-gray-600 dark:text-gray-300 max-w-lg mx-auto lg:mx-0 mb-8">
              Premium skincare and beauty products curated by intelligent AI to match your unique skin type, concerns, and goals. Radiance starts here.
            </p>

            <div className="flex flex-col sm:flex-row items-center gap-4 justify-center lg:justify-start">
              <Link to="/shop">
                <Button variant="primary" size="lg" icon={FaArrowRight}>Shop Now</Button>
              </Link>
              <Link to="/skin-quiz">
                <Button variant="secondary" size="lg" icon={FaMagic}>Take Skin Quiz</Button>
              </Link>
            </div>

            {/* Trust stats */}
            <div className="flex items-center justify-center lg:justify-start gap-8 mt-10">
              <div className="text-center lg:text-left">
                <p className="text-2xl font-display font-bold text-gray-900 dark:text-white">50K+</p>
                <p className="text-sm text-gray-500 dark:text-gray-400">Happy Customers</p>
              </div>
              <div className="w-px h-10 bg-gray-300 dark:bg-gray-700" />
              <div className="text-center lg:text-left">
                <div className="flex items-center gap-1 justify-center lg:justify-start">
                  <p className="text-2xl font-display font-bold text-gray-900 dark:text-white">4.8</p>
                  <FaStar className="text-amber-400" />
                </div>
                <p className="text-sm text-gray-500 dark:text-gray-400">Average Rating</p>
              </div>
              <div className="w-px h-10 bg-gray-300 dark:bg-gray-700" />
              <div className="text-center lg:text-left">
                <p className="text-2xl font-display font-bold text-gray-900 dark:text-white">100+</p>
                <p className="text-sm text-gray-500 dark:text-gray-400">Premium Products</p>
              </div>
            </div>
          </motion.div>

          {/* Right image */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="relative"
          >
            <div className="relative aspect-square max-w-lg mx-auto">
              <div className="absolute inset-0 bg-gradient-to-br from-pink-200 to-rose-200 dark:from-pink-900/40 dark:to-rose-900/40 rounded-full blur-2xl" />
              <img
                src="https://images.unsplash.com/photo-1571781926291-c477ebfd024b?w=800&q=80"
                alt="GlowAI Premium Skincare"
                className="relative w-full h-full object-cover rounded-[2.5rem] shadow-2xl"
              />
              {/* Floating glass card */}
              <motion.div
                animate={{ y: [0, -15, 0] }}
                transition={{ duration: 3, repeat: Infinity, ease: 'easeInOut' }}
                className="absolute -bottom-6 -left-6 glass-card-solid rounded-2xl p-4 shadow-card-hover"
              >
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-pink-400 to-pink-600 flex items-center justify-center">
                    <FaMagic className="text-white" size={18} />
                  </div>
                  <div>
                    <p className="font-semibold text-gray-800 dark:text-white text-sm">AI Skin Analysis</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">Personalized for you</p>
                  </div>
                </div>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}

export default Hero
