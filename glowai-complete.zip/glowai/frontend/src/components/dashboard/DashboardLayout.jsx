import React from 'react'
import { Link, useLocation } from 'react-router-dom'
import { FaUser, FaBoxOpen, FaHeart, FaLock, FaMapMarkerAlt } from 'react-icons/fa'

const navItems = [
  { name: 'Overview', path: '/dashboard', icon: FaUser },
  { name: 'My Orders', path: '/dashboard/orders', icon: FaBoxOpen },
  { name: 'Wishlist', path: '/dashboard/wishlist', icon: FaHeart },
  { name: 'Addresses', path: '/dashboard/addresses', icon: FaMapMarkerAlt },
  { name: 'Change Password', path: '/dashboard/password', icon: FaLock },
]

const DashboardLayout = ({ children, title }) => {
  const location = useLocation()

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h1 className="section-heading mb-8">{title || 'My Account'}</h1>
      <div className="flex flex-col lg:flex-row gap-8">
        <aside className="lg:w-64 flex-shrink-0">
          <div className="glass-card-solid rounded-2xl p-3 flex lg:flex-col gap-1 overflow-x-auto lg:overflow-visible">
            {navItems.map((item) => {
              const isActive = location.pathname === item.path
              return (
                <Link
                  key={item.path}
                  to={item.path}
                  className={`flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium whitespace-nowrap transition-colors ${
                    isActive
                      ? 'bg-pink-500 text-white shadow-glow'
                      : 'text-gray-600 dark:text-gray-300 hover:bg-pink-50 dark:hover:bg-pink-900/20 hover:text-pink-500'
                  }`}
                >
                  <item.icon size={15} /> {item.name}
                </Link>
              )
            })}
          </div>
        </aside>
        <div className="flex-1 min-w-0">{children}</div>
      </div>
    </div>
  )
}

export default DashboardLayout
