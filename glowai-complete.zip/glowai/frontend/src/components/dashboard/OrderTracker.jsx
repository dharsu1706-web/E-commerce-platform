import React from 'react'
import { FaClipboardCheck, FaCog, FaTruck, FaHome, FaTimesCircle } from 'react-icons/fa'

const steps = [
  { key: 'pending', label: 'Order Placed', icon: FaClipboardCheck },
  { key: 'processing', label: 'Processing', icon: FaCog },
  { key: 'shipped', label: 'Shipped', icon: FaTruck },
  { key: 'delivered', label: 'Delivered', icon: FaHome },
]

const OrderTracker = ({ status }) => {
  if (status === 'cancelled' || status === 'refunded') {
    return (
      <div className="flex items-center gap-3 text-red-500 glass-card-solid rounded-2xl p-5">
        <FaTimesCircle size={24} />
        <div>
          <p className="font-semibold capitalize">{status}</p>
          <p className="text-sm text-gray-500 dark:text-gray-400">This order has been {status}.</p>
        </div>
      </div>
    )
  }

  const currentIndex = steps.findIndex((s) => s.key === status)

  return (
    <div className="glass-card-solid rounded-2xl p-6">
      <div className="flex items-center justify-between relative">
        <div className="absolute top-5 left-0 right-0 h-0.5 bg-gray-200 dark:bg-gray-700 -z-0" />
        <div
          className="absolute top-5 left-0 h-0.5 bg-pink-500 transition-all duration-500 -z-0"
          style={{ width: `${(currentIndex / (steps.length - 1)) * 100}%` }}
        />
        {steps.map((step, i) => {
          const isActive = i <= currentIndex
          return (
            <div key={step.key} className="flex flex-col items-center gap-2 relative z-10 flex-1">
              <div className={`w-10 h-10 rounded-full flex items-center justify-center transition-colors ${isActive ? 'bg-pink-500 text-white shadow-glow' : 'bg-gray-100 dark:bg-gray-700 text-gray-400'}`}>
                <step.icon size={16} />
              </div>
              <span className={`text-xs font-medium text-center ${isActive ? 'text-pink-500' : 'text-gray-400'}`}>{step.label}</span>
            </div>
          )
        })}
      </div>
    </div>
  )
}

export default OrderTracker
