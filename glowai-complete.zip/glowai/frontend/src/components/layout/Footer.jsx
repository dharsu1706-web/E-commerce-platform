import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import { FaInstagram, FaFacebookF, FaTwitter, FaPinterestP, FaYoutube, FaPaperPlane, FaMapMarkerAlt, FaPhoneAlt, FaEnvelope } from 'react-icons/fa'
import toast from 'react-hot-toast'
import { newsletterAPI } from '../../services/api'
import Button from '../common/Button'

const Footer = () => {
  const [email, setEmail] = useState('')
  const [loading, setLoading] = useState(false)

  const handleSubscribe = async (e) => {
    e.preventDefault()
    if (!email.trim()) return
    setLoading(true)
    try {
      const { data } = await newsletterAPI.subscribe(email)
      toast.success(data.message)
      setEmail('')
    } catch (err) {
      toast.error(err.response?.data?.message || 'Subscription failed')
    } finally {
      setLoading(false)
    }
  }

  return (
    <footer className="bg-gray-900 dark:bg-[#0a0508] text-gray-300 mt-20">
      {/* Newsletter */}
      <div className="border-b border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="flex flex-col lg:flex-row items-center justify-between gap-6">
            <div className="text-center lg:text-left">
              <h3 className="text-2xl font-display font-semibold text-white mb-2">Join the GlowAI Community 🌸</h3>
              <p className="text-gray-400 max-w-md">Get exclusive offers, beauty tips, and early access to new launches.</p>
            </div>
            <form onSubmit={handleSubscribe} className="flex w-full lg:w-auto max-w-md gap-2">
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter your email"
                className="flex-1 px-4 py-3 rounded-full bg-gray-800 border border-gray-700 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-pink-500/50"
                required
              />
              <Button type="submit" variant="primary" loading={loading} icon={FaPaperPlane}>
                <span className="hidden sm:inline">Subscribe</span>
              </Button>
            </form>
          </div>
        </div>
      </div>

      {/* Main footer */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-10">
          {/* Brand */}
          <div className="lg:col-span-2">
            <Link to="/" className="flex items-center gap-2 mb-4">
              <div className="w-9 h-9 rounded-full bg-gradient-to-br from-pink-400 to-pink-600 flex items-center justify-center shadow-glow">
                <span className="text-white font-display font-bold text-lg">G</span>
              </div>
              <span className="text-xl font-display font-bold text-gradient-rose">GlowAI</span>
            </Link>
            <p className="text-gray-400 text-sm leading-relaxed mb-4 max-w-sm">
              Premium AI-powered skincare and beauty platform. Discover products tailored to your unique skin with intelligent recommendations and expert-curated formulas.
            </p>
            <div className="flex gap-3">
              {[FaInstagram, FaFacebookF, FaTwitter, FaPinterestP, FaYoutube].map((Icon, i) => (
                <a key={i} href="#" className="w-9 h-9 rounded-full bg-gray-800 hover:bg-pink-500 flex items-center justify-center transition-colors">
                  <Icon size={14} />
                </a>
              ))}
            </div>
          </div>

          {/* Shop links */}
          <div>
            <h4 className="text-white font-semibold mb-4">Shop</h4>
            <ul className="space-y-2.5 text-sm">
              <li><Link to="/shop" className="hover:text-pink-400 transition-colors">All Products</Link></li>
              <li><Link to="/shop?bestSeller=true" className="hover:text-pink-400 transition-colors">Best Sellers</Link></li>
              <li><Link to="/shop?trending=true" className="hover:text-pink-400 transition-colors">Trending</Link></li>
              <li><Link to="/shop?isNew=true" className="hover:text-pink-400 transition-colors">New Arrivals</Link></li>
              <li><Link to="/skin-quiz" className="hover:text-pink-400 transition-colors">Skin Quiz</Link></li>
            </ul>
          </div>

          {/* Company links */}
          <div>
            <h4 className="text-white font-semibold mb-4">Company</h4>
            <ul className="space-y-2.5 text-sm">
              <li><Link to="/about" className="hover:text-pink-400 transition-colors">About Us</Link></li>
              <li><Link to="/contact" className="hover:text-pink-400 transition-colors">Contact</Link></li>
              <li><Link to="/faq" className="hover:text-pink-400 transition-colors">FAQ</Link></li>
              <li><Link to="/privacy-policy" className="hover:text-pink-400 transition-colors">Privacy Policy</Link></li>
              <li><Link to="/terms" className="hover:text-pink-400 transition-colors">Terms of Service</Link></li>
            </ul>
          </div>

          {/* Contact info */}
          <div>
            <h4 className="text-white font-semibold mb-4">Get in Touch</h4>
            <ul className="space-y-3 text-sm">
              <li className="flex items-start gap-3">
                <FaMapMarkerAlt className="text-pink-400 mt-1 flex-shrink-0" />
                <span>123 Beauty Lane, Mumbai, Maharashtra, India 400001</span>
              </li>
              <li className="flex items-center gap-3">
                <FaPhoneAlt className="text-pink-400 flex-shrink-0" />
                <span>+91 98765 43210</span>
              </li>
              <li className="flex items-center gap-3">
                <FaEnvelope className="text-pink-400 flex-shrink-0" />
                <span>hello@glowai.com</span>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Bottom bar */}
      <div className="border-t border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 flex flex-col sm:flex-row items-center justify-between gap-3 text-sm text-gray-500">
          <p>© {new Date().getFullYear()} GlowAI. All rights reserved.</p>
          <p className="flex items-center gap-1">Made with 💗 for radiant skin everywhere</p>
        </div>
      </div>
    </footer>
  )
}

export default Footer
