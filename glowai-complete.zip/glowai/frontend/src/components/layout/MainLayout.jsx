import React from 'react'
import Navbar from './Navbar'
import Footer from './Footer'
import ChatbotWidget from '../chatbot/ChatbotWidget'
import AnnouncementBanner from '../common/AnnouncementBanner'

const MainLayout = ({ children }) => {
  return (
    <div className="min-h-screen flex flex-col bg-white dark:bg-[#0f0a0d]">
      <AnnouncementBanner />
      <Navbar />
      <main className="flex-1">{children}</main>
      <Footer />
      <ChatbotWidget />
    </div>
  )
}

export default MainLayout
