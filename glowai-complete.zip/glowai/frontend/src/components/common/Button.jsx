import React from 'react'
import { Spinner } from './Loaders'

const Button = ({
  children,
  variant = 'primary',
  size = 'md',
  loading = false,
  disabled = false,
  icon: Icon,
  className = '',
  type = 'button',
  ...props
}) => {
  const variants = {
    primary: 'bg-gradient-to-r from-pink-500 to-pink-600 hover:from-pink-600 hover:to-pink-700 text-white shadow-glow hover:shadow-glow-lg',
    secondary: 'border-2 border-pink-500 text-pink-500 hover:bg-pink-500 hover:text-white',
    ghost: 'text-gray-600 dark:text-gray-300 hover:text-pink-500 hover:bg-pink-50 dark:hover:bg-pink-900/20',
    dark: 'bg-gray-900 hover:bg-black text-white dark:bg-white dark:text-gray-900 dark:hover:bg-gray-100',
    danger: 'bg-red-500 hover:bg-red-600 text-white',
    outline: 'border border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-200 hover:border-pink-400 hover:text-pink-500',
  }

  const sizes = {
    sm: 'px-4 py-2 text-sm',
    md: 'px-6 py-3 text-sm',
    lg: 'px-8 py-4 text-base',
    icon: 'p-2.5',
  }

  return (
    <button
      type={type}
      disabled={disabled || loading}
      className={`inline-flex items-center justify-center gap-2 rounded-full font-semibold transition-all duration-300 hover:scale-105 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100 ${variants[variant]} ${sizes[size]} ${className}`}
      {...props}
    >
      {loading ? <Spinner size={18} className="border-2" /> : Icon && <Icon size={18} />}
      {children}
    </button>
  )
}

export default Button
