import React from 'react'
import { Helmet } from 'react-helmet-async'

const SEO = ({ title, description, image, type = 'website' }) => {
  const siteTitle = title ? `${title} | GlowAI` : 'GlowAI — Premium AI-Powered Beauty'
  const siteDescription = description || 'Discover luxury skincare and beauty products with personalized AI recommendations tailored to your unique skin type.'
  const siteImage = image || '/og-image.jpg'

  return (
    <Helmet>
      <title>{siteTitle}</title>
      <meta name="description" content={siteDescription} />
      <meta property="og:title" content={siteTitle} />
      <meta property="og:description" content={siteDescription} />
      <meta property="og:image" content={siteImage} />
      <meta property="og:type" content={type} />
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:title" content={siteTitle} />
      <meta name="twitter:description" content={siteDescription} />
    </Helmet>
  )
}

export default SEO
