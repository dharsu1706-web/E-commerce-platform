import React from 'react'
import { FaStar, FaStarHalfAlt, FaRegStar } from 'react-icons/fa'

const StarRating = ({ rating = 0, size = 14, showCount = false, count = 0, className = '' }) => {
  const stars = []
  for (let i = 1; i <= 5; i++) {
    if (rating >= i) {
      stars.push(<FaStar key={i} size={size} className="star-filled" />)
    } else if (rating >= i - 0.5) {
      stars.push(<FaStarHalfAlt key={i} size={size} className="star-filled" />)
    } else {
      stars.push(<FaRegStar key={i} size={size} className="star-empty" />)
    }
  }

  return (
    <div className={`flex items-center gap-1 ${className}`}>
      <div className="flex items-center gap-0.5">{stars}</div>
      {showCount && (
        <span className="text-xs text-gray-500 dark:text-gray-400 ml-1">
          ({count})
        </span>
      )}
    </div>
  )
}

export default StarRating
