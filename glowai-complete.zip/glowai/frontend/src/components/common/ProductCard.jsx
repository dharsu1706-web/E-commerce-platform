import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import { FaHeart, FaRegHeart, FaShoppingBag, FaEye } from 'react-icons/fa'
import toast from 'react-hot-toast'
import StarRating from './StarRating'
import PriceTag from './PriceTag'
import { useCart } from '../../context/CartContext'
import { useAuth } from '../../context/AuthContext'
import { wishlistAPI } from '../../services/api'

const ProductCard = ({ product, index = 0 }) => {
  const { addItem } = useCart()
  const { isAuthenticated, user, updateUser } = useAuth()
  const [isWishlisted, setIsWishlisted] = useState(
    user?.wishlist?.some?.((id) => (id === product._id || id?._id === product._id)) || false
  )
  const [wishLoading, setWishLoading] = useState(false)

  const handleAddToCart = (e) => {
    e.preventDefault()
    e.stopPropagation()
    if (product.stock === 0) {
      toast.error('Product is out of stock')
      return
    }
    addItem(product, 1)
  }

  const handleWishlist = async (e) => {
    e.preventDefault()
    e.stopPropagation()
    if (!isAuthenticated) {
      toast.error('Please login to add to wishlist')
      return
    }
    setWishLoading(true)
    try {
      const { data } = await wishlistAPI.toggle(product._id)
      setIsWishlisted(data.inWishlist)
      toast.success(data.message)
    } catch (err) {
      toast.error('Something went wrong')
    } finally {
      setWishLoading(false)
    }
  }

  const outOfStock = product.stock === 0
  const slug = product.slug || product._id

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.4, delay: Math.min(index * 0.05, 0.3) }}
    >
      <Link to={`/product/${slug}`} className="product-card group block">
        <div className="relative aspect-square overflow-hidden bg-pink-50 dark:bg-gray-700/30">
          <img
            src={product.images?.[0]?.url || 'https://via.placeholder.com/400x400?text=GlowAI'}
            alt={product.name}
            loading="lazy"
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
          />

          {/* Badges */}
          <div className="absolute top-2 left-2 flex flex-col gap-1.5">
            {product.discountPercent > 0 && <span className="badge-pink shadow">{product.discountPercent}% OFF</span>}
            {product.isNew && <span className="badge-green shadow">NEW</span>}
            {outOfStock && <span className="badge-gray shadow">SOLD OUT</span>}
          </div>

          {/* Wishlist button */}
          <button
            onClick={handleWishlist}
            disabled={wishLoading}
            className="absolute top-2 right-2 w-9 h-9 rounded-full glass-card flex items-center justify-center text-pink-500 hover:scale-110 transition-transform bg-white/80 dark:bg-gray-900/60"
            aria-label="Toggle wishlist"
          >
            {isWishlisted ? <FaHeart size={15} /> : <FaRegHeart size={15} />}
          </button>

          {/* Quick actions overlay */}
          <div className="absolute inset-x-0 bottom-0 p-2 flex gap-2 translate-y-full group-hover:translate-y-0 transition-transform duration-300 bg-gradient-to-t from-black/40 to-transparent">
            <button
              onClick={handleAddToCart}
              disabled={outOfStock}
              className="flex-1 flex items-center justify-center gap-2 bg-white/90 backdrop-blur text-gray-900 text-xs font-semibold py-2 rounded-full hover:bg-pink-500 hover:text-white transition-colors disabled:opacity-50"
            >
              <FaShoppingBag size={12} /> Add to Bag
            </button>
            <div className="w-9 h-9 flex items-center justify-center bg-white/90 backdrop-blur rounded-full text-gray-900">
              <FaEye size={14} />
            </div>
          </div>
        </div>

        <div className="p-3 sm:p-4">
          {product.brand && <p className="text-xs text-pink-500 font-semibold uppercase tracking-wide mb-1">{product.brand}</p>}
          <h3 className="font-medium text-sm sm:text-base text-gray-800 dark:text-gray-100 line-clamp-2 mb-1.5 group-hover:text-pink-500 transition-colors">
            {product.name}
          </h3>
          {product.ratings > 0 && (
            <StarRating rating={product.ratings} size={12} showCount count={product.numReviews} className="mb-2" />
          )}
          <PriceTag price={product.price} discountPrice={product.discountPrice} size="sm" />
        </div>
      </Link>
    </motion.div>
  )
}

export default ProductCard
