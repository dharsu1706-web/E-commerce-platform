import React from 'react'

const PriceTag = ({ price, discountPrice, size = 'md', className = '' }) => {
  const hasDiscount = discountPrice > 0 && discountPrice < price
  const sizes = {
    sm: 'text-sm',
    md: 'text-lg',
    lg: 'text-2xl',
    xl: 'text-3xl',
  }
  const smallSizes = {
    sm: 'text-xs',
    md: 'text-sm',
    lg: 'text-base',
    xl: 'text-lg',
  }

  if (!hasDiscount) {
    return <span className={`font-bold text-gray-900 dark:text-white ${sizes[size]} ${className}`}>₹{price?.toLocaleString('en-IN')}</span>
  }

  const percent = Math.round(((price - discountPrice) / price) * 100)

  return (
    <div className={`flex items-baseline gap-2 ${className}`}>
      <span className={`font-bold text-gray-900 dark:text-white ${sizes[size]}`}>₹{discountPrice.toLocaleString('en-IN')}</span>
      <span className={`text-gray-400 line-through ${smallSizes[size]}`}>₹{price.toLocaleString('en-IN')}</span>
      <span className="badge-pink">{percent}% OFF</span>
    </div>
  )
}

export default PriceTag
