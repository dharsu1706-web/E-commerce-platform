import React from 'react'
import { Link } from 'react-router-dom'
import Button from './Button'

const EmptyState = ({ icon: Icon, title, message, actionLabel, actionLink, onAction }) => (
  <div className="flex flex-col items-center justify-center text-center py-16 px-4">
    {Icon && (
      <div className="w-20 h-20 rounded-full bg-pink-50 dark:bg-pink-900/20 flex items-center justify-center mb-4">
        <Icon size={36} className="text-pink-400" />
      </div>
    )}
    <h3 className="text-xl font-display font-semibold text-gray-800 dark:text-white mb-2">{title}</h3>
    <p className="text-gray-500 dark:text-gray-400 max-w-sm mb-6">{message}</p>
    {actionLabel && actionLink && (
      <Link to={actionLink}>
        <Button variant="primary">{actionLabel}</Button>
      </Link>
    )}
    {actionLabel && onAction && !actionLink && (
      <Button variant="primary" onClick={onAction}>{actionLabel}</Button>
    )}
  </div>
)

export default EmptyState
