import React, { useState } from 'react'
import { FaTimes, FaTruck } from 'react-icons/fa'
import { Link } from 'react-router-dom'

const AnnouncementBanner = () => {
  const [visible, setVisible] = useState(true)

  if (!visible) return null

  return (
    <div className="bg-gradient-to-r from-pink-600 via-pink-500 to-rose-500 text-white">
      <div className="max-w-7xl mx-auto px-4 py-2.5 flex items-center justify-between gap-3">
        <div className="flex-1 flex items-center justify-center gap-2 text-sm font-medium">
          <FaTruck size={14} />
          <span>Free shipping on orders above ₹999! Use code <span className="font-bold underline">GLOW10</span> for 10% off your first order.</span>
          <Link to="/shop" className="ml-2 bg-white/20 hover:bg-white/30 px-3 py-1 rounded-full text-xs font-semibold transition-colors hidden sm:inline-block">
            Shop Now
          </Link>
        </div>
        <button
          onClick={() => setVisible(false)}
          className="flex-shrink-0 hover:bg-white/20 p-1.5 rounded-full transition-colors"
          aria-label="Close announcement"
        >
          <FaTimes size={12} />
        </button>
      </div>
    </div>
  )
}

export default AnnouncementBanner
