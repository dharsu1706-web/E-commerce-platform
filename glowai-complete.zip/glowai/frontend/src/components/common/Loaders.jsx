import React from 'react'
import { motion } from 'framer-motion'

export const Spinner = ({ size = 32, className = '' }) => (
  <motion.div
    className={`border-4 border-pink-200 border-t-pink-500 rounded-full ${className}`}
    style={{ width: size, height: size }}
    animate={{ rotate: 360 }}
    transition={{ duration: 0.8, repeat: Infinity, ease: 'linear' }}
  />
)

export const PageLoader = () => (
  <div className="min-h-[60vh] flex flex-col items-center justify-center gap-4">
    <Spinner size={48} />
    <p className="text-gray-500 dark:text-gray-400 font-medium animate-pulse">Loading your glow...</p>
  </div>
)

export const ProductCardSkeleton = () => (
  <div className="product-card p-3">
    <div className="skeleton aspect-square w-full mb-3" />
    <div className="skeleton h-3 w-20 mb-2" />
    <div className="skeleton h-4 w-full mb-2" />
    <div className="skeleton h-4 w-2/3 mb-3" />
    <div className="skeleton h-5 w-1/3" />
  </div>
)

export const ProductGridSkeleton = ({ count = 8 }) => (
  <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
    {Array.from({ length: count }).map((_, i) => <ProductCardSkeleton key={i} />)}
  </div>
)

export const TextSkeleton = ({ lines = 3, className = '' }) => (
  <div className={`space-y-2 ${className}`}>
    {Array.from({ length: lines }).map((_, i) => (
      <div key={i} className="skeleton h-4" style={{ width: `${100 - i * 15}%` }} />
    ))}
  </div>
)

export const CardSkeleton = ({ className = '' }) => (
  <div className={`skeleton ${className}`} />
)
