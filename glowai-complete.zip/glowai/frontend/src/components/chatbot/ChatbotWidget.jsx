import React, { useState, useRef, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { FaMagic, FaTimes, FaPaperPlane, FaRobot } from 'react-icons/fa'
import { Link } from 'react-router-dom'
import { aiAPI } from '../../services/api'

const suggestedPrompts = [
  'Which products are good for oily skin?',
  'Suggest a skincare routine for acne',
  'Recommend a serum for dark spots',
  'What helps with dry skin?',
]

const ChatbotWidget = () => {
  const [open, setOpen] = useState(false)
  const [messages, setMessages] = useState([
    {
      role: 'assistant',
      content: "Hi there! I'm your GlowAI Beauty Assistant 🌸 Ask me about skincare routines, product recommendations, or your skin concerns!",
      products: [],
    },
  ])
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const scrollRef = useRef(null)

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight
    }
  }, [messages, loading])

  const sendMessage = async (text) => {
    const message = text || input
    if (!message.trim() || loading) return

    setMessages((prev) => [...prev, { role: 'user', content: message }])
    setInput('')
    setLoading(true)

    try {
      const { data } = await aiAPI.chat({ message })
      setMessages((prev) => [...prev, { role: 'assistant', content: data.response, products: data.products || [] }])
    } catch (err) {
      setMessages((prev) => [...prev, { role: 'assistant', content: "Sorry, I'm having trouble connecting right now. Please try again in a moment! 🌸", products: [] }])
    } finally {
      setLoading(false)
    }
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    sendMessage()
  }

  return (
    <>
      {/* Floating button */}
      <motion.button
        onClick={() => setOpen(!open)}
        className="fixed bottom-5 right-5 z-50 w-14 h-14 sm:w-16 sm:h-16 rounded-full bg-gradient-to-br from-pink-500 to-pink-600 shadow-glow-lg flex items-center justify-center text-white"
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.95 }}
        animate={{ y: [0, -8, 0] }}
        transition={{ y: { duration: 2.5, repeat: Infinity, ease: 'easeInOut' } }}
        aria-label="Open GlowAI Assistant"
      >
        {open ? <FaTimes size={22} /> : <FaMagic size={24} />}
      </motion.button>

      {/* Chat window */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: 30, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 30, scale: 0.95 }}
            transition={{ duration: 0.2 }}
            className="fixed bottom-24 right-5 z-50 w-[calc(100vw-2.5rem)] sm:w-96 h-[70vh] sm:h-[600px] glass-card-solid rounded-3xl shadow-card-hover flex flex-col overflow-hidden"
          >
            {/* Header */}
            <div className="bg-gradient-to-r from-pink-500 to-pink-600 p-4 flex items-center gap-3 text-white">
              <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center">
                <FaRobot size={18} />
              </div>
              <div>
                <h3 className="font-display font-semibold">GlowAI Assistant</h3>
                <p className="text-xs text-pink-100">Your personal beauty advisor</p>
              </div>
            </div>

            {/* Messages */}
            <div ref={scrollRef} className="flex-1 overflow-y-auto custom-scroll p-4 space-y-4">
              {messages.map((msg, i) => (
                <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div
                    className={`max-w-[85%] rounded-2xl px-4 py-2.5 text-sm whitespace-pre-line ${
                      msg.role === 'user'
                        ? 'bg-pink-500 text-white rounded-br-sm'
                        : 'bg-pink-50 dark:bg-gray-800 text-gray-800 dark:text-gray-100 rounded-bl-sm'
                    }`}
                  >
                    {msg.content}
                    {msg.products?.length > 0 && (
                      <div className="mt-3 space-y-2">
                        {msg.products.map((p) => (
                          <Link
                            key={p._id}
                            to={`/product/${p.slug || p._id}`}
                            onClick={() => setOpen(false)}
                            className="flex items-center gap-3 bg-white dark:bg-gray-700 rounded-xl p-2 hover:bg-pink-100 dark:hover:bg-gray-600 transition-colors"
                          >
                            <img src={p.image} alt={p.name} className="w-12 h-12 rounded-lg object-cover flex-shrink-0" />
                            <div className="flex-1 min-w-0">
                              <p className="text-xs font-medium text-gray-800 dark:text-gray-100 line-clamp-1">{p.name}</p>
                              <p className="text-xs text-pink-500 font-semibold">₹{(p.discountPrice || p.price)?.toLocaleString('en-IN')}</p>
                            </div>
                          </Link>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              ))}
              {loading && (
                <div className="flex justify-start">
                  <div className="bg-pink-50 dark:bg-gray-800 rounded-2xl rounded-bl-sm px-4 py-3 flex gap-1">
                    {[0, 1, 2].map((i) => (
                      <motion.div
                        key={i}
                        className="w-2 h-2 bg-pink-400 rounded-full"
                        animate={{ y: [0, -6, 0] }}
                        transition={{ duration: 0.6, repeat: Infinity, delay: i * 0.15 }}
                      />
                    ))}
                  </div>
                </div>
              )}

              {messages.length === 1 && (
                <div className="space-y-2 pt-2">
                  <p className="text-xs text-gray-400 font-medium">Try asking:</p>
                  {suggestedPrompts.map((prompt, i) => (
                    <button
                      key={i}
                      onClick={() => sendMessage(prompt)}
                      className="block w-full text-left text-xs bg-white dark:bg-gray-800 border border-pink-100 dark:border-pink-900/30 rounded-xl px-3 py-2 hover:border-pink-400 hover:bg-pink-50 dark:hover:bg-pink-900/20 transition-colors text-gray-600 dark:text-gray-300"
                    >
                      {prompt}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Input */}
            <form onSubmit={handleSubmit} className="p-3 border-t border-pink-100 dark:border-pink-900/30 flex gap-2">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Ask about your skin..."
                className="input-field py-2.5 text-sm flex-1"
                disabled={loading}
              />
              <button
                type="submit"
                disabled={loading || !input.trim()}
                className="w-11 h-11 flex-shrink-0 rounded-full bg-pink-500 hover:bg-pink-600 text-white flex items-center justify-center disabled:opacity-50 transition-colors"
              >
                <FaPaperPlane size={14} />
              </button>
            </form>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}

export default ChatbotWidget
