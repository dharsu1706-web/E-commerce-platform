import React, { createContext, useContext, useState, useEffect, useMemo, useCallback } from 'react'
import toast from 'react-hot-toast'

const CartContext = createContext(null)

const STORAGE_KEY = 'glowai_cart'

export const CartProvider = ({ children }) => {
  const [items, setItems] = useState(() => {
    try { return JSON.parse(localStorage.getItem(STORAGE_KEY)) || [] } catch { return [] }
  })

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(items))
  }, [items])

  const addItem = useCallback((product, quantity = 1) => {
    setItems((prev) => {
      const existing = prev.find((i) => i.product === product._id)
      if (existing) {
        const newQty = Math.min(existing.quantity + quantity, product.stock || 99)
        toast.success('Cart updated 🛍️')
        return prev.map((i) => (i.product === product._id ? { ...i, quantity: newQty } : i))
      }
      toast.success('Added to cart 🛍️')
      return [
        ...prev,
        {
          product: product._id,
          name: product.name,
          image: product.images?.[0]?.url || '',
          price: product.discountPrice || product.price,
          originalPrice: product.price,
          quantity: Math.min(quantity, product.stock || 99),
          stock: product.stock,
          slug: product.slug,
        },
      ]
    })
  }, [])

  const removeItem = useCallback((productId) => {
    setItems((prev) => prev.filter((i) => i.product !== productId))
    toast.success('Removed from cart')
  }, [])

  const updateQuantity = useCallback((productId, quantity) => {
    if (quantity < 1) return
    setItems((prev) => prev.map((i) => (i.product === productId ? { ...i, quantity: Math.min(quantity, i.stock || 99) } : i)))
  }, [])

  const clearCart = useCallback(() => setItems([]), [])

  const { subtotal, totalItems, shippingPrice, taxPrice, totalPrice } = useMemo(() => {
    const subtotal = items.reduce((sum, i) => sum + i.price * i.quantity, 0)
    const totalItems = items.reduce((sum, i) => sum + i.quantity, 0)
    const shippingPrice = subtotal > 999 || subtotal === 0 ? 0 : 99
    const taxPrice = Math.round(subtotal * 0.18)
    const totalPrice = subtotal + shippingPrice + taxPrice
    return { subtotal, totalItems, shippingPrice, taxPrice, totalPrice }
  }, [items])

  return (
    <CartContext.Provider value={{ items, addItem, removeItem, updateQuantity, clearCart, subtotal, totalItems, shippingPrice, taxPrice, totalPrice }}>
      {children}
    </CartContext.Provider>
  )
}

export const useCart = () => {
  const ctx = useContext(CartContext)
  if (!ctx) throw new Error('useCart must be used within CartProvider')
  return ctx
}
