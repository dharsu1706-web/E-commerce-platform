import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import { FaEnvelope, FaCheckCircle } from 'react-icons/fa'
import toast from 'react-hot-toast'
import MainLayout from '../components/layout/MainLayout'
import SEO from '../components/common/SEO'
import Button from '../components/common/Button'
import { authAPI } from '../services/api'

const ForgotPasswordPage = () => {
  const [email, setEmail] = useState('')
  const [loading, setLoading] = useState(false)
  const [sent, setSent] = useState(false)

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)
    try {
      const { data } = await authAPI.forgotPassword(email)
      toast.success(data.message)
      setSent(true)
    } catch (err) {
      toast.error(err.response?.data?.message || 'Something went wrong')
    } finally {
      setLoading(false)
    }
  }

  return (
    <MainLayout>
      <SEO title="Forgot Password" />
      <div className="min-h-[80vh] flex items-center justify-center px-4 py-12 bg-gradient-hero">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
          className="w-full max-w-md glass-card-solid rounded-3xl p-8 sm:p-10"
        >
          {sent ? (
            <div className="text-center">
              <div className="w-16 h-16 rounded-full bg-emerald-100 dark:bg-emerald-900/30 flex items-center justify-center mx-auto mb-4">
                <FaCheckCircle className="text-emerald-500" size={28} />
              </div>
              <h1 className="text-2xl font-display font-bold text-gray-900 dark:text-white mb-2">Check Your Email</h1>
              <p className="text-gray-500 dark:text-gray-400 mb-6">We've sent a password reset link to <span className="font-medium text-gray-700 dark:text-gray-300">{email}</span></p>
              <Link to="/login"><Button variant="primary">Back to Login</Button></Link>
            </div>
          ) : (
            <>
              <div className="text-center mb-8">
                <div className="w-14 h-14 rounded-full bg-gradient-to-br from-pink-400 to-pink-600 flex items-center justify-center mx-auto mb-4 shadow-glow">
                  <FaEnvelope className="text-white" size={22} />
                </div>
                <h1 className="text-2xl font-display font-bold text-gray-900 dark:text-white">Forgot Password?</h1>
                <p className="text-gray-500 dark:text-gray-400 mt-1">Enter your email and we'll send you a reset link</p>
              </div>

              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="relative">
                  <FaEnvelope className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={14} />
                  <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email address" className="input-field pl-11" required />
                </div>
                <Button type="submit" variant="primary" loading={loading} className="w-full">Send Reset Link</Button>
              </form>

              <p className="text-center text-sm text-gray-500 dark:text-gray-400 mt-6">
                Remember your password? <Link to="/login" className="text-pink-500 font-semibold hover:underline">Login</Link>
              </p>
            </>
          )}
        </motion.div>
      </div>
    </MainLayout>
  )
}

export default ForgotPasswordPage
