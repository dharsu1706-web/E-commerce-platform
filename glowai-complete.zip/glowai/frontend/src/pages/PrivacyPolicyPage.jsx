import React from 'react'
import MainLayout from '../components/layout/MainLayout'
import SEO from '../components/common/SEO'

const PrivacyPolicyPage = () => {
  return (
    <MainLayout>
      <SEO title="Privacy Policy" description="Read GlowAI's privacy policy to understand how we collect, use, and protect your data." />

      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <h1 className="section-heading mb-2">Privacy Policy</h1>
        <p className="text-gray-400 text-sm mb-8">Last updated: January 2026</p>

        <div className="space-y-8 text-gray-600 dark:text-gray-300 leading-relaxed">
          <section>
            <h2 className="text-xl font-display font-semibold text-gray-900 dark:text-white mb-3">1. Information We Collect</h2>
            <p>We collect information you provide directly to us, such as when you create an account, place an order, take our skin quiz, or contact our support team. This includes your name, email address, shipping address, phone number, and skin type preferences.</p>
          </section>

          <section>
            <h2 className="text-xl font-display font-semibold text-gray-900 dark:text-white mb-3">2. How We Use Your Information</h2>
            <p>We use the information we collect to: process and fulfill your orders, provide personalized AI-powered product recommendations, send order confirmations and shipping updates, respond to your inquiries, and improve our products and services.</p>
          </section>

          <section>
            <h2 className="text-xl font-display font-semibold text-gray-900 dark:text-white mb-3">3. AI Recommendations & Skin Data</h2>
            <p>When you use our Skin Quiz or AI Beauty Assistant, we process your responses to generate personalized recommendations. This data is used solely to improve your shopping experience and is never sold to third parties.</p>
          </section>

          <section>
            <h2 className="text-xl font-display font-semibold text-gray-900 dark:text-white mb-3">4. Data Security</h2>
            <p>We implement industry-standard security measures including encryption, secure servers, and access controls to protect your personal information. Passwords are hashed using bcrypt and never stored in plain text.</p>
          </section>

          <section>
            <h2 className="text-xl font-display font-semibold text-gray-900 dark:text-white mb-3">5. Cookies</h2>
            <p>We use cookies and similar technologies to maintain your session, remember your preferences (such as dark mode and cart contents), and analyze site usage to improve our services.</p>
          </section>

          <section>
            <h2 className="text-xl font-display font-semibold text-gray-900 dark:text-white mb-3">6. Third-Party Services</h2>
            <p>We use trusted third-party services for payment processing, email delivery, and image hosting (Cloudinary). These providers have access only to the information necessary to perform their functions.</p>
          </section>

          <section>
            <h2 className="text-xl font-display font-semibold text-gray-900 dark:text-white mb-3">7. Your Rights</h2>
            <p>You have the right to access, update, or delete your personal information at any time through your account dashboard. You may also unsubscribe from marketing emails using the link provided in each email.</p>
          </section>

          <section>
            <h2 className="text-xl font-display font-semibold text-gray-900 dark:text-white mb-3">8. Contact Us</h2>
            <p>If you have any questions about this Privacy Policy, please contact us at hello@glowai.com.</p>
          </section>
        </div>
      </div>
    </MainLayout>
  )
}

export default PrivacyPolicyPage
