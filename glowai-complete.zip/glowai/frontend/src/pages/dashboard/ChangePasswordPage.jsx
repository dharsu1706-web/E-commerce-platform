import React, { useState } from 'react'
import { FaLock } from 'react-icons/fa'
import toast from 'react-hot-toast'
import MainLayout from '../../components/layout/MainLayout'
import SEO from '../../components/common/SEO'
import DashboardLayout from '../../components/dashboard/DashboardLayout'
import Button from '../../components/common/Button'
import { authAPI } from '../../services/api'

const ChangePasswordPage = () => {
  const [currentPassword, setCurrentPassword] = useState('')
  const [newPassword, setNewPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (newPassword !== confirmPassword) {
      toast.error('New passwords do not match')
      return
    }
    setLoading(true)
    try {
      const { data } = await authAPI.updatePassword({ currentPassword, newPassword })
      localStorage.setItem('glowai_token', data.token)
      toast.success(data.message)
      setCurrentPassword('')
      setNewPassword('')
      setConfirmPassword('')
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to update password')
    } finally {
      setLoading(false)
    }
  }

  return (
    <MainLayout>
      <SEO title="Change Password" />
      <DashboardLayout title="Change Password">
        <form onSubmit={handleSubmit} className="glass-card-solid rounded-2xl p-6 max-w-md space-y-4">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 rounded-full bg-pink-100 dark:bg-pink-900/30 flex items-center justify-center"><FaLock className="text-pink-500" /></div>
            <h2 className="font-display font-semibold text-lg text-gray-900 dark:text-white">Update Password</h2>
          </div>
          <input type="password" required value={currentPassword} onChange={(e) => setCurrentPassword(e.target.value)} placeholder="Current Password" className="input-field" />
          <input type="password" required minLength={6} value={newPassword} onChange={(e) => setNewPassword(e.target.value)} placeholder="New Password" className="input-field" />
          <input type="password" required value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} placeholder="Confirm New Password" className="input-field" />
          <Button type="submit" variant="primary" loading={loading}>Update Password</Button>
        </form>
      </DashboardLayout>
    </MainLayout>
  )
}

export default ChangePasswordPage
