import React, { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { FaBoxOpen, FaChevronRight } from 'react-icons/fa'
import MainLayout from '../../components/layout/MainLayout'
import SEO from '../../components/common/SEO'
import DashboardLayout from '../../components/dashboard/DashboardLayout'
import EmptyState from '../../components/common/EmptyState'
import Pagination from '../../components/shop/Pagination'
import { TextSkeleton } from '../../components/common/Loaders'
import { orderAPI } from '../../services/api'

const statusColors = {
  pending: 'badge-yellow',
  processing: 'badge-pink',
  shipped: 'badge-pink',
  delivered: 'badge-green',
  cancelled: 'badge-red',
  refunded: 'badge-gray',
}

const MyOrdersPage = () => {
  const [orders, setOrders] = useState([])
  const [loading, setLoading] = useState(true)
  const [page, setPage] = useState(1)
  const [pages, setPages] = useState(1)

  useEffect(() => {
    setLoading(true)
    orderAPI.getMyOrders({ page })
      .then(({ data }) => { setOrders(data.orders); setPages(data.pages) })
      .finally(() => setLoading(false))
  }, [page])

  return (
    <MainLayout>
      <SEO title="My Orders" />
      <DashboardLayout title="My Orders">
        {loading ? (
          <div className="space-y-4">{[1, 2, 3].map((i) => <div key={i} className="glass-card-solid rounded-2xl p-5"><TextSkeleton lines={2} /></div>)}</div>
        ) : orders.length === 0 ? (
          <EmptyState icon={FaBoxOpen} title="No orders yet" message="You haven't placed any orders yet. Start shopping to see your orders here!" actionLabel="Shop Now" actionLink="/shop" />
        ) : (
          <>
            <div className="space-y-4">
              {orders.map((order) => (
                <Link key={order._id} to={`/dashboard/orders/${order._id}`} className="glass-card-solid rounded-2xl p-5 flex items-center justify-between hover:shadow-card-hover transition-shadow">
                  <div className="flex items-center gap-4">
                    <div className="flex -space-x-3">
                      {order.items.slice(0, 3).map((item, i) => (
                        <img key={i} src={item.image} alt={item.name} className="w-12 h-12 rounded-xl object-cover border-2 border-white dark:border-gray-800" style={{ zIndex: 3 - i }} />
                      ))}
                    </div>
                    <div>
                      <p className="font-semibold text-gray-800 dark:text-white">{order.orderNumber}</p>
                      <p className="text-xs text-gray-400">{new Date(order.createdAt).toLocaleDateString()} · {order.items.length} item(s)</p>
                    </div>
                  </div>
                  <div className="text-right flex items-center gap-4">
                    <div>
                      <p className="font-bold text-gray-900 dark:text-white">₹{order.totalPrice.toLocaleString('en-IN')}</p>
                      <span className={`${statusColors[order.orderStatus]} text-[10px] capitalize`}>{order.orderStatus}</span>
                    </div>
                    <FaChevronRight className="text-gray-300" />
                  </div>
                </Link>
              ))}
            </div>
            <Pagination page={page} pages={pages} onChange={setPage} />
          </>
        )}
      </DashboardLayout>
    </MainLayout>
  )
}

export default MyOrdersPage
