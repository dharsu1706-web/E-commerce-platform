import React, { useState, useEffect } from 'react'
import { useParams, Link } from 'react-router-dom'
import { FaMapMarkerAlt, FaCreditCard } from 'react-icons/fa'
import MainLayout from '../../components/layout/MainLayout'
import SEO from '../../components/common/SEO'
import DashboardLayout from '../../components/dashboard/DashboardLayout'
import OrderTracker from '../../components/dashboard/OrderTracker'
import { PageLoader } from '../../components/common/Loaders'
import { orderAPI } from '../../services/api'

const OrderDetailsPage = () => {
  const { id } = useParams()
  const [order, setOrder] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    orderAPI.getOne(id).then(({ data }) => setOrder(data.order)).catch(() => setOrder(null)).finally(() => setLoading(false))
  }, [id])

  if (loading) return <MainLayout><PageLoader /></MainLayout>
  if (!order) return <MainLayout><div className="text-center py-20">Order not found.</div></MainLayout>

  return (
    <MainLayout>
      <SEO title={`Order ${order.orderNumber}`} />
      <DashboardLayout title="Order Details">
        <div className="space-y-6">
          {/* Header */}
          <div className="glass-card-solid rounded-2xl p-6 flex flex-wrap items-center justify-between gap-4">
            <div>
              <h2 className="font-display font-semibold text-lg text-gray-900 dark:text-white">{order.orderNumber}</h2>
              <p className="text-sm text-gray-400">Placed on {new Date(order.createdAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' })}</p>
            </div>
            {order.trackingNumber && (
              <div className="text-right">
                <p className="text-xs text-gray-400">Tracking Number</p>
                <p className="font-mono font-semibold text-gray-800 dark:text-gray-100">{order.trackingNumber}</p>
              </div>
            )}
          </div>

          {/* Tracker */}
          <OrderTracker status={order.orderStatus} />

          {/* Items */}
          <div className="glass-card-solid rounded-2xl p-6">
            <h3 className="font-display font-semibold text-gray-900 dark:text-white mb-4">Items</h3>
            <div className="space-y-3">
              {order.items.map((item, i) => (
                <div key={i} className="flex items-center gap-4">
                  <img src={item.image} alt={item.name} className="w-16 h-16 rounded-xl object-cover" />
                  <div className="flex-1">
                    <Link to={`/product/${item.product?.slug || item.product?._id || item.product}`} className="font-medium text-sm text-gray-800 dark:text-gray-100 hover:text-pink-500 line-clamp-1">{item.name}</Link>
                    <p className="text-xs text-gray-400">Qty: {item.quantity} × ₹{item.price.toLocaleString('en-IN')}</p>
                  </div>
                  <p className="font-semibold text-gray-800 dark:text-gray-100">₹{(item.price * item.quantity).toLocaleString('en-IN')}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="grid sm:grid-cols-2 gap-6">
            {/* Shipping */}
            <div className="glass-card-solid rounded-2xl p-6">
              <h3 className="font-display font-semibold text-gray-900 dark:text-white mb-3 flex items-center gap-2"><FaMapMarkerAlt className="text-pink-500" /> Shipping Address</h3>
              <div className="text-sm text-gray-600 dark:text-gray-300 space-y-1">
                <p className="font-medium text-gray-800 dark:text-gray-100">{order.shippingAddress.name}</p>
                <p>{order.shippingAddress.street}</p>
                <p>{order.shippingAddress.city}, {order.shippingAddress.state} {order.shippingAddress.zipCode}</p>
                <p>{order.shippingAddress.country}</p>
                <p>Phone: {order.shippingAddress.phone}</p>
              </div>
            </div>

            {/* Payment summary */}
            <div className="glass-card-solid rounded-2xl p-6">
              <h3 className="font-display font-semibold text-gray-900 dark:text-white mb-3 flex items-center gap-2"><FaCreditCard className="text-pink-500" /> Payment Summary</h3>
              <div className="text-sm space-y-2">
                <div className="flex justify-between text-gray-600 dark:text-gray-300"><span>Method</span><span className="uppercase font-medium">{order.paymentMethod}</span></div>
                <div className="flex justify-between text-gray-600 dark:text-gray-300"><span>Subtotal</span><span>₹{order.subtotal.toLocaleString('en-IN')}</span></div>
                <div className="flex justify-between text-gray-600 dark:text-gray-300"><span>Shipping</span><span>{order.shippingPrice === 0 ? 'FREE' : `₹${order.shippingPrice}`}</span></div>
                <div className="flex justify-between text-gray-600 dark:text-gray-300"><span>Tax</span><span>₹{order.taxPrice.toLocaleString('en-IN')}</span></div>
                {order.discount > 0 && <div className="flex justify-between text-emerald-500"><span>Discount ({order.couponCode})</span><span>-₹{order.discount.toLocaleString('en-IN')}</span></div>}
                <div className="flex justify-between font-bold text-gray-900 dark:text-white border-t border-pink-100 dark:border-pink-900/30 pt-2"><span>Total</span><span>₹{order.totalPrice.toLocaleString('en-IN')}</span></div>
              </div>
            </div>
          </div>
        </div>
      </DashboardLayout>
    </MainLayout>
  )
}

export default OrderDetailsPage
