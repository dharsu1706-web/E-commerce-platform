import React, { useState, useEffect } from 'react'
import { FaHeart } from 'react-icons/fa'
import MainLayout from '../../components/layout/MainLayout'
import SEO from '../../components/common/SEO'
import DashboardLayout from '../../components/dashboard/DashboardLayout'
import ProductCard from '../../components/common/ProductCard'
import EmptyState from '../../components/common/EmptyState'
import { ProductGridSkeleton } from '../../components/common/Loaders'
import { wishlistAPI } from '../../services/api'

const WishlistPage = () => {
  const [wishlist, setWishlist] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    wishlistAPI.get().then(({ data }) => setWishlist(data.wishlist)).finally(() => setLoading(false))
  }, [])

  return (
    <MainLayout>
      <SEO title="My Wishlist" />
      <DashboardLayout title="My Wishlist">
        {loading ? (
          <ProductGridSkeleton count={4} />
        ) : wishlist.length === 0 ? (
          <EmptyState icon={FaHeart} title="Your wishlist is empty" message="Save your favorite products here to shop them later!" actionLabel="Explore Products" actionLink="/shop" />
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 md:gap-6">
            {wishlist.map((p, i) => <ProductCard key={p._id} product={p} index={i} />)}
          </div>
        )}
      </DashboardLayout>
    </MainLayout>
  )
}

export default WishlistPage
