import React, { useState, useEffect } from 'react'
import { FaMapMarkerAlt, FaPlus, FaTrash, FaStar } from 'react-icons/fa'
import toast from 'react-hot-toast'
import MainLayout from '../../components/layout/MainLayout'
import SEO from '../../components/common/SEO'
import DashboardLayout from '../../components/dashboard/DashboardLayout'
import Button from '../../components/common/Button'
import EmptyState from '../../components/common/EmptyState'
import { userAPI } from '../../services/api'

const emptyAddress = { name: '', street: '', city: '', state: '', zipCode: '', country: 'India', isDefault: false }

const AddressesPage = () => {
  const [addresses, setAddresses] = useState([])
  const [loading, setLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [form, setForm] = useState(emptyAddress)
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    userAPI.getProfile().then(({ data }) => setAddresses(data.user.addresses || [])).finally(() => setLoading(false))
  }, [])

  const handleSubmit = async (e) => {
    e.preventDefault()
    setSaving(true)
    try {
      const { data } = await userAPI.addAddress(form)
      setAddresses(data.addresses)
      toast.success(data.message)
      setForm(emptyAddress)
      setShowForm(false)
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to add address')
    } finally {
      setSaving(false)
    }
  }

  const handleDelete = async (addressId) => {
    try {
      const { data } = await userAPI.deleteAddress(addressId)
      setAddresses(data.addresses)
      toast.success(data.message)
    } catch {
      toast.error('Failed to remove address')
    }
  }

  const handleSetDefault = async (address) => {
    try {
      const { data } = await userAPI.updateAddress(address._id, { isDefault: true })
      setAddresses(data.addresses)
      toast.success('Default address updated')
    } catch {
      toast.error('Failed to update')
    }
  }

  return (
    <MainLayout>
      <SEO title="My Addresses" />
      <DashboardLayout title="My Addresses">
        <div className="mb-4 flex justify-end">
          <Button variant="primary" icon={FaPlus} onClick={() => setShowForm(!showForm)}>{showForm ? 'Cancel' : 'Add Address'}</Button>
        </div>

        {showForm && (
          <form onSubmit={handleSubmit} className="glass-card-solid rounded-2xl p-6 mb-6 space-y-4">
            <div className="grid sm:grid-cols-2 gap-4">
              <input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Full Name" className="input-field sm:col-span-2" />
              <input required value={form.street} onChange={(e) => setForm({ ...form, street: e.target.value })} placeholder="Street Address" className="input-field sm:col-span-2" />
              <input required value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} placeholder="City" className="input-field" />
              <input required value={form.state} onChange={(e) => setForm({ ...form, state: e.target.value })} placeholder="State" className="input-field" />
              <input required value={form.zipCode} onChange={(e) => setForm({ ...form, zipCode: e.target.value })} placeholder="ZIP Code" className="input-field" />
              <input required value={form.country} onChange={(e) => setForm({ ...form, country: e.target.value })} placeholder="Country" className="input-field" />
            </div>
            <label className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-300">
              <input type="checkbox" checked={form.isDefault} onChange={(e) => setForm({ ...form, isDefault: e.target.checked })} className="text-pink-500 rounded focus:ring-pink-400" />
              Set as default address
            </label>
            <Button type="submit" variant="primary" loading={saving}>Save Address</Button>
          </form>
        )}

        {loading ? null : addresses.length === 0 && !showForm ? (
          <EmptyState icon={FaMapMarkerAlt} title="No addresses saved" message="Add an address to make checkout faster!" actionLabel="Add Address" onAction={() => setShowForm(true)} />
        ) : (
          <div className="grid sm:grid-cols-2 gap-4">
            {addresses.map((addr) => (
              <div key={addr._id} className="glass-card-solid rounded-2xl p-5 relative">
                {addr.isDefault && <span className="badge-pink absolute top-4 right-4"><FaStar size={9} /> Default</span>}
                <p className="font-semibold text-gray-800 dark:text-white mb-1">{addr.name}</p>
                <p className="text-sm text-gray-600 dark:text-gray-300">{addr.street}</p>
                <p className="text-sm text-gray-600 dark:text-gray-300">{addr.city}, {addr.state} {addr.zipCode}</p>
                <p className="text-sm text-gray-600 dark:text-gray-300">{addr.country}</p>
                <div className="flex gap-3 mt-3">
                  {!addr.isDefault && <button onClick={() => handleSetDefault(addr)} className="text-xs text-pink-500 hover:underline">Set as Default</button>}
                  <button onClick={() => handleDelete(addr._id)} className="text-xs text-red-400 hover:underline flex items-center gap-1"><FaTrash size={10} /> Remove</button>
                </div>
              </div>
            ))}
          </div>
        )}
      </DashboardLayout>
    </MainLayout>
  )
}

export default AddressesPage
