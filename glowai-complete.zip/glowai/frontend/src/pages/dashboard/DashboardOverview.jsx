import React, { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { FaBoxOpen, FaHeart, FaUser, FaEdit, FaArrowRight } from 'react-icons/fa'
import toast from 'react-hot-toast'
import MainLayout from '../../components/layout/MainLayout'
import SEO from '../../components/common/SEO'
import DashboardLayout from '../../components/dashboard/DashboardLayout'
import Button from '../../components/common/Button'
import { useAuth } from '../../context/AuthContext'
import { userAPI, orderAPI } from '../../services/api'

const skinTypeOptions = ['', 'normal', 'dry', 'oily', 'combination', 'sensitive']

const DashboardOverview = () => {
  const { user, updateUser } = useAuth()
  const [editing, setEditing] = useState(false)
  const [name, setName] = useState(user?.name || '')
  const [phone, setPhone] = useState(user?.phone || '')
  const [skinType, setSkinType] = useState(user?.skinType || '')
  const [loading, setLoading] = useState(false)
  const [recentOrders, setRecentOrders] = useState([])
  const [orderCount, setOrderCount] = useState(0)
  const [wishlistCount, setWishlistCount] = useState(0)

  useEffect(() => {
    orderAPI.getMyOrders({ limit: 3 }).then(({ data }) => {
      setRecentOrders(data.orders)
      setOrderCount(data.total)
    }).catch(() => {})
    userAPI.getProfile().then(({ data }) => setWishlistCount(data.user.wishlist?.length || 0)).catch(() => {})
  }, [])

  const handleSave = async () => {
    setLoading(true)
    try {
      const { data } = await userAPI.updateProfile({ name, phone, skinType })
      updateUser({ ...user, ...data.user })
      toast.success(data.message)
      setEditing(false)
    } catch (err) {
      toast.error(err.response?.data?.message || 'Update failed')
    } finally {
      setLoading(false)
    }
  }

  return (
    <MainLayout>
      <SEO title="My Dashboard" />
      <DashboardLayout title="My Dashboard">
        {/* Stats */}
        <div className="grid sm:grid-cols-3 gap-4 mb-6">
          <div className="glass-card-solid rounded-2xl p-5 flex items-center gap-4">
            <div className="w-12 h-12 rounded-full bg-pink-100 dark:bg-pink-900/30 flex items-center justify-center"><FaBoxOpen className="text-pink-500" size={18} /></div>
            <div><p className="text-2xl font-display font-bold text-gray-900 dark:text-white">{orderCount}</p><p className="text-xs text-gray-500">Total Orders</p></div>
          </div>
          <div className="glass-card-solid rounded-2xl p-5 flex items-center gap-4">
            <div className="w-12 h-12 rounded-full bg-pink-100 dark:bg-pink-900/30 flex items-center justify-center"><FaHeart className="text-pink-500" size={18} /></div>
            <div><p className="text-2xl font-display font-bold text-gray-900 dark:text-white">{wishlistCount}</p><p className="text-xs text-gray-500">Wishlist Items</p></div>
          </div>
          <div className="glass-card-solid rounded-2xl p-5 flex items-center gap-4">
            <div className="w-12 h-12 rounded-full bg-pink-100 dark:bg-pink-900/30 flex items-center justify-center"><FaUser className="text-pink-500" size={18} /></div>
            <div><p className="text-sm font-semibold text-gray-900 dark:text-white capitalize">{user?.skinType || 'Not set'}</p><p className="text-xs text-gray-500">Skin Type</p></div>
          </div>
        </div>

        {/* Profile */}
        <div className="glass-card-solid rounded-2xl p-6 mb-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-display font-semibold text-lg text-gray-900 dark:text-white">Profile Information</h2>
            <button onClick={() => setEditing(!editing)} className="btn-icon"><FaEdit /></button>
          </div>

          {editing ? (
            <div className="space-y-4">
              <div className="grid sm:grid-cols-2 gap-4">
                <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Full Name" className="input-field" />
                <input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="Phone Number" className="input-field" />
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2 block">Skin Type</label>
                <select value={skinType} onChange={(e) => setSkinType(e.target.value)} className="input-field">
                  {skinTypeOptions.map((opt) => <option key={opt} value={opt}>{opt ? opt.charAt(0).toUpperCase() + opt.slice(1) : 'Not specified'}</option>)}
                </select>
              </div>
              <Button variant="primary" onClick={handleSave} loading={loading}>Save Changes</Button>
            </div>
          ) : (
            <div className="grid sm:grid-cols-2 gap-4 text-sm">
              <div><p className="text-gray-400 mb-1">Full Name</p><p className="font-medium text-gray-800 dark:text-gray-100">{user?.name}</p></div>
              <div><p className="text-gray-400 mb-1">Email</p><p className="font-medium text-gray-800 dark:text-gray-100">{user?.email}</p></div>
              <div><p className="text-gray-400 mb-1">Phone</p><p className="font-medium text-gray-800 dark:text-gray-100">{user?.phone || 'Not set'}</p></div>
              <div><p className="text-gray-400 mb-1">Skin Type</p><p className="font-medium text-gray-800 dark:text-gray-100 capitalize">{user?.skinType || 'Not set'}</p></div>
            </div>
          )}
        </div>

        {/* Recent orders */}
        <div className="glass-card-solid rounded-2xl p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-display font-semibold text-lg text-gray-900 dark:text-white">Recent Orders</h2>
            <Link to="/dashboard/orders" className="text-sm text-pink-500 hover:underline flex items-center gap-1">View All <FaArrowRight size={10} /></Link>
          </div>
          {recentOrders.length === 0 ? (
            <p className="text-gray-400 text-sm py-4 text-center">No orders yet.</p>
          ) : (
            <div className="space-y-3">
              {recentOrders.map((order) => (
                <Link key={order._id} to={`/dashboard/orders/${order._id}`} className="flex items-center justify-between p-3 rounded-xl hover:bg-pink-50 dark:hover:bg-pink-900/20 transition-colors">
                  <div>
                    <p className="font-medium text-sm text-gray-800 dark:text-gray-100">{order.orderNumber}</p>
                    <p className="text-xs text-gray-400">{new Date(order.createdAt).toLocaleDateString()}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold text-sm text-gray-800 dark:text-gray-100">₹{order.totalPrice.toLocaleString('en-IN')}</p>
                    <span className={`badge-${order.orderStatus === 'delivered' ? 'green' : order.orderStatus === 'cancelled' ? 'red' : 'pink'} text-[10px] capitalize`}>{order.orderStatus}</span>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </div>
      </DashboardLayout>
    </MainLayout>
  )
}

export default DashboardOverview
