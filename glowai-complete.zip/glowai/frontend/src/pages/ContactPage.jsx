import React, { useState } from 'react'
import { motion } from 'framer-motion'
import { FaMapMarkerAlt, FaPhoneAlt, FaEnvelope, FaPaperPlane, FaClock } from 'react-icons/fa'
import toast from 'react-hot-toast'
import MainLayout from '../components/layout/MainLayout'
import SEO from '../components/common/SEO'
import Button from '../components/common/Button'
import { contactAPI } from '../services/api'

const ContactPage = () => {
  const [form, setForm] = useState({ name: '', email: '', subject: '', message: '' })
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)
    try {
      const { data } = await contactAPI.send(form)
      toast.success(data.message)
      setForm({ name: '', email: '', subject: '', message: '' })
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to send message')
    } finally {
      setLoading(false)
    }
  }

  return (
    <MainLayout>
      <SEO title="Contact Us" description="Get in touch with the GlowAI team for support, feedback, or partnership inquiries." />

      <div className="bg-gradient-hero py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="section-heading">Get In Touch</h1>
          <p className="section-subheading mx-auto">We'd love to hear from you. Our team is here to help with anything you need.</p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Contact info */}
          <div className="space-y-4">
            {[
              { icon: FaMapMarkerAlt, title: 'Visit Us', text: '123 Beauty Lane, Mumbai, Maharashtra, India 400001' },
              { icon: FaPhoneAlt, title: 'Call Us', text: '+91 98765 43210' },
              { icon: FaEnvelope, title: 'Email Us', text: 'hello@glowai.com' },
              { icon: FaClock, title: 'Business Hours', text: 'Mon - Sat: 9:00 AM - 7:00 PM' },
            ].map((item, i) => (
              <motion.div key={i} initial={{ opacity: 0, x: -10 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.1 }} className="glass-card-solid rounded-2xl p-5 flex items-start gap-4">
                <div className="w-11 h-11 rounded-full bg-pink-100 dark:bg-pink-900/30 flex items-center justify-center flex-shrink-0">
                  <item.icon className="text-pink-500" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-800 dark:text-white text-sm mb-1">{item.title}</h3>
                  <p className="text-sm text-gray-500 dark:text-gray-400">{item.text}</p>
                </div>
              </motion.div>
            ))}
          </div>

          {/* Form */}
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="lg:col-span-2 glass-card-solid rounded-3xl p-6 sm:p-8">
            <h2 className="font-display font-semibold text-xl text-gray-900 dark:text-white mb-6">Send us a Message</h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid sm:grid-cols-2 gap-4">
                <input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Your Name" className="input-field" />
                <input required type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder="Your Email" className="input-field" />
              </div>
              <input required value={form.subject} onChange={(e) => setForm({ ...form, subject: e.target.value })} placeholder="Subject" className="input-field" />
              <textarea required value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} placeholder="Your Message" className="input-field min-h-[150px] resize-none" />
              <Button type="submit" variant="primary" size="lg" icon={FaPaperPlane} loading={loading}>Send Message</Button>
            </form>
          </motion.div>
        </div>
      </div>
    </MainLayout>
  )
}

export default ContactPage
