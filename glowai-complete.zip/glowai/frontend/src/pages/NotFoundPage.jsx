import React from 'react'
import { Link } from 'react-router-dom'
import MainLayout from '../components/layout/MainLayout'
import SEO from '../components/common/SEO'
import Button from '../components/common/Button'

const NotFoundPage = () => (
  <MainLayout>
    <SEO title="Page Not Found" />
    <div className="min-h-[70vh] flex flex-col items-center justify-center text-center px-4">
      <div className="text-7xl mb-4">🌸</div>
      <h1 className="text-4xl font-display font-bold text-gray-900 dark:text-white mb-2">404 — Page Not Found</h1>
      <p className="text-gray-500 dark:text-gray-400 mb-8 max-w-md">The page you're looking for doesn't exist or has been moved.</p>
      <Link to="/"><Button variant="primary">Back to Home</Button></Link>
    </div>
  </MainLayout>
)

export default NotFoundPage
