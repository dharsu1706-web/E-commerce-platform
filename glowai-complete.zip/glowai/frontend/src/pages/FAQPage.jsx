import React, { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { FaChevronDown } from 'react-icons/fa'
import MainLayout from '../components/layout/MainLayout'
import SEO from '../components/common/SEO'

const faqs = [
  {
    category: 'Orders & Shipping',
    items: [
      { q: 'How long does shipping take?', a: 'Standard shipping takes 3-5 business days within India. Orders above ₹999 qualify for free shipping. Express delivery options are available at checkout for select pin codes.' },
      { q: 'Can I track my order?', a: 'Yes! Once your order ships, you\'ll receive a tracking number via email. You can also track your order status anytime from your Dashboard under "My Orders".' },
      { q: 'Do you ship internationally?', a: 'Currently we ship only within India. We\'re working on expanding to international markets soon!' },
    ],
  },
  {
    category: 'Returns & Refunds',
    items: [
      { q: 'What is your return policy?', a: 'We offer a 7-day easy return policy for unopened products in original packaging. If you receive a damaged or incorrect item, contact us within 48 hours for a free replacement.' },
      { q: 'How do I request a refund?', a: 'Go to your Order Details page and select "Request Return". Our team will review and process approved refunds within 5-7 business days to your original payment method.' },
    ],
  },
  {
    category: 'AI Beauty Assistant',
    items: [
      { q: 'How does the AI recommend products?', a: 'Our GlowAI Assistant analyzes your skin type, concerns, and preferences (either from chat or the Skin Quiz) to match you with products containing the most suitable ingredients and formulations.' },
      { q: 'Is the Skin Quiz accurate?', a: 'The Skin Quiz is designed by skincare experts and continuously refined based on user feedback. While it provides excellent general guidance, we recommend consulting a dermatologist for specific medical skin conditions.' },
      { q: 'Can I retake the skin quiz?', a: 'Absolutely! Your skin can change over time, so feel free to retake the quiz whenever you want updated recommendations.' },
    ],
  },
  {
    category: 'Products',
    items: [
      { q: 'Are your products cruelty-free?', a: 'Yes, all GlowAI products are cruelty-free and never tested on animals. We\'re proud to be a 100% vegan-friendly beauty brand.' },
      { q: 'How do I know which products suit my skin?', a: 'Take our AI Skin Quiz, chat with our GlowAI Assistant, or check the "Skin Type" tags on each product page for personalized guidance.' },
      { q: 'Do products have an expiry date?', a: 'Yes, all products have a shelf life of 12-24 months from manufacturing date, clearly marked on the packaging. We recommend using opened products within 6-12 months.' },
    ],
  },
  {
    category: 'Account & Payments',
    items: [
      { q: 'What payment methods do you accept?', a: 'We accept Credit/Debit Cards, UPI, Net Banking, and Cash on Delivery (COD) for eligible orders.' },
      { q: 'Is my payment information secure?', a: 'Yes, we use industry-standard encryption and never store your full card details on our servers.' },
      { q: 'How do I delete my account?', a: 'Please contact our support team at hello@glowai.com to request account deletion. We\'ll process your request within 7 business days.' },
    ],
  },
]

const FAQItem = ({ item, isOpen, onClick }) => (
  <div className="glass-card-solid rounded-2xl overflow-hidden">
    <button onClick={onClick} className="w-full flex items-center justify-between p-5 text-left">
      <span className="font-medium text-gray-800 dark:text-white pr-4">{item.q}</span>
      <FaChevronDown className={`text-pink-500 flex-shrink-0 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
    </button>
    <AnimatePresence>
      {isOpen && (
        <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="overflow-hidden">
          <p className="px-5 pb-5 text-sm text-gray-500 dark:text-gray-400 leading-relaxed">{item.a}</p>
        </motion.div>
      )}
    </AnimatePresence>
  </div>
)

const FAQPage = () => {
  const [openItems, setOpenItems] = useState({})

  const toggle = (catIdx, itemIdx) => {
    const key = `${catIdx}-${itemIdx}`
    setOpenItems((prev) => ({ ...prev, [key]: !prev[key] }))
  }

  return (
    <MainLayout>
      <SEO title="Frequently Asked Questions" description="Find answers to common questions about GlowAI products, shipping, returns, and our AI beauty assistant." />

      <div className="bg-gradient-hero py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="section-heading">Frequently Asked Questions</h1>
          <p className="section-subheading mx-auto">Everything you need to know about GlowAI</p>
        </div>
      </div>

      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        {faqs.map((cat, catIdx) => (
          <div key={cat.category} className="mb-10">
            <h2 className="text-xl font-display font-semibold text-gray-900 dark:text-white mb-4">{cat.category}</h2>
            <div className="space-y-3">
              {cat.items.map((item, itemIdx) => (
                <FAQItem key={itemIdx} item={item} isOpen={!!openItems[`${catIdx}-${itemIdx}`]} onClick={() => toggle(catIdx, itemIdx)} />
              ))}
            </div>
          </div>
        ))}
      </div>
    </MainLayout>
  )
}

export default FAQPage
