import React from 'react'
import MainLayout from '../components/layout/MainLayout'
import SEO from '../components/common/SEO'

const TermsPage = () => {
  return (
    <MainLayout>
      <SEO title="Terms of Service" description="Read GlowAI's terms of service governing use of our website and products." />

      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <h1 className="section-heading mb-2">Terms of Service</h1>
        <p className="text-gray-400 text-sm mb-8">Last updated: January 2026</p>

        <div className="space-y-8 text-gray-600 dark:text-gray-300 leading-relaxed">
          <section>
            <h2 className="text-xl font-display font-semibold text-gray-900 dark:text-white mb-3">1. Acceptance of Terms</h2>
            <p>By accessing or using the GlowAI website and services, you agree to be bound by these Terms of Service and our Privacy Policy. If you do not agree, please do not use our services.</p>
          </section>

          <section>
            <h2 className="text-xl font-display font-semibold text-gray-900 dark:text-white mb-3">2. Account Registration</h2>
            <p>To make purchases, you must create an account with accurate information. You are responsible for maintaining the confidentiality of your account credentials and for all activities under your account.</p>
          </section>

          <section>
            <h2 className="text-xl font-display font-semibold text-gray-900 dark:text-white mb-3">3. Orders & Pricing</h2>
            <p>All prices are listed in Indian Rupees (₹) and are subject to change without notice. We reserve the right to refuse or cancel any order for any reason, including pricing errors or stock unavailability.</p>
          </section>

          <section>
            <h2 className="text-xl font-display font-semibold text-gray-900 dark:text-white mb-3">4. AI Recommendations Disclaimer</h2>
            <p>Our GlowAI Assistant and Skin Quiz provide general skincare guidance based on algorithmic analysis of your responses. These recommendations are not medical advice. For specific skin conditions, please consult a licensed dermatologist.</p>
          </section>

          <section>
            <h2 className="text-xl font-display font-semibold text-gray-900 dark:text-white mb-3">5. Shipping & Delivery</h2>
            <p>Delivery times are estimates and not guaranteed. GlowAI is not liable for delays caused by courier partners, weather, or circumstances beyond our control.</p>
          </section>

          <section>
            <h2 className="text-xl font-display font-semibold text-gray-900 dark:text-white mb-3">6. Returns & Refunds</h2>
            <p>Returns are accepted within 7 days of delivery for unopened products in original packaging, as described in our Privacy Policy and Refund Policy. Refunds are processed to the original payment method within 5-7 business days.</p>
          </section>

          <section>
            <h2 className="text-xl font-display font-semibold text-gray-900 dark:text-white mb-3">7. Intellectual Property</h2>
            <p>All content on this website, including text, graphics, logos, and software, is the property of GlowAI and protected by applicable intellectual property laws. Unauthorized use is prohibited.</p>
          </section>

          <section>
            <h2 className="text-xl font-display font-semibold text-gray-900 dark:text-white mb-3">8. Limitation of Liability</h2>
            <p>GlowAI shall not be liable for any indirect, incidental, or consequential damages arising from the use of our products or services, to the extent permitted by applicable law.</p>
          </section>

          <section>
            <h2 className="text-xl font-display font-semibold text-gray-900 dark:text-white mb-3">9. Governing Law</h2>
            <p>These Terms are governed by the laws of India. Any disputes shall be subject to the exclusive jurisdiction of the courts of Mumbai, Maharashtra.</p>
          </section>

          <section>
            <h2 className="text-xl font-display font-semibold text-gray-900 dark:text-white mb-3">10. Contact</h2>
            <p>For questions about these Terms, please contact us at hello@glowai.com.</p>
          </section>
        </div>
      </div>
    </MainLayout>
  )
}

export default TermsPage
