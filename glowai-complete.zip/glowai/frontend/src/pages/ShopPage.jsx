import React, { useState, useEffect, useCallback } from 'react'
import { useSearchParams } from 'react-router-dom'
import { motion } from 'framer-motion'
import { FaFilter, FaSearch, FaTimes } from 'react-icons/fa'
import MainLayout from '../components/layout/MainLayout'
import SEO from '../components/common/SEO'
import ProductCard from '../components/common/ProductCard'
import { ProductGridSkeleton } from '../components/common/Loaders'
import EmptyState from '../components/common/EmptyState'
import ShopFilters from '../components/shop/ShopFilters'
import Pagination from '../components/shop/Pagination'
import { productAPI, categoryAPI } from '../services/api'

const sortOptions = [
  { value: '', label: 'Newest' },
  { value: 'price_asc', label: 'Price: Low to High' },
  { value: 'price_desc', label: 'Price: High to Low' },
  { value: 'rating', label: 'Highest Rated' },
  { value: 'popular', label: 'Most Popular' },
]

const ShopPage = () => {
  const [searchParams, setSearchParams] = useSearchParams()
  const [products, setProducts] = useState([])
  const [categories, setCategories] = useState([])
  const [loading, setLoading] = useState(true)
  const [total, setTotal] = useState(0)
  const [pages, setPages] = useState(1)
  const [mobileFiltersOpen, setMobileFiltersOpen] = useState(false)
  const [searchInput, setSearchInput] = useState(searchParams.get('search') || '')

  const filters = {
    search: searchParams.get('search') || '',
    category: searchParams.get('category') || '',
    minPrice: searchParams.get('minPrice') ? Number(searchParams.get('minPrice')) : undefined,
    maxPrice: searchParams.get('maxPrice') ? Number(searchParams.get('maxPrice')) : undefined,
    skinType: searchParams.get('skinType') || '',
    sort: searchParams.get('sort') || '',
    featured: searchParams.get('featured') || '',
    bestSeller: searchParams.get('bestSeller') || '',
    trending: searchParams.get('trending') || '',
    isNew: searchParams.get('isNew') || '',
    page: Number(searchParams.get('page')) || 1,
  }

  useEffect(() => {
    categoryAPI.getAll().then(({ data }) => setCategories(data.categories)).catch(() => {})
  }, [])

  useEffect(() => {
    setLoading(true)
    const params = { ...filters, limit: 12 }
    Object.keys(params).forEach((key) => (params[key] === '' || params[key] === undefined) && delete params[key])

    productAPI.getAll(params)
      .then(({ data }) => {
        setProducts(data.products)
        setTotal(data.total)
        setPages(data.pages)
      })
      .catch(() => setProducts([]))
      .finally(() => setLoading(false))
  }, [searchParams])

  const updateFilters = useCallback((updates) => {
    const newParams = new URLSearchParams(searchParams)
    Object.entries(updates).forEach(([key, value]) => {
      if (value === '' || value === undefined || value === null) {
        newParams.delete(key)
      } else {
        newParams.set(key, value)
      }
    })
    newParams.delete('page') // Reset page on filter change
    setSearchParams(newParams)
  }, [searchParams, setSearchParams])

  const handlePageChange = (newPage) => {
    const newParams = new URLSearchParams(searchParams)
    newParams.set('page', newPage)
    setSearchParams(newParams)
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  const handleSearchSubmit = (e) => {
    e.preventDefault()
    updateFilters({ search: searchInput })
  }

  const clearFilters = () => {
    setSearchParams({})
    setSearchInput('')
  }

  const activeFilterCount = [filters.category, filters.minPrice, filters.skinType, filters.search].filter(Boolean).length

  return (
    <MainLayout>
      <SEO title="Shop All Products" description="Browse our complete collection of premium skincare and beauty products." />

      <div className="bg-gradient-hero py-10 lg:py-14">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="section-heading">Shop GlowAI</h1>
          <p className="section-subheading mx-auto">Discover {total > 0 ? total : ''} premium products curated for your skin</p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Search bar */}
        <form onSubmit={handleSearchSubmit} className="mb-6">
          <div className="relative max-w-xl">
            <FaSearch className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              placeholder="Search products, brands, ingredients..."
              className="input-field pl-11"
            />
            {searchInput && (
              <button type="button" onClick={() => { setSearchInput(''); updateFilters({ search: '' }) }} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-pink-500">
                <FaTimes size={14} />
              </button>
            )}
          </div>
        </form>

        <div className="flex gap-8">
          {/* Desktop sidebar */}
          <aside className="hidden lg:block w-72 flex-shrink-0">
            <ShopFilters categories={categories} filters={filters} onChange={updateFilters} onClear={clearFilters} />
          </aside>

          {/* Main content */}
          <div className="flex-1">
            {/* Toolbar */}
            <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
              <p className="text-sm text-gray-500 dark:text-gray-400">
                Showing <span className="font-semibold text-gray-800 dark:text-gray-200">{products.length}</span> of {total} products
                {activeFilterCount > 0 && <span className="text-pink-500"> ({activeFilterCount} filters applied)</span>}
              </p>
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setMobileFiltersOpen(true)}
                  className="lg:hidden flex items-center gap-2 text-sm font-medium border border-pink-200 dark:border-pink-800 rounded-full px-4 py-2 text-gray-700 dark:text-gray-300"
                >
                  <FaFilter size={12} /> Filters
                  {activeFilterCount > 0 && <span className="bg-pink-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">{activeFilterCount}</span>}
                </button>
                <select
                  value={filters.sort}
                  onChange={(e) => updateFilters({ sort: e.target.value })}
                  className="input-field py-2 text-sm w-auto"
                >
                  {sortOptions.map((opt) => <option key={opt.value} value={opt.value}>{opt.label}</option>)}
                </select>
              </div>
            </div>

            {/* Products grid */}
            {loading ? (
              <ProductGridSkeleton count={12} />
            ) : products.length === 0 ? (
              <EmptyState
                icon={FaSearch}
                title="No products found"
                message="Try adjusting your filters or search terms to find what you're looking for."
                actionLabel="Clear Filters"
                onAction={clearFilters}
              />
            ) : (
              <motion.div
                className="grid grid-cols-2 sm:grid-cols-3 gap-4 md:gap-6"
                initial="hidden"
                animate="visible"
              >
                {products.map((p, i) => <ProductCard key={p._id} product={p} index={i} />)}
              </motion.div>
            )}

            <Pagination page={filters.page} pages={pages} onChange={handlePageChange} />
          </div>
        </div>
      </div>

      {/* Mobile filters drawer */}
      {mobileFiltersOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-black/50" onClick={() => setMobileFiltersOpen(false)} />
          <motion.div
            initial={{ x: '-100%' }}
            animate={{ x: 0 }}
            exit={{ x: '-100%' }}
            className="absolute left-0 top-0 h-full w-80 max-w-[85vw] bg-white dark:bg-gray-900 p-5 overflow-y-auto custom-scroll"
          >
            <ShopFilters
              categories={categories}
              filters={filters}
              onChange={(u) => { updateFilters(u) }}
              onClear={() => { clearFilters(); setMobileFiltersOpen(false) }}
              isMobile
              onClose={() => setMobileFiltersOpen(false)}
            />
          </motion.div>
        </div>
      )}
    </MainLayout>
  )
}

export default ShopPage
