import React, { useState, useEffect } from 'react'
import { useParams, Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import { FaHeart, FaRegHeart, FaShoppingBag, FaMinus, FaPlus, FaCheckCircle, FaTruck, FaUndo, FaShieldAlt } from 'react-icons/fa'
import toast from 'react-hot-toast'
import MainLayout from '../components/layout/MainLayout'
import SEO from '../components/common/SEO'
import StarRating from '../components/common/StarRating'
import PriceTag from '../components/common/PriceTag'
import Button from '../components/common/Button'
import ProductGallery from '../components/product/ProductGallery'
import ProductTabs from '../components/product/ProductTabs'
import ProductCard from '../components/common/ProductCard'
import { PageLoader, TextSkeleton } from '../components/common/Loaders'
import { productAPI, wishlistAPI } from '../services/api'
import { useCart } from '../context/CartContext'
import { useAuth } from '../context/AuthContext'

const ProductDetailsPage = () => {
  const { id } = useParams()
  const { addItem } = useCart()
  const { isAuthenticated, user } = useAuth()
  const [product, setProduct] = useState(null)
  const [reviews, setReviews] = useState([])
  const [related, setRelated] = useState([])
  const [loading, setLoading] = useState(true)
  const [quantity, setQuantity] = useState(1)
  const [isWishlisted, setIsWishlisted] = useState(false)
  const [wishLoading, setWishLoading] = useState(false)

  useEffect(() => {
    setLoading(true)
    setQuantity(1)
    productAPI.getOne(id)
      .then(({ data }) => {
        setProduct(data.product)
        setReviews(data.reviews)
        setRelated(data.related)
        setIsWishlisted(user?.wishlist?.some?.((p) => (p === data.product._id || p?._id === data.product._id)) || false)
      })
      .catch(() => setProduct(null))
      .finally(() => setLoading(false))
    window.scrollTo(0, 0)
  }, [id, user])

  const handleAddToCart = () => {
    if (product.stock === 0) {
      toast.error('Product is out of stock')
      return
    }
    addItem(product, quantity)
  }

  const handleWishlist = async () => {
    if (!isAuthenticated) {
      toast.error('Please login to add to wishlist')
      return
    }
    setWishLoading(true)
    try {
      const { data } = await wishlistAPI.toggle(product._id)
      setIsWishlisted(data.inWishlist)
      toast.success(data.message)
    } catch {
      toast.error('Something went wrong')
    } finally {
      setWishLoading(false)
    }
  }

  const handleReviewSubmit = (newReview) => {
    setReviews((prev) => [newReview, ...prev])
    setProduct((prev) => ({ ...prev, numReviews: prev.numReviews + 1 }))
  }

  if (loading) return <MainLayout><PageLoader /></MainLayout>

  if (!product) {
    return (
      <MainLayout>
        <div className="max-w-7xl mx-auto px-4 py-20 text-center">
          <h2 className="text-2xl font-display font-semibold mb-4">Product Not Found</h2>
          <Link to="/shop"><Button variant="primary">Back to Shop</Button></Link>
        </div>
      </MainLayout>
    )
  }

  const outOfStock = product.stock === 0

  return (
    <MainLayout>
      <SEO
        title={product.name}
        description={product.shortDescription || product.description?.slice(0, 160)}
        image={product.images?.[0]?.url}
        type="product"
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Breadcrumb */}
        <div className="text-sm text-gray-500 dark:text-gray-400 mb-6 flex items-center gap-2 flex-wrap">
          <Link to="/" className="hover:text-pink-500">Home</Link> /
          <Link to="/shop" className="hover:text-pink-500">Shop</Link> /
          {product.category?.name && <><Link to={`/shop?category=${product.category._id}`} className="hover:text-pink-500">{product.category.name}</Link> /</>}
          <span className="text-gray-800 dark:text-gray-200 truncate">{product.name}</span>
        </div>

        <div className="grid lg:grid-cols-2 gap-10 lg:gap-16">
          {/* Gallery */}
          <ProductGallery images={product.images} />

          {/* Details */}
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4 }}>
            {product.brand && <p className="text-sm text-pink-500 font-semibold uppercase tracking-wide mb-2">{product.brand}</p>}
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-display font-bold text-gray-900 dark:text-white mb-3">{product.name}</h1>

            <div className="flex items-center gap-3 mb-4">
              <StarRating rating={product.ratings} size={16} showCount count={product.numReviews} />
              {product.sold > 0 && <span className="text-sm text-gray-400">· {product.sold} sold</span>}
            </div>

            <PriceTag price={product.price} discountPrice={product.discountPrice} size="xl" className="mb-4" />

            {product.shortDescription && <p className="text-gray-600 dark:text-gray-300 mb-6">{product.shortDescription}</p>}

            {/* Stock status */}
            <div className="mb-6">
              {outOfStock ? (
                <span className="badge-red">Out of Stock</span>
              ) : product.stock <= 10 ? (
                <span className="badge-yellow">Only {product.stock} left in stock!</span>
              ) : (
                <span className="badge-green"><FaCheckCircle size={10} /> In Stock</span>
              )}
            </div>

            {/* Skin type tags */}
            {product.skinType?.length > 0 && (
              <div className="flex flex-wrap gap-2 mb-6">
                {product.skinType.map((type) => (
                  <span key={type} className="badge-pink capitalize">{type} skin</span>
                ))}
              </div>
            )}

            {/* Quantity + Add to cart */}
            <div className="flex items-center gap-4 mb-6">
              <div className="flex items-center border border-pink-200 dark:border-pink-800 rounded-full">
                <button onClick={() => setQuantity((q) => Math.max(1, q - 1))} className="p-3 text-gray-500 hover:text-pink-500 transition-colors">
                  <FaMinus size={12} />
                </button>
                <span className="w-10 text-center font-semibold">{quantity}</span>
                <button onClick={() => setQuantity((q) => Math.min(product.stock, q + 1))} className="p-3 text-gray-500 hover:text-pink-500 transition-colors">
                  <FaPlus size={12} />
                </button>
              </div>

              <Button variant="primary" size="lg" icon={FaShoppingBag} onClick={handleAddToCart} disabled={outOfStock} className="flex-1">
                {outOfStock ? 'Out of Stock' : 'Add to Bag'}
              </Button>

              <button
                onClick={handleWishlist}
                disabled={wishLoading}
                className="w-14 h-14 flex-shrink-0 rounded-full border border-pink-200 dark:border-pink-800 flex items-center justify-center text-pink-500 hover:bg-pink-50 dark:hover:bg-pink-900/20 transition-colors"
              >
                {isWishlisted ? <FaHeart size={20} /> : <FaRegHeart size={20} />}
              </button>
            </div>

            {/* Trust badges */}
            <div className="grid grid-cols-3 gap-3 mb-6">
              <div className="flex flex-col items-center gap-2 text-center glass-card-solid rounded-xl p-3">
                <FaTruck className="text-pink-500" size={18} />
                <span className="text-xs text-gray-600 dark:text-gray-300">Free shipping over ₹999</span>
              </div>
              <div className="flex flex-col items-center gap-2 text-center glass-card-solid rounded-xl p-3">
                <FaUndo className="text-pink-500" size={18} />
                <span className="text-xs text-gray-600 dark:text-gray-300">7-day easy returns</span>
              </div>
              <div className="flex flex-col items-center gap-2 text-center glass-card-solid rounded-xl p-3">
                <FaShieldAlt className="text-pink-500" size={18} />
                <span className="text-xs text-gray-600 dark:text-gray-300">100% authentic</span>
              </div>
            </div>

            {/* Volume */}
            {product.volume && (
              <p className="text-sm text-gray-500 dark:text-gray-400">Volume: <span className="font-medium text-gray-700 dark:text-gray-300">{product.volume}</span></p>
            )}
          </motion.div>
        </div>

        {/* Tabs */}
        <ProductTabs product={product} reviews={reviews} onReviewSubmit={handleReviewSubmit} />

        {/* Related products */}
        {related.length > 0 && (
          <div className="mt-16">
            <h2 className="section-heading mb-8">You May Also Like</h2>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 md:gap-6">
              {related.map((p, i) => <ProductCard key={p._id} product={p} index={i} />)}
            </div>
          </div>
        )}
      </div>
    </MainLayout>
  )
}

export default ProductDetailsPage
