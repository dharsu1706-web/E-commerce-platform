import React, { useState, useEffect } from 'react'
import { FaSearch, FaEye } from 'react-icons/fa'
import toast from 'react-hot-toast'
import { motion } from 'framer-motion'
import MainLayout from '../../components/layout/MainLayout'
import SEO from '../../components/common/SEO'
import AdminLayout from '../../components/admin/AdminLayout'
import Pagination from '../../components/shop/Pagination'
import Button from '../../components/common/Button'
import { TextSkeleton, PageLoader } from '../../components/common/Loaders'
import { orderAPI } from '../../services/api'

const statusOptions = ['pending', 'processing', 'shipped', 'delivered', 'cancelled', 'refunded']
const statusColors = { pending: 'badge-yellow', processing: 'badge-pink', shipped: 'badge-pink', delivered: 'badge-green', cancelled: 'badge-red', refunded: 'badge-gray' }

const AdminOrdersPage = () => {
  const [orders, setOrders] = useState([])
  const [loading, setLoading] = useState(true)
  const [page, setPage] = useState(1)
  const [pages, setPages] = useState(1)
  const [search, setSearch] = useState('')
  const [statusFilter, setStatusFilter] = useState('')
  const [selectedOrder, setSelectedOrder] = useState(null)

  const fetchOrders = () => {
    setLoading(true)
    orderAPI.getAll({ page, limit: 10, search, status: statusFilter })
      .then(({ data }) => { setOrders(data.orders); setPages(data.pages) })
      .finally(() => setLoading(false))
  }

  useEffect(() => { fetchOrders() }, [page, search, statusFilter])

  const handleStatusChange = async (orderId, newStatus) => {
    try {
      const { data } = await orderAPI.updateStatus(orderId, { status: newStatus })
      toast.success(data.message)
      fetchOrders()
      if (selectedOrder?._id === orderId) setSelectedOrder(data.order)
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to update status')
    }
  }

  return (
    <MainLayout>
      <SEO title="Manage Orders" />
      <AdminLayout title="Orders">
        <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
          <div className="relative max-w-xs">
            <FaSearch className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={12} />
            <input value={search} onChange={(e) => { setSearch(e.target.value); setPage(1) }} placeholder="Search order number..." className="input-field pl-10 py-2 text-sm" />
          </div>
          <select value={statusFilter} onChange={(e) => { setStatusFilter(e.target.value); setPage(1) }} className="input-field py-2 text-sm w-auto">
            <option value="">All Statuses</option>
            {statusOptions.map((s) => <option key={s} value={s}>{s.charAt(0).toUpperCase() + s.slice(1)}</option>)}
          </select>
        </div>

        {loading ? (
          <div className="space-y-3">{[1, 2, 3, 4, 5].map((i) => <div key={i} className="glass-card-solid rounded-2xl p-4"><TextSkeleton lines={1} /></div>)}</div>
        ) : (
          <div className="glass-card-solid rounded-2xl overflow-hidden overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-pink-50 dark:bg-pink-900/20">
                <tr>
                  <th className="text-left p-4 font-semibold text-gray-700 dark:text-gray-300">Order</th>
                  <th className="text-left p-4 font-semibold text-gray-700 dark:text-gray-300">Customer</th>
                  <th className="text-left p-4 font-semibold text-gray-700 dark:text-gray-300">Date</th>
                  <th className="text-left p-4 font-semibold text-gray-700 dark:text-gray-300">Total</th>
                  <th className="text-left p-4 font-semibold text-gray-700 dark:text-gray-300">Status</th>
                  <th className="text-right p-4 font-semibold text-gray-700 dark:text-gray-300">Actions</th>
                </tr>
              </thead>
              <tbody>
                {orders.map((order) => (
                  <tr key={order._id} className="border-t border-pink-50 dark:border-pink-900/20">
                    <td className="p-4 font-medium text-gray-800 dark:text-gray-100">{order.orderNumber}</td>
                    <td className="p-4 text-gray-600 dark:text-gray-300">
                      <p>{order.user?.name}</p>
                      <p className="text-xs text-gray-400">{order.user?.email}</p>
                    </td>
                    <td className="p-4 text-gray-600 dark:text-gray-300">{new Date(order.createdAt).toLocaleDateString()}</td>
                    <td className="p-4 font-semibold text-gray-800 dark:text-gray-100">₹{order.totalPrice.toLocaleString('en-IN')}</td>
                    <td className="p-4">
                      <select value={order.orderStatus} onChange={(e) => handleStatusChange(order._id, e.target.value)} className={`text-xs rounded-full px-3 py-1.5 border-0 focus:ring-2 focus:ring-pink-400 ${statusColors[order.orderStatus]}`}>
                        {statusOptions.map((s) => <option key={s} value={s}>{s.charAt(0).toUpperCase() + s.slice(1)}</option>)}
                      </select>
                    </td>
                    <td className="p-4 text-right">
                      <button onClick={() => setSelectedOrder(order)} className="btn-icon"><FaEye size={14} /></button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        <Pagination page={page} pages={pages} onChange={setPage} />

        {/* Order details modal */}
        {selectedOrder && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <div className="absolute inset-0 bg-black/50" onClick={() => setSelectedOrder(null)} />
            <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="relative bg-white dark:bg-gray-900 rounded-3xl w-full max-w-2xl max-h-[85vh] overflow-y-auto custom-scroll p-6 sm:p-8">
              <h2 className="text-xl font-display font-semibold text-gray-900 dark:text-white mb-4">{selectedOrder.orderNumber}</h2>
              <div className="space-y-4">
                <div className="grid sm:grid-cols-2 gap-4 text-sm">
                  <div className="glass-card-solid rounded-xl p-4">
                    <p className="text-gray-400 mb-1">Customer</p>
                    <p className="font-medium text-gray-800 dark:text-gray-100">{selectedOrder.user?.name}</p>
                    <p className="text-gray-500">{selectedOrder.user?.email}</p>
                  </div>
                  <div className="glass-card-solid rounded-xl p-4">
                    <p className="text-gray-400 mb-1">Shipping Address</p>
                    <p className="text-gray-700 dark:text-gray-300">{selectedOrder.shippingAddress.street}, {selectedOrder.shippingAddress.city}, {selectedOrder.shippingAddress.state} {selectedOrder.shippingAddress.zipCode}</p>
                  </div>
                </div>
                <div>
                  <h3 className="font-semibold text-gray-800 dark:text-white mb-2">Items</h3>
                  {selectedOrder.items.map((item, i) => (
                    <div key={i} className="flex items-center gap-3 py-2">
                      <img src={item.image} alt={item.name} className="w-12 h-12 rounded-lg object-cover" />
                      <div className="flex-1">
                        <p className="text-sm font-medium text-gray-800 dark:text-gray-100">{item.name}</p>
                        <p className="text-xs text-gray-400">Qty: {item.quantity} × ₹{item.price}</p>
                      </div>
                      <p className="text-sm font-semibold text-gray-800 dark:text-gray-100">₹{(item.price * item.quantity).toLocaleString('en-IN')}</p>
                    </div>
                  ))}
                </div>
                <div className="flex justify-end">
                  <Button variant="ghost" onClick={() => setSelectedOrder(null)}>Close</Button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AdminLayout>
    </MainLayout>
  )
}

export default AdminOrdersPage
