import React, { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { FaRupeeSign, FaShoppingCart, FaUsers, FaBoxOpen, FaExclamationTriangle } from 'react-icons/fa'
import { AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts'
import MainLayout from '../../components/layout/MainLayout'
import SEO from '../../components/common/SEO'
import AdminLayout from '../../components/admin/AdminLayout'
import StatCard from '../../components/admin/StatCard'
import { PageLoader } from '../../components/common/Loaders'
import { dashboardAPI } from '../../services/api'

const COLORS = ['#ec4899', '#f472b6', '#f9a8d4', '#fbcfe8', '#fce7f3', '#9d174d', '#be185d'];

const statusLabels = { pending: 'Pending', processing: 'Processing', shipped: 'Shipped', delivered: 'Delivered', cancelled: 'Cancelled', refunded: 'Refunded' };

const AdminDashboardPage = () => {
  const [data, setData] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    dashboardAPI.getStats().then(({ data }) => setData(data)).finally(() => setLoading(false))
  }, [])

  if (loading) return <MainLayout><AdminLayout title="Dashboard"><PageLoader /></AdminLayout></MainLayout>
  if (!data) return <MainLayout><AdminLayout title="Dashboard"><p>Failed to load dashboard.</p></AdminLayout></MainLayout>

  const { stats, topProducts, recentOrders, monthlyRevenue, orderStatusStats, pendingReviews } = data
  const pieData = orderStatusStats.map((s) => ({ name: statusLabels[s._id] || s._id, value: s.count }))

  return (
    <MainLayout>
      <SEO title="Admin Dashboard" />
      <AdminLayout title="Dashboard Overview">
        {/* Stat cards */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <StatCard icon={FaRupeeSign} label="Total Revenue" value={stats.totalRevenue} growth={stats.revenueGrowth} prefix="₹" />
          <StatCard icon={FaShoppingCart} label="Total Orders" value={stats.totalOrders} growth={stats.orderGrowth} />
          <StatCard icon={FaUsers} label="Total Customers" value={stats.totalUsers} />
          <StatCard icon={FaBoxOpen} label="Active Products" value={stats.totalProducts} />
        </div>

        {/* Low stock alert */}
        {stats.lowStockProducts > 0 && (
          <div className="mb-6 flex items-center gap-3 bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-2xl p-4">
            <FaExclamationTriangle className="text-yellow-500" />
            <p className="text-sm text-yellow-700 dark:text-yellow-400">{stats.lowStockProducts} product(s) running low on stock. <Link to="/admin/products" className="underline font-medium">Review now</Link></p>
          </div>
        )}

        {/* Charts */}
        <div className="grid lg:grid-cols-3 gap-6 mb-6">
          <div className="lg:col-span-2 glass-card-solid rounded-2xl p-5">
            <h3 className="font-display font-semibold text-gray-900 dark:text-white mb-4">Revenue (Last 6 Months)</h3>
            <ResponsiveContainer width="100%" height={280}>
              <AreaChart data={monthlyRevenue}>
                <defs>
                  <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#ec4899" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#ec4899" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
                <XAxis dataKey="month" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} />
                <Tooltip formatter={(value) => `₹${value.toLocaleString('en-IN')}`} />
                <Area type="monotone" dataKey="revenue" stroke="#ec4899" fillOpacity={1} fill="url(#colorRevenue)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          <div className="glass-card-solid rounded-2xl p-5">
            <h3 className="font-display font-semibold text-gray-900 dark:text-white mb-4">Order Status</h3>
            <ResponsiveContainer width="100%" height={280}>
              <PieChart>
                <Pie data={pieData} cx="50%" cy="50%" innerRadius={50} outerRadius={80} paddingAngle={2} dataKey="value">
                  {pieData.map((entry, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Pie>
                <Tooltip />
                <Legend wrapperStyle={{ fontSize: 12 }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="grid lg:grid-cols-2 gap-6">
          {/* Top products */}
          <div className="glass-card-solid rounded-2xl p-5">
            <h3 className="font-display font-semibold text-gray-900 dark:text-white mb-4">Top Selling Products</h3>
            <div className="space-y-3">
              {topProducts.map((p, i) => (
                <div key={i} className="flex items-center gap-3">
                  <span className="text-sm font-bold text-pink-400 w-5">{i + 1}</span>
                  <img src={p.image} alt={p.name} className="w-10 h-10 rounded-lg object-cover" />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-800 dark:text-gray-100 line-clamp-1">{p.name}</p>
                    <p className="text-xs text-gray-400">{p.totalSold} sold</p>
                  </div>
                  <p className="text-sm font-semibold text-gray-800 dark:text-gray-100">₹{p.revenue.toLocaleString('en-IN')}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Recent orders */}
          <div className="glass-card-solid rounded-2xl p-5">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-display font-semibold text-gray-900 dark:text-white">Recent Orders</h3>
              <Link to="/admin/orders" className="text-xs text-pink-500 hover:underline">View All</Link>
            </div>
            <div className="space-y-3">
              {recentOrders.map((order) => (
                <Link key={order._id} to="/admin/orders" className="flex items-center justify-between hover:bg-pink-50 dark:hover:bg-pink-900/20 p-2 rounded-xl transition-colors">
                  <div>
                    <p className="text-sm font-medium text-gray-800 dark:text-gray-100">{order.orderNumber}</p>
                    <p className="text-xs text-gray-400">{order.user?.name}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-semibold text-gray-800 dark:text-gray-100">₹{order.totalPrice.toLocaleString('en-IN')}</p>
                    <span className="badge-pink text-[10px] capitalize">{order.orderStatus}</span>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </div>

        {pendingReviews > 0 && (
          <div className="mt-6 flex items-center gap-3 bg-pink-50 dark:bg-pink-900/20 border border-pink-200 dark:border-pink-800 rounded-2xl p-4">
            <FaExclamationTriangle className="text-pink-500" />
            <p className="text-sm text-pink-700 dark:text-pink-400">{pendingReviews} review(s) awaiting moderation. <Link to="/admin/reviews" className="underline font-medium">Review now</Link></p>
          </div>
        )}
      </AdminLayout>
    </MainLayout>
  )
}

export default AdminDashboardPage
