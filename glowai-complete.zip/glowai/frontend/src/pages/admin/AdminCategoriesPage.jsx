import React, { useState, useEffect } from 'react'
import { FaPlus, FaEdit, FaTrash, FaTimes } from 'react-icons/fa'
import toast from 'react-hot-toast'
import { motion } from 'framer-motion'
import MainLayout from '../../components/layout/MainLayout'
import SEO from '../../components/common/SEO'
import AdminLayout from '../../components/admin/AdminLayout'
import Button from '../../components/common/Button'
import { TextSkeleton } from '../../components/common/Loaders'
import { categoryAPI } from '../../services/api'

const emptyForm = { name: '', description: '', icon: '', order: 0 }

const AdminCategoriesPage = () => {
  const [categories, setCategories] = useState([])
  const [loading, setLoading] = useState(true)
  const [modalOpen, setModalOpen] = useState(false)
  const [editCategory, setEditCategory] = useState(null)
  const [form, setForm] = useState(emptyForm)
  const [saving, setSaving] = useState(false)

  const fetchCategories = () => {
    setLoading(true)
    categoryAPI.getAll().then(({ data }) => setCategories(data.categories)).finally(() => setLoading(false))
  }

  useEffect(() => { fetchCategories() }, [])

  const openModal = (cat = null) => {
    setEditCategory(cat)
    setForm(cat ? { name: cat.name, description: cat.description || '', icon: cat.icon || '', order: cat.order || 0 } : emptyForm)
    setModalOpen(true)
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setSaving(true)
    try {
      if (editCategory) {
        const { data } = await categoryAPI.update(editCategory._id, form)
        toast.success(data.message)
      } else {
        const { data } = await categoryAPI.create(form)
        toast.success(data.message)
      }
      setModalOpen(false)
      fetchCategories()
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to save category')
    } finally {
      setSaving(false)
    }
  }

  const handleDelete = async (id) => {
    if (!window.confirm('Delete this category?')) return
    try {
      const { data } = await categoryAPI.delete(id)
      toast.success(data.message)
      fetchCategories()
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to delete')
    }
  }

  return (
    <MainLayout>
      <SEO title="Manage Categories" />
      <AdminLayout title="Categories">
        <div className="flex justify-end mb-6">
          <Button variant="primary" icon={FaPlus} onClick={() => openModal()}>Add Category</Button>
        </div>

        {loading ? (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">{[1, 2, 3, 4, 5, 6].map((i) => <div key={i} className="glass-card-solid rounded-2xl p-5"><TextSkeleton lines={2} /></div>)}</div>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {categories.map((cat) => (
              <div key={cat._id} className="glass-card-solid rounded-2xl p-5">
                <div className="flex items-start justify-between mb-2">
                  <div className="text-3xl">{cat.icon || '✨'}</div>
                  <div className="flex gap-2">
                    <button onClick={() => openModal(cat)} className="btn-icon"><FaEdit size={13} /></button>
                    <button onClick={() => handleDelete(cat._id)} className="btn-icon text-red-400 hover:text-red-500"><FaTrash size={13} /></button>
                  </div>
                </div>
                <h3 className="font-semibold text-gray-800 dark:text-white">{cat.name}</h3>
                <p className="text-sm text-gray-400 mb-2 line-clamp-2">{cat.description}</p>
                <span className="badge-pink">{cat.productCount || 0} products</span>
              </div>
            ))}
          </div>
        )}

        {modalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <div className="absolute inset-0 bg-black/50" onClick={() => setModalOpen(false)} />
            <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="relative bg-white dark:bg-gray-900 rounded-3xl w-full max-w-md p-6 sm:p-8">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-display font-semibold text-gray-900 dark:text-white">{editCategory ? 'Edit Category' : 'Add Category'}</h2>
                <button onClick={() => setModalOpen(false)} className="btn-icon"><FaTimes /></button>
              </div>
              <form onSubmit={handleSubmit} className="space-y-4">
                <input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Category Name" className="input-field" />
                <input value={form.icon} onChange={(e) => setForm({ ...form, icon: e.target.value })} placeholder="Icon (emoji, e.g. 💧)" className="input-field" />
                <textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="Description" className="input-field" />
                <input type="number" value={form.order} onChange={(e) => setForm({ ...form, order: Number(e.target.value) })} placeholder="Display Order" className="input-field" />
                <Button type="submit" variant="primary" loading={saving} className="w-full">{editCategory ? 'Update' : 'Create'}</Button>
              </form>
            </motion.div>
          </div>
        )}
      </AdminLayout>
    </MainLayout>
  )
}

export default AdminCategoriesPage
