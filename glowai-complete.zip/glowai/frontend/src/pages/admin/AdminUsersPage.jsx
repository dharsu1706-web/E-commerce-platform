import React, { useState, useEffect } from 'react'
import { FaSearch, FaTrash, FaUserShield } from 'react-icons/fa'
import toast from 'react-hot-toast'
import MainLayout from '../../components/layout/MainLayout'
import SEO from '../../components/common/SEO'
import AdminLayout from '../../components/admin/AdminLayout'
import Pagination from '../../components/shop/Pagination'
import { TextSkeleton } from '../../components/common/Loaders'
import { userAPI } from '../../services/api'

const AdminUsersPage = () => {
  const [users, setUsers] = useState([])
  const [loading, setLoading] = useState(true)
  const [page, setPage] = useState(1)
  const [pages, setPages] = useState(1)
  const [search, setSearch] = useState('')

  const fetchUsers = () => {
    setLoading(true)
    userAPI.getAll({ page, search }).then(({ data }) => { setUsers(data.users); setPages(data.pages) }).finally(() => setLoading(false))
  }

  useEffect(() => { fetchUsers() }, [page, search])

  const handleRoleToggle = async (user) => {
    const newRole = user.role === 'admin' ? 'user' : 'admin'
    if (!window.confirm(`Change ${user.name}'s role to ${newRole}?`)) return
    try {
      const { data } = await userAPI.update(user._id, { role: newRole })
      toast.success(data.message)
      fetchUsers()
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to update role')
    }
  }

  const handleDeactivate = async (user) => {
    if (!window.confirm(`Deactivate ${user.name}'s account?`)) return
    try {
      const { data } = await userAPI.delete(user._id)
      toast.success(data.message)
      fetchUsers()
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to deactivate')
    }
  }

  return (
    <MainLayout>
      <SEO title="Manage Users" />
      <AdminLayout title="Users">
        <div className="relative max-w-xs mb-6">
          <FaSearch className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={12} />
          <input value={search} onChange={(e) => { setSearch(e.target.value); setPage(1) }} placeholder="Search by name or email..." className="input-field pl-10 py-2 text-sm" />
        </div>

        {loading ? (
          <div className="space-y-3">{[1, 2, 3, 4, 5].map((i) => <div key={i} className="glass-card-solid rounded-2xl p-4"><TextSkeleton lines={1} /></div>)}</div>
        ) : (
          <div className="glass-card-solid rounded-2xl overflow-hidden overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-pink-50 dark:bg-pink-900/20">
                <tr>
                  <th className="text-left p-4 font-semibold text-gray-700 dark:text-gray-300">User</th>
                  <th className="text-left p-4 font-semibold text-gray-700 dark:text-gray-300">Email</th>
                  <th className="text-left p-4 font-semibold text-gray-700 dark:text-gray-300">Role</th>
                  <th className="text-left p-4 font-semibold text-gray-700 dark:text-gray-300">Joined</th>
                  <th className="text-left p-4 font-semibold text-gray-700 dark:text-gray-300">Status</th>
                  <th className="text-right p-4 font-semibold text-gray-700 dark:text-gray-300">Actions</th>
                </tr>
              </thead>
              <tbody>
                {users.map((u) => (
                  <tr key={u._id} className="border-t border-pink-50 dark:border-pink-900/20">
                    <td className="p-4">
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-full bg-gradient-to-br from-pink-300 to-pink-500 flex items-center justify-center text-white font-semibold text-sm">{u.name?.charAt(0).toUpperCase()}</div>
                        <p className="font-medium text-gray-800 dark:text-gray-100">{u.name}</p>
                      </div>
                    </td>
                    <td className="p-4 text-gray-600 dark:text-gray-300">{u.email}</td>
                    <td className="p-4"><span className={`badge-${u.role === 'admin' ? 'pink' : 'gray'} capitalize`}>{u.role}</span></td>
                    <td className="p-4 text-gray-600 dark:text-gray-300">{new Date(u.createdAt).toLocaleDateString()}</td>
                    <td className="p-4"><span className={`badge-${u.isActive ? 'green' : 'red'}`}>{u.isActive ? 'Active' : 'Inactive'}</span></td>
                    <td className="p-4 text-right">
                      <div className="flex justify-end gap-2">
                        <button onClick={() => handleRoleToggle(u)} className="btn-icon" title="Toggle admin role"><FaUserShield size={14} /></button>
                        <button onClick={() => handleDeactivate(u)} className="btn-icon text-red-400 hover:text-red-500" title="Deactivate"><FaTrash size={14} /></button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        <Pagination page={page} pages={pages} onChange={setPage} />
      </AdminLayout>
    </MainLayout>
  )
}

export default AdminUsersPage
