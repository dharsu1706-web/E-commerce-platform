import React, { useState, useEffect } from 'react'
import { FaPlus, FaTrash, FaTimes, FaTag } from 'react-icons/fa'
import toast from 'react-hot-toast'
import { motion } from 'framer-motion'
import MainLayout from '../../components/layout/MainLayout'
import SEO from '../../components/common/SEO'
import AdminLayout from '../../components/admin/AdminLayout'
import Button from '../../components/common/Button'
import { TextSkeleton } from '../../components/common/Loaders'
import { couponAPI } from '../../services/api'

const emptyForm = { code: '', description: '', discountType: 'percentage', discountValue: '', minOrderAmount: 0, maxDiscountAmount: '', usageLimit: '', endDate: '' }

const AdminCouponsPage = () => {
  const [coupons, setCoupons] = useState([])
  const [loading, setLoading] = useState(true)
  const [modalOpen, setModalOpen] = useState(false)
  const [form, setForm] = useState(emptyForm)
  const [saving, setSaving] = useState(false)

  const fetchCoupons = () => {
    setLoading(true)
    couponAPI.getAll().then(({ data }) => setCoupons(data.coupons)).finally(() => setLoading(false))
  }

  useEffect(() => { fetchCoupons() }, [])

  const handleSubmit = async (e) => {
    e.preventDefault()
    setSaving(true)
    try {
      const payload = {
        ...form,
        discountValue: Number(form.discountValue),
        minOrderAmount: Number(form.minOrderAmount) || 0,
        maxDiscountAmount: form.maxDiscountAmount ? Number(form.maxDiscountAmount) : null,
        usageLimit: form.usageLimit ? Number(form.usageLimit) : null,
      }
      const { data } = await couponAPI.create(payload)
      toast.success(data.message)
      setModalOpen(false)
      setForm(emptyForm)
      fetchCoupons()
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to create coupon')
    } finally {
      setSaving(false)
    }
  }

  const handleDelete = async (id) => {
    if (!window.confirm('Delete this coupon?')) return
    try {
      const { data } = await couponAPI.delete(id)
      toast.success(data.message)
      fetchCoupons()
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to delete')
    }
  }

  const toggleActive = async (coupon) => {
    try {
      const { data } = await couponAPI.update(coupon._id, { isActive: !coupon.isActive })
      toast.success(data.message)
      fetchCoupons()
    } catch {
      toast.error('Failed to update')
    }
  }

  return (
    <MainLayout>
      <SEO title="Manage Coupons" />
      <AdminLayout title="Coupons">
        <div className="flex justify-end mb-6">
          <Button variant="primary" icon={FaPlus} onClick={() => setModalOpen(true)}>Add Coupon</Button>
        </div>

        {loading ? (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">{[1, 2, 3].map((i) => <div key={i} className="glass-card-solid rounded-2xl p-5"><TextSkeleton lines={3} /></div>)}</div>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {coupons.map((coupon) => (
              <div key={coupon._id} className="glass-card-solid rounded-2xl p-5">
                <div className="flex items-center justify-between mb-3">
                  <span className="flex items-center gap-2 font-mono font-bold text-lg text-pink-500"><FaTag size={14} /> {coupon.code}</span>
                  <button onClick={() => handleDelete(coupon._id)} className="btn-icon text-red-400 hover:text-red-500"><FaTrash size={13} /></button>
                </div>
                <p className="text-sm text-gray-500 dark:text-gray-400 mb-3">{coupon.description}</p>
                <div className="space-y-1 text-sm text-gray-600 dark:text-gray-300">
                  <p>Discount: <span className="font-semibold">{coupon.discountType === 'percentage' ? `${coupon.discountValue}%` : `₹${coupon.discountValue}`}</span></p>
                  <p>Min Order: <span className="font-semibold">₹{coupon.minOrderAmount}</span></p>
                  <p>Used: <span className="font-semibold">{coupon.usedCount}{coupon.usageLimit ? ` / ${coupon.usageLimit}` : ''}</span></p>
                  <p>Expires: <span className="font-semibold">{new Date(coupon.endDate).toLocaleDateString()}</span></p>
                </div>
                <button onClick={() => toggleActive(coupon)} className={`mt-3 text-xs px-3 py-1.5 rounded-full ${coupon.isActive ? 'badge-green' : 'badge-gray'}`}>
                  {coupon.isActive ? 'Active' : 'Inactive'}
                </button>
              </div>
            ))}
          </div>
        )}

        {modalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <div className="absolute inset-0 bg-black/50" onClick={() => setModalOpen(false)} />
            <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="relative bg-white dark:bg-gray-900 rounded-3xl w-full max-w-md p-6 sm:p-8 max-h-[85vh] overflow-y-auto custom-scroll">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-display font-semibold text-gray-900 dark:text-white">Add Coupon</h2>
                <button onClick={() => setModalOpen(false)} className="btn-icon"><FaTimes /></button>
              </div>
              <form onSubmit={handleSubmit} className="space-y-4">
                <input required value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value.toUpperCase() })} placeholder="Coupon Code (e.g. SAVE20)" className="input-field" />
                <textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="Description" className="input-field" />
                <select value={form.discountType} onChange={(e) => setForm({ ...form, discountType: e.target.value })} className="input-field">
                  <option value="percentage">Percentage Discount</option>
                  <option value="fixed">Fixed Amount Discount</option>
                </select>
                <input required type="number" value={form.discountValue} onChange={(e) => setForm({ ...form, discountValue: e.target.value })} placeholder={form.discountType === 'percentage' ? 'Discount %' : 'Discount Amount (₹)'} className="input-field" />
                <input type="number" value={form.minOrderAmount} onChange={(e) => setForm({ ...form, minOrderAmount: e.target.value })} placeholder="Minimum Order Amount (₹)" className="input-field" />
                {form.discountType === 'percentage' && <input type="number" value={form.maxDiscountAmount} onChange={(e) => setForm({ ...form, maxDiscountAmount: e.target.value })} placeholder="Max Discount Cap (₹) - optional" className="input-field" />}
                <input type="number" value={form.usageLimit} onChange={(e) => setForm({ ...form, usageLimit: e.target.value })} placeholder="Usage Limit - optional" className="input-field" />
                <div>
                  <label className="text-sm text-gray-600 dark:text-gray-300 mb-1 block">Expiry Date</label>
                  <input required type="date" value={form.endDate} onChange={(e) => setForm({ ...form, endDate: e.target.value })} className="input-field" />
                </div>
                <Button type="submit" variant="primary" loading={saving} className="w-full">Create Coupon</Button>
              </form>
            </motion.div>
          </div>
        )}
      </AdminLayout>
    </MainLayout>
  )
}

export default AdminCouponsPage
