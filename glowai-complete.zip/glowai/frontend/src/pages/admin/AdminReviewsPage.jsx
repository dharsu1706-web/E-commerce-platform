import React, { useState, useEffect } from 'react'
import { FaCheck, FaTimes, FaTrash } from 'react-icons/fa'
import toast from 'react-hot-toast'
import MainLayout from '../../components/layout/MainLayout'
import SEO from '../../components/common/SEO'
import AdminLayout from '../../components/admin/AdminLayout'
import StarRating from '../../components/common/StarRating'
import Pagination from '../../components/shop/Pagination'
import { TextSkeleton } from '../../components/common/Loaders'
import { reviewAPI } from '../../services/api'

const AdminReviewsPage = () => {
  const [reviews, setReviews] = useState([])
  const [loading, setLoading] = useState(true)
  const [page, setPage] = useState(1)
  const [pages, setPages] = useState(1)

  const fetchReviews = () => {
    setLoading(true)
    reviewAPI.getAll({ page }).then(({ data }) => { setReviews(data.reviews); setPages(data.pages) }).finally(() => setLoading(false))
  }

  useEffect(() => { fetchReviews() }, [page])

  const handleModerate = async (id, isApproved) => {
    try {
      const { data } = await reviewAPI.moderate(id, { isApproved })
      toast.success(data.message)
      fetchReviews()
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to moderate')
    }
  }

  const handleDelete = async (id) => {
    if (!window.confirm('Delete this review?')) return
    try {
      const { data } = await reviewAPI.delete(id)
      toast.success(data.message)
      fetchReviews()
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to delete')
    }
  }

  return (
    <MainLayout>
      <SEO title="Manage Reviews" />
      <AdminLayout title="Reviews">
        {loading ? (
          <div className="space-y-3">{[1, 2, 3, 4].map((i) => <div key={i} className="glass-card-solid rounded-2xl p-4"><TextSkeleton lines={2} /></div>)}</div>
        ) : reviews.length === 0 ? (
          <p className="text-center text-gray-400 py-12">No reviews found.</p>
        ) : (
          <div className="space-y-4">
            {reviews.map((review) => (
              <div key={review._id} className="glass-card-solid rounded-2xl p-5">
                <div className="flex items-start justify-between gap-4 flex-wrap">
                  <div className="flex items-start gap-3">
                    <img src={review.product?.images?.[0]?.url} alt="" className="w-12 h-12 rounded-lg object-cover" />
                    <div>
                      <p className="font-medium text-gray-800 dark:text-gray-100 line-clamp-1">{review.product?.name}</p>
                      <p className="text-xs text-gray-400">by {review.user?.name} ({review.user?.email})</p>
                      <StarRating rating={review.rating} size={12} className="mt-1" />
                    </div>
                  </div>
                  <span className={`badge-${review.isApproved ? 'green' : 'yellow'}`}>{review.isApproved ? 'Approved' : 'Pending'}</span>
                </div>
                <h4 className="font-medium text-sm text-gray-800 dark:text-gray-100 mt-3">{review.title}</h4>
                <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">{review.comment}</p>
                <div className="flex gap-2 mt-3">
                  {!review.isApproved && (
                    <button onClick={() => handleModerate(review._id, true)} className="flex items-center gap-1 text-xs px-3 py-1.5 rounded-full bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 hover:bg-emerald-200 transition-colors"><FaCheck size={10} /> Approve</button>
                  )}
                  {review.isApproved && (
                    <button onClick={() => handleModerate(review._id, false)} className="flex items-center gap-1 text-xs px-3 py-1.5 rounded-full bg-yellow-100 dark:bg-yellow-900/30 text-yellow-600 dark:text-yellow-400 hover:bg-yellow-200 transition-colors"><FaTimes size={10} /> Unapprove</button>
                  )}
                  <button onClick={() => handleDelete(review._id)} className="flex items-center gap-1 text-xs px-3 py-1.5 rounded-full bg-red-100 dark:bg-red-900/30 text-red-500 hover:bg-red-200 transition-colors"><FaTrash size={10} /> Delete</button>
                </div>
              </div>
            ))}
          </div>
        )}
        <Pagination page={page} pages={pages} onChange={setPage} />
      </AdminLayout>
    </MainLayout>
  )
}

export default AdminReviewsPage
