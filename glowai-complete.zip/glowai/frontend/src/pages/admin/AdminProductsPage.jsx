import React, { useState, useEffect } from 'react'
import { FaPlus, FaEdit, FaTrash, FaSearch } from 'react-icons/fa'
import toast from 'react-hot-toast'
import MainLayout from '../../components/layout/MainLayout'
import SEO from '../../components/common/SEO'
import AdminLayout from '../../components/admin/AdminLayout'
import ProductFormModal from '../../components/admin/ProductFormModal'
import Pagination from '../../components/shop/Pagination'
import Button from '../../components/common/Button'
import { TextSkeleton } from '../../components/common/Loaders'
import { productAPI, categoryAPI } from '../../services/api'

const AdminProductsPage = () => {
  const [products, setProducts] = useState([])
  const [categories, setCategories] = useState([])
  const [loading, setLoading] = useState(true)
  const [page, setPage] = useState(1)
  const [pages, setPages] = useState(1)
  const [search, setSearch] = useState('')
  const [modalOpen, setModalOpen] = useState(false)
  const [editProduct, setEditProduct] = useState(null)

  const fetchProducts = () => {
    setLoading(true)
    productAPI.getAll({ page, limit: 10, search })
      .then(({ data }) => { setProducts(data.products); setPages(data.pages) })
      .finally(() => setLoading(false))
  }

  useEffect(() => {
    categoryAPI.getAll().then(({ data }) => setCategories(data.categories))
  }, [])

  useEffect(() => {
    fetchProducts()
  }, [page, search])

  const handleDelete = async (id) => {
    if (!window.confirm('Delete this product?')) return
    try {
      const { data } = await productAPI.delete(id)
      toast.success(data.message)
      fetchProducts()
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to delete')
    }
  }

  return (
    <MainLayout>
      <SEO title="Manage Products" />
      <AdminLayout title="Products">
        <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
          <div className="relative max-w-xs">
            <FaSearch className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={12} />
            <input value={search} onChange={(e) => { setSearch(e.target.value); setPage(1) }} placeholder="Search products..." className="input-field pl-10 py-2 text-sm" />
          </div>
          <Button variant="primary" icon={FaPlus} onClick={() => { setEditProduct(null); setModalOpen(true) }}>Add Product</Button>
        </div>

        {loading ? (
          <div className="space-y-3">{[1, 2, 3, 4, 5].map((i) => <div key={i} className="glass-card-solid rounded-2xl p-4"><TextSkeleton lines={1} /></div>)}</div>
        ) : (
          <div className="glass-card-solid rounded-2xl overflow-hidden overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-pink-50 dark:bg-pink-900/20">
                <tr>
                  <th className="text-left p-4 font-semibold text-gray-700 dark:text-gray-300">Product</th>
                  <th className="text-left p-4 font-semibold text-gray-700 dark:text-gray-300">Category</th>
                  <th className="text-left p-4 font-semibold text-gray-700 dark:text-gray-300">Price</th>
                  <th className="text-left p-4 font-semibold text-gray-700 dark:text-gray-300">Stock</th>
                  <th className="text-left p-4 font-semibold text-gray-700 dark:text-gray-300">Rating</th>
                  <th className="text-right p-4 font-semibold text-gray-700 dark:text-gray-300">Actions</th>
                </tr>
              </thead>
              <tbody>
                {products.map((p) => (
                  <tr key={p._id} className="border-t border-pink-50 dark:border-pink-900/20">
                    <td className="p-4">
                      <div className="flex items-center gap-3">
                        <img src={p.images?.[0]?.url} alt={p.name} className="w-10 h-10 rounded-lg object-cover" />
                        <div>
                          <p className="font-medium text-gray-800 dark:text-gray-100 line-clamp-1 max-w-[200px]">{p.name}</p>
                          <p className="text-xs text-gray-400">{p.brand}</p>
                        </div>
                      </div>
                    </td>
                    <td className="p-4 text-gray-600 dark:text-gray-300">{p.category?.name}</td>
                    <td className="p-4">
                      <p className="font-semibold text-gray-800 dark:text-gray-100">₹{(p.discountPrice || p.price).toLocaleString('en-IN')}</p>
                      {p.discountPrice > 0 && <p className="text-xs text-gray-400 line-through">₹{p.price}</p>}
                    </td>
                    <td className="p-4">
                      <span className={p.stock <= 10 ? 'text-yellow-600 font-medium' : 'text-gray-600 dark:text-gray-300'}>{p.stock}</span>
                    </td>
                    <td className="p-4 text-gray-600 dark:text-gray-300">{p.ratings?.toFixed(1) || '—'} ⭐</td>
                    <td className="p-4 text-right">
                      <div className="flex justify-end gap-2">
                        <button onClick={() => { setEditProduct(p); setModalOpen(true) }} className="btn-icon"><FaEdit size={14} /></button>
                        <button onClick={() => handleDelete(p._id)} className="btn-icon text-red-400 hover:text-red-500"><FaTrash size={14} /></button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        <Pagination page={page} pages={pages} onChange={setPage} />

        {modalOpen && (
          <ProductFormModal
            product={editProduct}
            categories={categories}
            onClose={() => setModalOpen(false)}
            onSaved={() => { setModalOpen(false); fetchProducts() }}
          />
        )}
      </AdminLayout>
    </MainLayout>
  )
}

export default AdminProductsPage
