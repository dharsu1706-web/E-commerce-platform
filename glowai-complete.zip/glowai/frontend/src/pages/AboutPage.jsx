import React from 'react'
import { motion } from 'framer-motion'
import { FaLeaf, FaFlask, FaHeart, FaGlobeAmericas } from 'react-icons/fa'
import MainLayout from '../components/layout/MainLayout'
import SEO from '../components/common/SEO'

const values = [
  { icon: FaLeaf, title: 'Clean Ingredients', text: 'We carefully source dermatologist-approved, cruelty-free ingredients for every formula.' },
  { icon: FaFlask, title: 'Science-Backed', text: 'Every product is developed with proven actives at clinically effective concentrations.' },
  { icon: FaHeart, title: 'Inclusive Beauty', text: 'Our AI ensures recommendations work for every skin type, tone, and concern.' },
  { icon: FaGlobeAmericas, title: 'Sustainable', text: 'Eco-conscious packaging and ethically sourced ingredients across our range.' },
]

const AboutPage = () => {
  return (
    <MainLayout>
      <SEO title="About Us" description="Learn about GlowAI's mission to revolutionize skincare with AI-powered personalization." />

      {/* Hero */}
      <div className="bg-gradient-hero py-16 lg:py-24">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.h1 initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-4xl sm:text-5xl font-display font-bold text-gray-900 dark:text-white mb-6">
            Beauty, Reimagined with <span className="text-gradient-rose italic">Intelligence</span>
          </motion.h1>
          <p className="text-lg text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
            GlowAI was founded on a simple belief: everyone deserves skincare that truly understands their unique needs. We combine premium formulations with cutting-edge AI to deliver personalized beauty experiences.
          </p>
        </div>
      </div>

      {/* Story */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-24">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <motion.div initial={{ opacity: 0, x: -20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }}>
            <img src="https://images.unsplash.com/photo-1556228852-80b6e1cdb9e1?w=800&q=80" alt="Our story" className="rounded-3xl shadow-card-hover w-full aspect-[4/3] object-cover" />
          </motion.div>
          <motion.div initial={{ opacity: 0, x: 20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }}>
            <h2 className="section-heading mb-4">Our Story</h2>
            <p className="text-gray-600 dark:text-gray-300 mb-4 leading-relaxed">
              Founded in 2023, GlowAI began with a frustrating reality many of us know too well: countless products, endless reviews, and still no idea what actually works for our skin.
            </p>
            <p className="text-gray-600 dark:text-gray-300 mb-4 leading-relaxed">
              We set out to change that by building an AI-powered platform that learns about your skin — its type, concerns, and goals — and matches you with products and routines that actually deliver results.
            </p>
            <p className="text-gray-600 dark:text-gray-300 leading-relaxed">
              Today, GlowAI serves thousands of customers across India, offering a curated range of premium skincare alongside intelligent, personalized guidance every step of the way.
            </p>
          </motion.div>
        </div>
      </div>

      {/* Values */}
      <div className="bg-pink-50/50 dark:bg-pink-950/10 py-16 lg:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="section-heading">What We Stand For</h2>
            <p className="section-subheading mx-auto">The principles that guide everything we create</p>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {values.map((v, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="glass-card-solid rounded-2xl p-6 text-center"
              >
                <div className="w-14 h-14 rounded-full bg-gradient-to-br from-pink-100 to-pink-200 dark:from-pink-900/40 dark:to-pink-800/40 flex items-center justify-center mx-auto mb-4">
                  <v.icon className="text-pink-500" size={22} />
                </div>
                <h3 className="font-display font-semibold text-gray-900 dark:text-white mb-2">{v.title}</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400">{v.text}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-24">
        <div className="grid sm:grid-cols-4 gap-8 text-center">
          {[
            { value: '50K+', label: 'Happy Customers' },
            { value: '100+', label: 'Premium Products' },
            { value: '4.8/5', label: 'Average Rating' },
            { value: '24/7', label: 'AI Assistant' },
          ].map((stat, i) => (
            <motion.div key={i} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.1 }}>
              <p className="text-4xl font-display font-bold text-gradient-rose mb-2">{stat.value}</p>
              <p className="text-gray-500 dark:text-gray-400">{stat.label}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </MainLayout>
  )
}

export default AboutPage
