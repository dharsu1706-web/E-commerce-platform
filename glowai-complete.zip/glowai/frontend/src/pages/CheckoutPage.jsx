import React, { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import { FaMapMarkerAlt, FaCreditCard, FaMoneyBillWave, FaUniversity, FaMobileAlt, FaTag, FaCheckCircle } from 'react-icons/fa'
import toast from 'react-hot-toast'
import MainLayout from '../components/layout/MainLayout'
import SEO from '../components/common/SEO'
import Button from '../components/common/Button'
import { useCart } from '../context/CartContext'
import { useAuth } from '../context/AuthContext'
import { orderAPI, couponAPI } from '../services/api'

const paymentOptions = [
  { value: 'card', label: 'Credit / Debit Card', icon: FaCreditCard },
  { value: 'upi', label: 'UPI', icon: FaMobileAlt },
  { value: 'netbanking', label: 'Net Banking', icon: FaUniversity },
  { value: 'cod', label: 'Cash on Delivery', icon: FaMoneyBillWave },
]

const CheckoutPage = () => {
  const { items, subtotal, shippingPrice, taxPrice, totalPrice, clearCart } = useCart()
  const { user } = useAuth()
  const navigate = useNavigate()

  const [address, setAddress] = useState({
    name: user?.name || '',
    street: '',
    city: '',
    state: '',
    zipCode: '',
    country: 'India',
    phone: user?.phone || '',
  })
  const [paymentMethod, setPaymentMethod] = useState('card')
  const [couponCode, setCouponCode] = useState('')
  const [discount, setDiscount] = useState(0)
  const [couponApplied, setCouponApplied] = useState(null)
  const [couponLoading, setCouponLoading] = useState(false)
  const [loading, setLoading] = useState(false)

  if (items.length === 0) {
    navigate('/cart')
    return null
  }

  const finalTotal = totalPrice - discount

  const handleApplyCoupon = async () => {
    if (!couponCode.trim()) return
    setCouponLoading(true)
    try {
      const { data } = await couponAPI.validate({ code: couponCode, orderAmount: subtotal })
      setDiscount(data.discount)
      setCouponApplied(data.coupon)
      toast.success(`Coupon applied! You saved ₹${data.discount}`)
    } catch (err) {
      toast.error(err.response?.data?.message || 'Invalid coupon')
      setDiscount(0)
      setCouponApplied(null)
    } finally {
      setCouponLoading(false)
    }
  }

  const handlePlaceOrder = async (e) => {
    e.preventDefault()
    setLoading(true)
    try {
      const orderItems = items.map((i) => ({ product: i.product, quantity: i.quantity }))
      const { data } = await orderAPI.create({
        items: orderItems,
        shippingAddress: address,
        paymentMethod,
        couponCode: couponApplied ? couponCode : undefined,
      })
      clearCart()
      toast.success('Order placed successfully! 🎉')
      navigate(`/dashboard/orders/${data.order._id}`)
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to place order')
    } finally {
      setLoading(false)
    }
  }

  return (
    <MainLayout>
      <SEO title="Checkout" />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <h1 className="section-heading mb-8">Checkout</h1>

        <form onSubmit={handlePlaceOrder} className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-6">
            {/* Shipping Address */}
            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="glass-card-solid rounded-2xl p-6">
              <h2 className="font-display font-semibold text-lg text-gray-900 dark:text-white mb-4 flex items-center gap-2">
                <FaMapMarkerAlt className="text-pink-500" /> Shipping Address
              </h2>
              <div className="grid sm:grid-cols-2 gap-4">
                <input required value={address.name} onChange={(e) => setAddress({ ...address, name: e.target.value })} placeholder="Full Name" className="input-field sm:col-span-2" />
                <input required value={address.street} onChange={(e) => setAddress({ ...address, street: e.target.value })} placeholder="Street Address" className="input-field sm:col-span-2" />
                <input required value={address.city} onChange={(e) => setAddress({ ...address, city: e.target.value })} placeholder="City" className="input-field" />
                <input required value={address.state} onChange={(e) => setAddress({ ...address, state: e.target.value })} placeholder="State" className="input-field" />
                <input required value={address.zipCode} onChange={(e) => setAddress({ ...address, zipCode: e.target.value })} placeholder="ZIP / Postal Code" className="input-field" />
                <input required value={address.phone} onChange={(e) => setAddress({ ...address, phone: e.target.value })} placeholder="Phone Number" className="input-field" />
              </div>
            </motion.div>

            {/* Payment Method */}
            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="glass-card-solid rounded-2xl p-6">
              <h2 className="font-display font-semibold text-lg text-gray-900 dark:text-white mb-4 flex items-center gap-2">
                <FaCreditCard className="text-pink-500" /> Payment Method
              </h2>
              <div className="grid sm:grid-cols-2 gap-3">
                {paymentOptions.map((opt) => (
                  <label
                    key={opt.value}
                    className={`flex items-center gap-3 p-4 rounded-xl border-2 cursor-pointer transition-colors ${
                      paymentMethod === opt.value ? 'border-pink-500 bg-pink-50 dark:bg-pink-900/20' : 'border-gray-200 dark:border-gray-700 hover:border-pink-300'
                    }`}
                  >
                    <input type="radio" name="payment" value={opt.value} checked={paymentMethod === opt.value} onChange={() => setPaymentMethod(opt.value)} className="text-pink-500 focus:ring-pink-400" />
                    <opt.icon className="text-pink-500" />
                    <span className="text-sm font-medium text-gray-700 dark:text-gray-300">{opt.label}</span>
                  </label>
                ))}
              </div>
              {paymentMethod !== 'cod' && (
                <p className="text-xs text-gray-400 mt-3">* This is a demo store. No real payment will be processed.</p>
              )}
            </motion.div>
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-1">
            <div className="glass-card-solid rounded-2xl p-6 sticky top-24">
              <h2 className="font-display font-semibold text-lg text-gray-900 dark:text-white mb-4">Order Summary</h2>

              <div className="space-y-3 max-h-48 overflow-y-auto custom-scroll mb-4">
                {items.map((item) => (
                  <div key={item.product} className="flex gap-3 items-center">
                    <img src={item.image} alt={item.name} className="w-12 h-12 rounded-lg object-cover flex-shrink-0" />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-gray-800 dark:text-gray-100 line-clamp-1">{item.name}</p>
                      <p className="text-xs text-gray-400">Qty: {item.quantity}</p>
                    </div>
                    <p className="text-sm font-semibold text-gray-800 dark:text-gray-100">₹{(item.price * item.quantity).toLocaleString('en-IN')}</p>
                  </div>
                ))}
              </div>

              {/* Coupon */}
              <div className="mb-4">
                {couponApplied ? (
                  <div className="flex items-center justify-between bg-emerald-50 dark:bg-emerald-900/20 rounded-xl p-3">
                    <span className="text-sm text-emerald-600 dark:text-emerald-400 flex items-center gap-2"><FaCheckCircle /> {couponApplied.code} applied</span>
                    <button type="button" onClick={() => { setCouponApplied(null); setDiscount(0); setCouponCode('') }} className="text-xs text-gray-400 hover:text-red-500">Remove</button>
                  </div>
                ) : (
                  <div className="flex gap-2">
                    <div className="relative flex-1">
                      <FaTag className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={12} />
                      <input value={couponCode} onChange={(e) => setCouponCode(e.target.value.toUpperCase())} placeholder="Coupon code" className="input-field pl-9 py-2 text-sm" />
                    </div>
                    <Button type="button" variant="outline" size="sm" onClick={handleApplyCoupon} loading={couponLoading}>Apply</Button>
                  </div>
                )}
              </div>

              <div className="space-y-2 text-sm border-t border-pink-100 dark:border-pink-900/30 pt-3">
                <div className="flex justify-between text-gray-600 dark:text-gray-300"><span>Subtotal</span><span>₹{subtotal.toLocaleString('en-IN')}</span></div>
                <div className="flex justify-between text-gray-600 dark:text-gray-300"><span>Shipping</span><span>{shippingPrice === 0 ? 'FREE' : `₹${shippingPrice}`}</span></div>
                <div className="flex justify-between text-gray-600 dark:text-gray-300"><span>Tax (GST)</span><span>₹{taxPrice.toLocaleString('en-IN')}</span></div>
                {discount > 0 && <div className="flex justify-between text-emerald-500"><span>Discount</span><span>-₹{discount.toLocaleString('en-IN')}</span></div>}
                <div className="flex justify-between font-bold text-lg text-gray-900 dark:text-white border-t border-pink-100 dark:border-pink-900/30 pt-2">
                  <span>Total</span><span>₹{finalTotal.toLocaleString('en-IN')}</span>
                </div>
              </div>

              <Button type="submit" variant="primary" size="lg" loading={loading} className="w-full mt-6">Place Order</Button>
              <Link to="/cart" className="block text-center text-sm text-pink-500 hover:underline mt-4">Back to Bag</Link>
            </div>
          </div>
        </form>
      </div>
    </MainLayout>
  )
}

export default CheckoutPage
