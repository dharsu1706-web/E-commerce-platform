import React, { useState, useEffect } from 'react'
import MainLayout from '../components/layout/MainLayout'
import SEO from '../components/common/SEO'
import Hero from '../components/home/Hero'
import Categories from '../components/home/Categories'
import ProductSection from '../components/home/ProductSection'
import AIBanner from '../components/home/AIBanner'
import Testimonials from '../components/home/Testimonials'
import { productAPI, categoryAPI } from '../services/api'

const HomePage = () => {
  const [categories, setCategories] = useState([])
  const [special, setSpecial] = useState({ featured: [], bestSellers: [], trending: [], newArrivals: [] })
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [catRes, prodRes] = await Promise.all([
          categoryAPI.getAll(),
          productAPI.getSpecial(),
        ])
        setCategories(catRes.data.categories)
        setSpecial(prodRes.data)
      } catch (err) {
        console.error('Failed to load home data', err)
      } finally {
        setLoading(false)
      }
    }
    fetchData()
  }, [])

  return (
    <MainLayout>
      <SEO
        title="Premium AI-Powered Beauty & Skincare"
        description="Discover personalized skincare recommendations powered by AI. Premium serums, moisturizers, and beauty essentials for radiant skin."
      />

      <Hero />
      <Categories categories={categories} />
      <ProductSection
        title="Featured Products"
        subtitle="Hand-picked favorites for your skincare journey"
        badge="✨ Featured"
        products={special.featured}
        loading={loading}
        viewAllLink="/shop?featured=true"
      />
      <ProductSection
        title="Best Sellers"
        subtitle="Most loved by our GlowAI community"
        badge="🔥 Best Sellers"
        products={special.bestSellers}
        loading={loading}
        viewAllLink="/shop?bestSeller=true"
        bgClass="bg-pink-50/30 dark:bg-pink-950/5"
      />
      <AIBanner />
      <ProductSection
        title="Trending Now"
        subtitle="What everyone's adding to their routines"
        badge="📈 Trending"
        products={special.trending}
        loading={loading}
        viewAllLink="/shop?trending=true"
      />
      <Testimonials />
      <ProductSection
        title="New Arrivals"
        subtitle="Fresh drops just for you"
        badge="🆕 New"
        products={special.newArrivals}
        loading={loading}
        viewAllLink="/shop?isNew=true"
        bgClass="bg-pink-50/30 dark:bg-pink-950/5"
      />
    </MainLayout>
  )
}

export default HomePage
