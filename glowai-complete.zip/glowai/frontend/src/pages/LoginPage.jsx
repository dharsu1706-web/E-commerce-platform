import React, { useState } from 'react'
import { Link, useNavigate, useLocation } from 'react-router-dom'
import { motion } from 'framer-motion'
import { FaEnvelope, FaLock, FaEye, FaEyeSlash } from 'react-icons/fa'
import MainLayout from '../components/layout/MainLayout'
import SEO from '../components/common/SEO'
import Button from '../components/common/Button'
import { useAuth } from '../context/AuthContext'

const LoginPage = () => {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const { login, loading } = useAuth()
  const navigate = useNavigate()
  const location = useLocation()

  const handleSubmit = async (e) => {
    e.preventDefault()
    const res = await login(email, password)
    if (res.success) {
      navigate(location.state?.from?.pathname || '/')
    }
  }

  return (
    <MainLayout>
      <SEO title="Login" description="Login to your GlowAI account" />
      <div className="min-h-[80vh] flex items-center justify-center px-4 py-12 bg-gradient-hero">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
          className="w-full max-w-md glass-card-solid rounded-3xl p-8 sm:p-10"
        >
          <div className="text-center mb-8">
            <div className="w-14 h-14 rounded-full bg-gradient-to-br from-pink-400 to-pink-600 flex items-center justify-center mx-auto mb-4 shadow-glow">
              <span className="text-white font-display font-bold text-2xl">G</span>
            </div>
            <h1 className="text-2xl font-display font-bold text-gray-900 dark:text-white">Welcome Back</h1>
            <p className="text-gray-500 dark:text-gray-400 mt-1">Login to continue your glow journey ✨</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="relative">
              <FaEnvelope className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={14} />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Email address"
                className="input-field pl-11"
                required
              />
            </div>

            <div className="relative">
              <FaLock className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={14} />
              <input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Password"
                className="input-field pl-11 pr-11"
                required
              />
              <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 hover:text-pink-500">
                {showPassword ? <FaEyeSlash size={14} /> : <FaEye size={14} />}
              </button>
            </div>

            <div className="flex justify-end">
              <Link to="/forgot-password" className="text-sm text-pink-500 hover:underline">Forgot Password?</Link>
            </div>

            <Button type="submit" variant="primary" loading={loading} className="w-full">Login</Button>
          </form>

          <p className="text-center text-sm text-gray-500 dark:text-gray-400 mt-6">
            Don't have an account? <Link to="/register" className="text-pink-500 font-semibold hover:underline">Sign up</Link>
          </p>

          <div className="mt-6 pt-6 border-t border-pink-100 dark:border-pink-900/30 text-center">
            <p className="text-xs text-gray-400 mb-2">Demo Credentials</p>
            <p className="text-xs text-gray-500 dark:text-gray-400">Admin: admin@glowai.com / Admin@123456</p>
            <p className="text-xs text-gray-500 dark:text-gray-400">User: demo@glowai.com / Demo@123456</p>
          </div>
        </motion.div>
      </div>
    </MainLayout>
  )
}

export default LoginPage
