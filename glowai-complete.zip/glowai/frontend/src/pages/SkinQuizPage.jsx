import React, { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { FaMagic, FaArrowRight, FaArrowLeft, FaRedo } from 'react-icons/fa'
import MainLayout from '../components/layout/MainLayout'
import SEO from '../components/common/SEO'
import Button from '../components/common/Button'
import ProductCard from '../components/common/ProductCard'
import { PageLoader } from '../components/common/Loaders'
import { aiAPI } from '../services/api'

const questions = [
  {
    id: 'skinType',
    question: "How does your skin feel a few hours after washing your face?",
    options: [
      { value: 'oily', label: 'Shiny and greasy, especially T-zone', emoji: '✨' },
      { value: 'dry', label: 'Tight, flaky, or rough', emoji: '🏜️' },
      { value: 'combination', label: 'Oily T-zone but normal/dry cheeks', emoji: '⚖️' },
      { value: 'sensitive', label: 'Red, itchy, or easily irritated', emoji: '🌸' },
      { value: 'normal', label: 'Balanced, neither oily nor dry', emoji: '😊' },
    ],
  },
  {
    id: 'concern1',
    question: "What's your #1 skin concern right now?",
    options: [
      { value: 'acne', label: 'Acne & breakouts', emoji: '🎯' },
      { value: 'dark spots', label: 'Dark spots & pigmentation', emoji: '🌟' },
      { value: 'fine lines', label: 'Fine lines & wrinkles', emoji: '⏳' },
      { value: 'dehydration', label: 'Dryness & dehydration', emoji: '💧' },
      { value: 'large pores', label: 'Large pores', emoji: '🔍' },
    ],
  },
  {
    id: 'concern2',
    question: "Any secondary concerns?",
    options: [
      { value: 'dullness', label: 'Dull, tired-looking skin', emoji: '😴' },
      { value: 'redness', label: 'Redness & sensitivity', emoji: '🌹' },
      { value: 'uneven tone', label: 'Uneven skin tone', emoji: '🎨' },
      { value: 'oiliness', label: 'Excess oil & shine', emoji: '💦' },
      { value: 'none', label: 'None of these', emoji: '✅' },
    ],
  },
  {
    id: 'routine',
    question: "How would you describe your current skincare routine?",
    options: [
      { value: 'minimal', label: 'Minimal — just cleanse & moisturize', emoji: '🧼' },
      { value: 'basic', label: 'Basic — cleanser, moisturizer, SPF', emoji: '☀️' },
      { value: 'advanced', label: 'Advanced — multiple serums & actives', emoji: '🧪' },
      { value: 'none', label: "I don't really have one", emoji: '🤷' },
    ],
  },
  {
    id: 'sun',
    question: "How much sun exposure do you get daily?",
    options: [
      { value: 'low', label: 'Minimal — mostly indoors', emoji: '🏠' },
      { value: 'moderate', label: 'Moderate — some outdoor time', emoji: '🌤️' },
      { value: 'high', label: 'High — outdoors most of the day', emoji: '🌞' },
    ],
  },
]

const SkinQuizPage = () => {
  const [step, setStep] = useState(-1) // -1 = intro
  const [answers, setAnswers] = useState({})
  const [results, setResults] = useState(null)
  const [loading, setLoading] = useState(false)

  const handleAnswer = (value) => {
    const q = questions[step]
    setAnswers((prev) => ({ ...prev, [q.id]: value }))
    if (step < questions.length - 1) {
      setTimeout(() => setStep(step + 1), 250)
    } else {
      setTimeout(() => submitQuiz({ ...answers, [q.id]: value }), 250)
    }
  }

  const submitQuiz = async (finalAnswers) => {
    setLoading(true)
    try {
      const concerns = [finalAnswers.concern1, finalAnswers.concern2].filter((c) => c && c !== 'none')
      const { data } = await aiAPI.quiz({ skinType: finalAnswers.skinType, concerns, answers: finalAnswers })
      setResults(data)
    } catch (err) {
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  const restart = () => {
    setStep(-1)
    setAnswers({})
    setResults(null)
  }

  return (
    <MainLayout>
      <SEO title="AI Skin Quiz" description="Take our AI-powered skin quiz to discover your skin type and get personalized product recommendations." />

      <div className="bg-gradient-hero py-10 lg:py-14">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="inline-flex items-center gap-2 glass-card-solid px-4 py-2 rounded-full mb-4">
            <FaMagic className="text-pink-500" size={14} />
            <span className="text-sm font-medium text-pink-600 dark:text-pink-400">AI-Powered Skin Analysis</span>
          </div>
          <h1 className="section-heading">Discover Your Perfect Routine</h1>
          <p className="section-subheading mx-auto">Answer a few questions and let our AI curate the perfect products for your skin</p>
        </div>
      </div>

      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {step === -1 && !results && (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center glass-card-solid rounded-3xl p-10">
            <div className="text-6xl mb-4">🌸</div>
            <h2 className="text-2xl font-display font-bold text-gray-900 dark:text-white mb-3">Ready to find your glow?</h2>
            <p className="text-gray-500 dark:text-gray-400 mb-8 max-w-md mx-auto">
              This quick 5-question quiz will help us understand your skin type and concerns so we can recommend the perfect products for you.
            </p>
            <Button variant="primary" size="lg" icon={FaArrowRight} onClick={() => setStep(0)}>Start Quiz</Button>
          </motion.div>
        )}

        {step >= 0 && !results && (
          <div>
            {/* Progress bar */}
            <div className="mb-8">
              <div className="flex justify-between text-sm text-gray-500 mb-2">
                <span>Question {step + 1} of {questions.length}</span>
                <span>{Math.round(((step + 1) / questions.length) * 100)}%</span>
              </div>
              <div className="h-2 bg-pink-100 dark:bg-pink-900/30 rounded-full overflow-hidden">
                <motion.div
                  className="h-full bg-gradient-to-r from-pink-400 to-pink-600"
                  initial={{ width: 0 }}
                  animate={{ width: `${((step + 1) / questions.length) * 100}%` }}
                  transition={{ duration: 0.4 }}
                />
              </div>
            </div>

            <AnimatePresence mode="wait">
              <motion.div
                key={step}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.25 }}
                className="glass-card-solid rounded-3xl p-8"
              >
                <h2 className="text-xl sm:text-2xl font-display font-semibold text-gray-900 dark:text-white mb-6">{questions[step].question}</h2>
                <div className="space-y-3">
                  {questions[step].options.map((opt) => (
                    <button
                      key={opt.value}
                      onClick={() => handleAnswer(opt.value)}
                      className={`w-full flex items-center gap-4 p-4 rounded-2xl border-2 text-left transition-all hover:scale-[1.02] ${
                        answers[questions[step].id] === opt.value
                          ? 'border-pink-500 bg-pink-50 dark:bg-pink-900/20'
                          : 'border-gray-200 dark:border-gray-700 hover:border-pink-300'
                      }`}
                    >
                      <span className="text-2xl">{opt.emoji}</span>
                      <span className="font-medium text-gray-700 dark:text-gray-200">{opt.label}</span>
                    </button>
                  ))}
                </div>
              </motion.div>
            </AnimatePresence>

            {step > 0 && (
              <button onClick={() => setStep(step - 1)} className="mt-6 flex items-center gap-2 text-pink-500 hover:underline text-sm">
                <FaArrowLeft size={12} /> Previous Question
              </button>
            )}
          </div>
        )}

        {loading && <PageLoader />}

        {results && (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            <div className="text-center mb-10 glass-card-solid rounded-3xl p-8">
              <div className="text-5xl mb-3">🎉</div>
              <h2 className="text-2xl font-display font-bold text-gray-900 dark:text-white mb-2">Your Skin Profile</h2>
              <div className="flex items-center justify-center gap-2 mb-4">
                <span className="badge-pink text-sm capitalize">{results.skinType} Skin</span>
                {results.concerns?.map((c) => <span key={c} className="badge-gray text-sm capitalize">{c}</span>)}
              </div>
              <p className="text-gray-500 dark:text-gray-400">{results.message}</p>
            </div>

            {/* Routine */}
            {results.routine?.length > 0 && (
              <div className="glass-card-solid rounded-2xl p-6 mb-8">
                <h3 className="font-display font-semibold text-lg text-gray-900 dark:text-white mb-4">Your Recommended Routine</h3>
                <div className="space-y-3">
                  {results.routine.map((step, i) => (
                    <div key={i} className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-pink-500 text-white flex items-center justify-center text-sm font-bold flex-shrink-0">{i + 1}</div>
                      <p className="text-gray-700 dark:text-gray-300 text-sm">{step}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Key ingredients */}
            {results.ingredients?.length > 0 && (
              <div className="mb-8">
                <h3 className="font-display font-semibold text-lg text-gray-900 dark:text-white mb-4">Look for These Ingredients</h3>
                <div className="flex flex-wrap gap-2">
                  {results.ingredients.map((ing) => <span key={ing} className="badge-pink capitalize">{ing}</span>)}
                </div>
              </div>
            )}

            {/* Recommended products */}
            <h3 className="font-display font-semibold text-lg text-gray-900 dark:text-white mb-4">Recommended Products for You</h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 md:gap-6 mb-8">
              {results.products?.map((p, i) => <ProductCard key={p._id} product={p} index={i} />)}
            </div>

            <div className="text-center">
              <Button variant="secondary" icon={FaRedo} onClick={restart}>Retake Quiz</Button>
            </div>
          </motion.div>
        )}
      </div>
    </MainLayout>
  )
}

export default SkinQuizPage
