import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import { FaUser, FaEnvelope, FaLock, FaEye, FaEyeSlash } from 'react-icons/fa'
import MainLayout from '../components/layout/MainLayout'
import SEO from '../components/common/SEO'
import Button from '../components/common/Button'
import { useAuth } from '../context/AuthContext'

const RegisterPage = () => {
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const { register, loading } = useAuth()
  const navigate = useNavigate()

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (password !== confirmPassword) {
      return
    }
    const res = await register(name, email, password)
    if (res.success) navigate('/')
  }

  return (
    <MainLayout>
      <SEO title="Create Account" description="Join GlowAI for personalized AI-powered beauty recommendations" />
      <div className="min-h-[80vh] flex items-center justify-center px-4 py-12 bg-gradient-hero">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
          className="w-full max-w-md glass-card-solid rounded-3xl p-8 sm:p-10"
        >
          <div className="text-center mb-8">
            <div className="w-14 h-14 rounded-full bg-gradient-to-br from-pink-400 to-pink-600 flex items-center justify-center mx-auto mb-4 shadow-glow">
              <span className="text-white font-display font-bold text-2xl">G</span>
            </div>
            <h1 className="text-2xl font-display font-bold text-gray-900 dark:text-white">Join GlowAI</h1>
            <p className="text-gray-500 dark:text-gray-400 mt-1">Create your account and start glowing ✨</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="relative">
              <FaUser className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={14} />
              <input type="text" value={name} onChange={(e) => setName(e.target.value)} placeholder="Full Name" className="input-field pl-11" required />
            </div>

            <div className="relative">
              <FaEnvelope className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={14} />
              <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email address" className="input-field pl-11" required />
            </div>

            <div className="relative">
              <FaLock className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={14} />
              <input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Password (min. 6 characters)"
                className="input-field pl-11 pr-11"
                required
                minLength={6}
              />
              <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 hover:text-pink-500">
                {showPassword ? <FaEyeSlash size={14} /> : <FaEye size={14} />}
              </button>
            </div>

            <div className="relative">
              <FaLock className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={14} />
              <input
                type={showPassword ? 'text' : 'password'}
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="Confirm Password"
                className="input-field pl-11"
                required
              />
            </div>

            {password && confirmPassword && password !== confirmPassword && (
              <p className="text-red-500 text-xs">Passwords do not match</p>
            )}

            <Button type="submit" variant="primary" loading={loading} className="w-full">Create Account</Button>
          </form>

          <p className="text-center text-sm text-gray-500 dark:text-gray-400 mt-6">
            Already have an account? <Link to="/login" className="text-pink-500 font-semibold hover:underline">Login</Link>
          </p>
        </motion.div>
      </div>
    </MainLayout>
  )
}

export default RegisterPage
