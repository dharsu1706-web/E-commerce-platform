import React from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import { FaTrash, FaMinus, FaPlus, FaShoppingBag, FaArrowRight } from 'react-icons/fa'
import MainLayout from '../components/layout/MainLayout'
import SEO from '../components/common/SEO'
import Button from '../components/common/Button'
import EmptyState from '../components/common/EmptyState'
import { useCart } from '../context/CartContext'
import { useAuth } from '../context/AuthContext'

const CartPage = () => {
  const { items, removeItem, updateQuantity, subtotal, shippingPrice, taxPrice, totalPrice, totalItems } = useCart()
  const { isAuthenticated } = useAuth()
  const navigate = useNavigate()

  const handleCheckout = () => {
    if (!isAuthenticated) {
      navigate('/login', { state: { from: { pathname: '/checkout' } } })
      return
    }
    navigate('/checkout')
  }

  if (items.length === 0) {
    return (
      <MainLayout>
        <SEO title="Shopping Cart" />
        <div className="max-w-3xl mx-auto px-4 py-16">
          <EmptyState
            icon={FaShoppingBag}
            title="Your bag is empty"
            message="Looks like you haven't added anything to your bag yet. Explore our collection to find your perfect products!"
            actionLabel="Start Shopping"
            actionLink="/shop"
          />
        </div>
      </MainLayout>
    )
  }

  return (
    <MainLayout>
      <SEO title="Shopping Cart" />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <h1 className="section-heading mb-8">Shopping Bag ({totalItems} items)</h1>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Items */}
          <div className="lg:col-span-2 space-y-4">
            {items.map((item, i) => (
              <motion.div
                key={item.product}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.05 }}
                className="glass-card-solid rounded-2xl p-4 flex gap-4"
              >
                <Link to={`/product/${item.slug || item.product}`} className="flex-shrink-0">
                  <img src={item.image} alt={item.name} className="w-20 h-20 sm:w-24 sm:h-24 rounded-xl object-cover" />
                </Link>
                <div className="flex-1 min-w-0">
                  <Link to={`/product/${item.slug || item.product}`} className="font-medium text-gray-800 dark:text-white hover:text-pink-500 transition-colors line-clamp-2">
                    {item.name}
                  </Link>
                  <p className="text-pink-500 font-bold mt-1">₹{item.price.toLocaleString('en-IN')}</p>

                  <div className="flex items-center justify-between mt-3">
                    <div className="flex items-center border border-pink-200 dark:border-pink-800 rounded-full">
                      <button onClick={() => updateQuantity(item.product, item.quantity - 1)} className="p-2 text-gray-500 hover:text-pink-500 transition-colors">
                        <FaMinus size={10} />
                      </button>
                      <span className="w-8 text-center text-sm font-semibold">{item.quantity}</span>
                      <button onClick={() => updateQuantity(item.product, item.quantity + 1)} className="p-2 text-gray-500 hover:text-pink-500 transition-colors">
                        <FaPlus size={10} />
                      </button>
                    </div>
                    <button onClick={() => removeItem(item.product)} className="text-red-400 hover:text-red-600 transition-colors p-2">
                      <FaTrash size={14} />
                    </button>
                  </div>
                </div>
                <div className="hidden sm:flex flex-col items-end justify-center flex-shrink-0">
                  <p className="font-bold text-gray-900 dark:text-white">₹{(item.price * item.quantity).toLocaleString('en-IN')}</p>
                </div>
              </motion.div>
            ))}
          </div>

          {/* Order summary */}
          <div className="lg:col-span-1">
            <div className="glass-card-solid rounded-2xl p-6 sticky top-24">
              <h2 className="font-display font-semibold text-lg text-gray-900 dark:text-white mb-4">Order Summary</h2>
              <div className="space-y-3 text-sm">
                <div className="flex justify-between text-gray-600 dark:text-gray-300">
                  <span>Subtotal</span>
                  <span>₹{subtotal.toLocaleString('en-IN')}</span>
                </div>
                <div className="flex justify-between text-gray-600 dark:text-gray-300">
                  <span>Shipping</span>
                  <span>{shippingPrice === 0 ? <span className="text-emerald-500 font-medium">FREE</span> : `₹${shippingPrice}`}</span>
                </div>
                <div className="flex justify-between text-gray-600 dark:text-gray-300">
                  <span>Tax (GST 18%)</span>
                  <span>₹{taxPrice.toLocaleString('en-IN')}</span>
                </div>
                {subtotal < 999 && (
                  <p className="text-xs text-pink-500 bg-pink-50 dark:bg-pink-900/20 rounded-lg p-2">
                    Add ₹{(999 - subtotal).toLocaleString('en-IN')} more for FREE shipping!
                  </p>
                )}
                <div className="border-t border-pink-100 dark:border-pink-900/30 pt-3 flex justify-between font-bold text-lg text-gray-900 dark:text-white">
                  <span>Total</span>
                  <span>₹{totalPrice.toLocaleString('en-IN')}</span>
                </div>
              </div>

              <Button variant="primary" size="lg" icon={FaArrowRight} onClick={handleCheckout} className="w-full mt-6">
                Proceed to Checkout
              </Button>
              <Link to="/shop" className="block text-center text-sm text-pink-500 hover:underline mt-4">
                Continue Shopping
              </Link>
            </div>
          </div>
        </div>
      </div>
    </MainLayout>
  )
}

export default CartPage
